# KotlinAndroidTest
kotlin android practice

* 2019/6/30 Add Animation Practice ..activity.AnimationActivity

* 2019/7/2 Add Animation Interpolator ..activity.InterpolatorActivity
