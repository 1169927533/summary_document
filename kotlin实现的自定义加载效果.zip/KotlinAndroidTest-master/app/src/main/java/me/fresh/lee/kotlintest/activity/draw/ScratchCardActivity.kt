package me.fresh.lee.kotlintest.activity.draw

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_scratch_card.*
import me.fresh.lee.kotlintest.R

/**
 *
 * @description    ScratchCardActivity
 * @author         lihuayong
 * @date           2019/7/17 0:09
 * @version        1.0
 */
class ScratchCardActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_scratch_card)
    }


    override fun onDestroy() {
        super.onDestroy()
        wave_text.stopAnim()
        shimmer_text.stopAnim()
    }
}