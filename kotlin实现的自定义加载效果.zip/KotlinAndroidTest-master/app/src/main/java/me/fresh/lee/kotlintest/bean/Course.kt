package me.fresh.lee.kotlintest.bean

/**
 * Created by lihuayong on 2018/9/21.
 */
data class Course(val id: Int, val title: String)