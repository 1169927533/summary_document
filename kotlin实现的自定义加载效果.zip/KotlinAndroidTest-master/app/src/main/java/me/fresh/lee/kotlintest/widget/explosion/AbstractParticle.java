package me.fresh.lee.kotlintest.widget.explosion;

import android.graphics.Canvas;
import android.graphics.Paint;

/**
 * @author lihuayong
 * @version 1.0
 * @description AbstractParticle
 * @date 2019-07-13 20:35
 */
@SuppressWarnings("WeakerAccess")
public abstract class AbstractParticle {

    protected float cx;
    protected float cy;

    protected int color;

    public AbstractParticle(int color, float x, float y) {
        this.color = color;
        this.cx = x;
        this.cy = y;
    }

    /**
     * 步进
     *
     * @param factor 粒子特效执行进度
     */
    public void advance(Canvas canvas, Paint paint, float factor) {
        //计算单前应该所在的位置
        calculate(factor);
        draw(canvas, paint);
    }

    /**
     * draw
     */
    protected abstract void draw(Canvas canvas, Paint paint);

    /**
     * calculate
     *
     * @param factor 粒子特效执行进度
     */
    protected abstract void calculate(float factor);
}
