package me.fresh.lee.kotlintest.activity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import me.fresh.lee.kotlintest.R;
import me.fresh.lee.kotlintest.util.UtilsKt;
import me.fresh.lee.kotlintest.widget.CoverFlowLayoutManager;
import me.fresh.lee.kotlintest.widget.CoverFlowRecyclerView;

/**
 * @author lee-r
 */
public class CoverFlowActivity extends AppCompatActivity {
    private ArrayList<String> mDatas = new ArrayList<>();
    private int[] mPics = {R.mipmap.item1, R.mipmap.item2, R.mipmap.item3, R.mipmap.item4,
            R.mipmap.item5, R.mipmap.item6};

    private static final int GAUSS_BLUR_RADIUS = 10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flowlayout);

        generateDatas();
        RecyclerView mRecyclerView = findViewById(R.id.linear_recycler_view);
        ImageView imageView = findViewById(R.id.iv_bg);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inSampleSize = 2;
        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.item1, options);
        Bitmap gaussBitmap = UtilsKt.gasussBlur(CoverFlowActivity.this, bitmap, GAUSS_BLUR_RADIUS);
        imageView.setImageBitmap(gaussBitmap);

        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
                if (newState == RecyclerView.SCROLL_STATE_IDLE) {
                    int center = ((CoverFlowRecyclerView) recyclerView).getCoverFlowLayout().getCenterPosition();
                    BitmapFactory.Options options = new BitmapFactory.Options();
                    options.inSampleSize = 2;
                    Bitmap bitmap = BitmapFactory.decodeResource(getResources(), mPics[center % mPics.length], options);
                    Bitmap gaussBitmap = UtilsKt.gasussBlur(CoverFlowActivity.this, bitmap, GAUSS_BLUR_RADIUS);
//                recyclerView.setBackground(new BitmapDrawable(getResources(), gaussBitmap));
                    imageView.setImageBitmap(gaussBitmap);
                }
            }
        });

        //线性布局
        mRecyclerView.setLayoutManager(new CoverFlowLayoutManager());

        CoverFlowAdapter adapter = new CoverFlowAdapter(this, mDatas, mRecyclerView);
        mRecyclerView.setAdapter(adapter);
    }

    private void generateDatas() {
        for (int i = 0; i < 200; i++) {
            mDatas.add("第 " + i + " 个item");
        }
    }
}