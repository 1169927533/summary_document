package me.fresh.lee.kotlintest.activity.animation

import android.animation.*
import android.graphics.*
import android.graphics.drawable.VectorDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.Animation
import android.view.animation.BounceInterpolator
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.android.synthetic.main.activity_animator.*
import kotlinx.android.synthetic.main.dialog_select_animator.view.*
import me.fresh.lee.kotlintest.R
import me.fresh.lee.kotlintest.util.getScreenSize
import me.fresh.lee.kotlintest.widget.TraceView


/**
 *
 * @description    AnimatorActivity
 *   演示了ValueAnimator ObjectAnimator PropertyValueHolder Keyframe TypeEvaluator 等的用法
 * @author         lihuayong
 * @date           2019-07-04 11:32
 * @version        1.0
 */
@Suppress("unused")
class AnimatorActivity : AppCompatActivity() {

    private lateinit var selectAnimatorDialog: BottomSheetDialog

    private lateinit var radioGroupAnimator: RadioGroup

    private lateinit var animator: ValueAnimator

    private lateinit var objectAnimator: ObjectAnimator

    private lateinit var btnAnimator: Button
    private lateinit var ivLike: ImageView

    private val mCurrentPosition = FloatArray(2)
    private lateinit var pathMeasure: PathMeasure
    private lateinit var traceView: TraceView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_animator)

        initView()

        initDefaultAnimator()

        initDialog()

        setClickListener()

        // AnimatorSet practice
        val horizontalAnim = ObjectAnimator.ofFloat(iv_like, "translationX", 0f, 500f)
        horizontalAnim.repeatCount = ValueAnimator.INFINITE
        horizontalAnim.duration = 2000
        horizontalAnim.interpolator = LinearInterpolator()
        val verticalAnim = ObjectAnimator.ofFloat(iv_like, "translationY", 0f, 500f)
        verticalAnim.repeatCount = Animation.INFINITE
        verticalAnim.duration = 2000

        val animSet = AnimatorSet()
        animSet.play(horizontalAnim).with(verticalAnim)
        animSet.duration = 2000
    }

    private fun setClickListener() {
        btn_choose_animator.setOnClickListener {
            btnAnimator.textSize = 16f
            selectAnimatorDialog.show()
        }

        btn_start.setOnClickListener {
            if (cb_object_animator.isChecked) {
                objectAnimator.start()
            } else {
                animator.start()
            }
        }

        btn_path.setOnClickListener {
            getHeartPath()
        }

        cb_object_animator.setOnClickListener {
            cb_object_animator.toggle()
            tv_object_animator.text = getString(if (cb_object_animator.isChecked) {
                R.string.choose_value_animator
            } else {
                R.string.choose_object_animator
            })
        }
    }

    private fun initDialog() {
        selectAnimatorDialog = BottomSheetDialog(this).apply {
            setContentView(R.layout.dialog_select_animator)
            window?.decorView?.apply {
                radioGroupAnimator = findViewById(R.id.radio_group)
                radioGroupAnimator.setOnCheckedChangeListener { _, checkedId ->
                    when (checkedId) {
                        R.id.rb_translate_z -> {
                            animator = ValueAnimator.ofFloat(1f, 3f)
                            animator.addUpdateListener {
                                ivLike.scaleX = it.animatedValue as Float
                                ivLike.scaleY = it.animatedValue as Float
                                ivLike.translationZ = it.animatedValue as Float
                            }
                            animator.interpolator = BounceInterpolator()
                            animator.duration = 2000
                            btnAnimator.text = rb_translate_z.text
                            objectAnimator = ObjectAnimator.ofFloat(btnAnimator, "translationZ", 1f, 20f)
                            objectAnimator.duration = 1000
                        }
                        R.id.rb_scale_x -> {
                            val holder = PropertyValuesHolder.ofFloat("scaleX", 1f, 2f, 1f)
                            animator = ObjectAnimator.ofPropertyValuesHolder(ivLike, holder)
                            animator.duration = 2000
                            btnAnimator.text = rb_scale_x.text
                            objectAnimator = ObjectAnimator.ofObject(ivLike, "scaleX", FloatEvaluator(), 1f, 2f, 1f)
                            objectAnimator.duration = 2000
                        }
                        R.id.rb_scale_y -> {
                            val holder = PropertyValuesHolder.ofFloat("scaleY", 1f, 2f, 1f)
                            animator = ObjectAnimator.ofPropertyValuesHolder(ivLike, holder)
                            animator.setTarget(ivLike)
                            animator.duration = 2000
                            btnAnimator.text = rb_scale_y.text
                            objectAnimator = ObjectAnimator.ofObject(ivLike, "scaleY", FloatEvaluator(), 1f, 2f, 1f)
                            objectAnimator.duration = 2000
                        }
                        R.id.rb_rotate_x -> {
                            val holder = PropertyValuesHolder.ofFloat("rotationX", 0f, 180f, 0f)
                            animator = ObjectAnimator.ofPropertyValuesHolder(ivLike, holder)
                            animator.duration = 2000
                            btnAnimator.text = rb_rotate_x.text
                            objectAnimator = ObjectAnimator.ofObject(ivLike, "rotationX", FloatEvaluator(), 0f, 180f, 0f)
                            objectAnimator.duration = 2000
                        }
                        R.id.rb_rotate_y -> {
                            val holder = PropertyValuesHolder.ofFloat("rotationY", 0f, 180f, 0f)
                            animator = ObjectAnimator.ofPropertyValuesHolder(ivLike, holder)
                            animator.setTarget(ivLike)
                            animator.duration = 2000
                            btnAnimator.text = rb_rotate_y.text
                            objectAnimator = ObjectAnimator.ofObject(ivLike, "rotationY", FloatEvaluator(), 0f, 180f, 0f)
                            objectAnimator.duration = 2000
                        }
                        R.id.rb_alpha -> {
                            val holder = PropertyValuesHolder.ofFloat("alpha", 1f, 0.1f, 1f)
                            animator = ObjectAnimator.ofPropertyValuesHolder(ivLike, holder)
                            animator.setTarget(ivLike)
                            animator.duration = 2000
                            btnAnimator.text = rb_alpha.text
                            val keyframe = Keyframe.ofFloat(0f, 1f)
                            val keyframe2 = Keyframe.ofFloat(0.5f, 0.1f)
                            val keyframe3 = Keyframe.ofFloat(1f, 1f)
                            val holder2 = PropertyValuesHolder.ofKeyframe("alpha", keyframe, keyframe2, keyframe3)
                            objectAnimator = ObjectAnimator.ofPropertyValuesHolder(ivLike, holder2)
                            objectAnimator.duration = 2000
                        }
                        R.id.rb_color -> {
                            val drawable = ContextCompat.getDrawable(this@AnimatorActivity, R.drawable.ic_like) as VectorDrawable
                            animator = ValueAnimator.ofArgb(0xffff0066.toInt(), 0x1100ffff, 0xffff0000.toInt())
                            animator.addUpdateListener {
                                drawable.setTint(it.animatedValue as Int)
                                ivLike.setImageDrawable(drawable)
                            }
                            animator.duration = 3000
                            btnAnimator.text = rb_color.text
                            objectAnimator = ObjectAnimator.ofObject(drawable, "tint", ArgbEvaluator(), 0xffff0066.toInt(), 0x1100ffff, 0xffff0000.toInt())
                            objectAnimator.addUpdateListener {
                                ivLike.setImageDrawable(drawable)
                            }
                            objectAnimator.duration = 2000
                        }
                        R.id.rb_digit -> {
                            animator = ValueAnimator.ofObject(object : TypeEvaluator<Char> {
                                override fun evaluate(fraction: Float, startValue: Char?, endValue: Char?): Char {
                                    val startInt = startValue?.toInt() ?: 0
                                    val endInt = endValue?.toInt() ?: 1
                                    return (startInt + fraction * (endInt - startInt)).toChar()
                                }
                            }, 'A', 'Z')
                            animator.addUpdateListener {
                                btnAnimator.text = it.animatedValue.toString()
                                btnAnimator.textSize = 16f + ((it.animatedValue as Char).toFloat() - 'A'.toFloat())
                            }
                            animator.duration = 2000

                            objectAnimator = ObjectAnimator.ofObject(btnAnimator, "text", object : TypeEvaluator<String> {
                                override fun evaluate(fraction: Float, startValue: String?, endValue: String?): String {
                                    val startInt = startValue?.toCharArray()!![0].toInt()
                                    val endInt = endValue?.toCharArray()!![0].toInt()
                                    Log.d("=====", "start = $startInt , end = $endInt, return = " + (startInt + fraction * (endInt - startInt)).toChar().toString())
                                    return (startInt + fraction * (endInt - startInt)).toChar().toString()
                                }

                            }, "A", "Z")
                            objectAnimator.duration = 2000
                        }
                        else -> {
                            animator = ValueAnimator.ofArgb(0xff0066, 0x00ffff)
                            animator.addUpdateListener {
                                (ivLike.background as VectorDrawable).setTint(it.animatedValue as Int)
                            }
                            animator.duration = 2000
                            btnAnimator.text = rb_color.text
                        }
                    }

                    selectAnimatorDialog.dismiss()
                }
            }
        }
    }

    private fun initDefaultAnimator() {
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 2000
            addUpdateListener {
                val value = it.animatedValue as Float
                ivLike.rotation = value
                ivLike.rotationX = value
                ivLike.rotationY = value
            }
        }

        objectAnimator = ObjectAnimator.ofObject(ivLike, "rotation", FloatEvaluator(), 0f, 360f)
        objectAnimator.duration = 2000
    }

    private fun initView() {
        btnAnimator = btn_choose_animator
        ivLike = iv_like
        traceView = trace_view
    }

    /**
     * 绘制心形Path
     */
    private fun getHeartPath() {
        //获取控件当前位置
        val startLoc = IntArray(2)
        ivLike.getLocationInWindow(startLoc)

        //获取被围绕控件的起始点
        val parentStart = IntArray(2)
        ivLike.getLocationInWindow(parentStart)

        val h = ivLike.height
        val halfW = ivLike.width / 2

        //获取被围绕坐标的终点
        val parentEnd = IntArray(2)
        parentEnd[0] = parentStart[0] + ivLike.width + 100
        parentEnd[1] = parentStart[1] + ivLike.height
        val path = getHeartPath((startLoc[0] + halfW).toFloat(), (startLoc[1] + h).toFloat())

        //pathMeasure用来计算显示坐标
        pathMeasure = PathMeasure(path, false)

        //属性动画加载
        val valueAnimator = ValueAnimator.ofFloat(0f, 180f)

        //设置动画时长
        valueAnimator.duration = 60000

        //加入差值器
        valueAnimator.interpolator = AccelerateDecelerateInterpolator()

        //设置无限次循环
        valueAnimator.repeatCount = ValueAnimator.INFINITE

        pathMeasure.getPosTan(0f, mCurrentPosition, null)
//        traceView.init(mCurrentPosition[0], mCurrentPosition[1], false)

        val size = getScreenSize()
        val width = size.x
        val height = size.y
        traceView.init((width / 2).toFloat(), (height / 3 - h).toFloat(), false)

        //添加监听
        valueAnimator.addUpdateListener { animation ->
            //获取当前位置
            val value = animation.animatedValue as Float
            //boolean getPosTan(float distance, float[] pos, float[] tan) ：
            //传入一个距离distance(0<=distance<=getLength())，然后会计算当前距
            // 离的坐标点和切线，pos会自动填充上坐标
            pathMeasure.getPosTan(value, mCurrentPosition, null)
            //设置视图坐标
//            ivLike.x = mCurrentPosition[0] - halfW
//            ivLike.y = mCurrentPosition[1] - h
//            traceView.draw(mCurrentPosition[0], mCurrentPosition[1])

            val p = getHeartPoint(value, width / 2, height / 3)
            ivLike.x = (p.x - halfW).toFloat()
            ivLike.y = (p.y - h).toFloat()
            traceView.draw(p.x.toFloat(), p.y.toFloat())
        }

        valueAnimator.start()
    }

    /**
     * 构建心形
     */
    private fun getHeartPath(x: Float, y: Float): Path {
        val path = Path()
        path.moveTo(x, y)
        path.cubicTo(x - 220f, y - 200f, x - 50f, y - 267f, x, y - 150f)
        path.cubicTo(x + 50f, y - 267f, x + 220f, y - 200f, x, y)
        return path
    }

    private fun getHeartPoint(angle: Float, offsetX: Int, offsetY: Int): Point {
        val t = (angle / Math.PI).toFloat()
        val x = (19.5 * (16 * Math.pow(Math.sin(t.toDouble()), 3.0))).toFloat()
        val y = (-20 * (13 * Math.cos(t.toDouble()) - 5 * Math.cos((2 * t).toDouble()) - 2 * Math.cos((3 * t).toDouble()) - Math.cos((4 * t).toDouble()))).toFloat()
        return Point(offsetX + x.toInt(), offsetY + y.toInt())
    }

    /**
     * 构建椭圆
     */
    @Suppress("unused")
    private fun drawOvalPath(parentStart: IntArray, parentEnd: IntArray): Path {
        val path = Path()
        //椭圆大小需自己调整
        val rectF = RectF((parentStart[0] - 120).toFloat(), (parentStart[1] - 220).toFloat(), (parentEnd[0] + 100).toFloat(), parentEnd[1].toFloat())
        path.addArc(rectF, 0f, 360f)

        //设置椭圆倾斜度数
        val matrix = Matrix()
        matrix.setRotate(-14f, (parentStart[0] + parentEnd[0]) / 2f, (parentStart[1] + parentEnd[1]) / 2f)
        path.transform(matrix)
        return path
    }

    private fun alpha(view: View) {
        view.animate().alpha(0.1f).alpha(1f).duration = 2000
    }

    private fun rotate(view: View) {
        view.animate().rotation(360f).duration = 2000
    }

    private fun rotateX(view: View) {
        view.animate().rotationX(360f).duration = 2000
    }

    private fun rotateY(view: View) {
        view.animate().rotationY(360f).duration = 2000
    }

    private fun scaleX(view: View) {
        view.animate().scaleX(2f).scaleX(1f).duration = 2000
    }

    private fun scaleY(view: View) {
        view.animate().scaleY(2f).scaleY(1f).duration = 2000
    }
}