package me.fresh.lee.kotlintest.widget

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.ViewAnimator
import me.fresh.lee.kotlintest.R
import me.fresh.lee.kotlintest.adapter.RollingTextAdapter

/**
 * Created by lihuayong on 2018/9/21.
 */
class TextViewSwitcher : ViewAnimator {

    private val TAG = "TextViewSwitcher"

    private var mFlipInterval = 1000
    /**
     * 动画切换时间间隔
     */
    private var mDuration = 500

    private var mAutoStart = false

    private var mVisible = false

    private var mStarted = false
    private var mRunning = false
    private var mCurItem = 0

    private var mAdapter: RollingTextAdapter? = null
    private var mListener: OnItemClickListener? = null

    private var mContext: Context? = null

    constructor(context: Context?) : super(context) {
        mContext = context
        init()
    }

    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs) {
        mContext = context
        init()
    }

    /**
     * Start a timer to cycle through child views
     * without show animation.
     */
    fun startFlipping() {
        mStarted = true
        updateRunning(false)
    }

    /**
     * No more flips
     */
    fun stopFlipping() {
        mStarted = false
        updateRunning()
    }

    private fun init() {
        setFlipInterval(mFlipInterval)
        setInAnimation(mContext, R.anim.rolling_text_in)
        setOutAnimation(mContext, R.anim.rolling_text_out)
        setAutoStart(false)
    }

    /**
     * load subview
     */
    private fun start() {
        if (this.mAdapter == null || this.mAdapter!!.getCount() <= 0) {
            throw IllegalStateException("should set Adapter first!")
        }
        removeAllViews()

        if (mAdapter!!.getCount() > 2)
            setAutoStart(true)
        else
            setAutoStart(false)
        var i = 0
        while (i < this.mAdapter!!.getCount()) {
            val view = this.mAdapter!!.getView(context, i)
            addView(view)
            if (mListener != null) {
                view.tag = i
                view.setOnClickListener { view -> mListener!!.onClick(view.tag as Int) }
            }
            i += 2
        }
    }

    private fun setAutoStart(autoStart: Boolean) {
        this.mAutoStart = autoStart
    }

    private fun updateRunning() {
        updateRunning(true)
    }


    private fun updateRunning(flipNow: Boolean) {
        val running = mVisible && mStarted
        if (running != mRunning) {
            if (running) {
                showOnly(mCurItem, flipNow)
                postDelayed(mRollRunnable, mFlipInterval.toLong())
            } else {
                removeCallbacks(mRollRunnable)
            }
            mRunning = running
        }
    }

    /**
     * 在布局中只显示当前id的子view，其他view不显示
     * @param childIndex 子view的id
     * @param animate 是否要显示动画
     */
    private fun showOnly(childIndex: Int, animate: Boolean) {
        val count = childCount
        for (i in 0 until count) {
            val child = getChildAt(i)
            if (i == childIndex) {
                if (animate && inAnimation != null) {
                    child.startAnimation(inAnimation)
                }
                child.visibility = View.VISIBLE
            } else {
                if (animate && outAnimation != null && child.visibility == View.VISIBLE) {
                    child.startAnimation(outAnimation)
                } else if (child.animation === inAnimation)
                    child.clearAnimation()
                child.visibility = View.GONE
            }
        }
    }

    fun setFlipInterval(flipInterval: Int) {
        this.mFlipInterval = flipInterval
    }


    fun setAdapter(adapter: RollingTextAdapter){
        mAdapter = adapter
        start()
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.mListener = listener
    }

    private val mRollRunnable = object : Runnable {
        override fun run() {
            if (mRunning) {
                mCurItem = if (mCurItem == childCount - 1) 0 else mCurItem + 1
                showNext()
                postDelayed(this, mFlipInterval.toLong())
            }
        }
    }

    override fun removeAllViews() {
        super.removeAllViews()
        mCurItem = 0
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (mAutoStart) {
            startFlipping()
        }
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        mVisible = false
        updateRunning()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        mVisible = visibility == View.VISIBLE
        updateRunning(false)

    }

    interface OnItemClickListener {
        fun onClick(position: Int)
    }
}