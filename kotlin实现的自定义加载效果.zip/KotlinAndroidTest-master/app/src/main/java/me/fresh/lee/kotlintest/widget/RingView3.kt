package me.fresh.lee.kotlintest.widget


import android.animation.ObjectAnimator
import android.animation.TimeInterpolator
import android.content.Context
import android.content.res.TypedArray
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Region
import android.os.Bundle
import android.os.Parcelable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.annotation.Keep
import androidx.core.content.ContextCompat
import me.fresh.lee.kotlintest.R

/**
 *
 * @description    RingView 环状图
 * @author         lihuayong
 * @date           2019-08-16 17:51
 * @version        1.0
 */
class RingView3 @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    companion object {
        const val DEFAULT_ANIMATION_DURATION = 500L
        const val NO_ITEM_SELECT = -1
        const val DEFAULT_EXTRA_WIDTH = 20f
    }

    /**
     * 动画进度控制
     */
    private val mProgressAnimator: ObjectAnimator = ObjectAnimator.ofFloat(this, "progress", 0f, 1f)
            .apply {
                duration = DEFAULT_ANIMATION_DURATION
                this.interpolator = DecelerateInterpolator()
            }
    private var mProgress: Float = 1f
    /**
     * 圆环宽度
     */
    private var mArcWidth: Float = 0f

    /**
     * 选中状态下额外的宽度
     */
    private var mExtraWidth: Float = DEFAULT_EXTRA_WIDTH

    private var mOuterRadius: Float = 0f
    private var mInnerRadius = 0f

    /**
     * 图形中心点
     */
    private var mCenterX = 0f
    private var mCenterY = 0f

    /**
     * 绘制圆弧的画笔和Path
     */
    private lateinit var mArcPath: Path
    private lateinit var mArcPaint: Paint

    /**
     * 外圆的外接矩形
     */
    private lateinit var mOuterRect: RectF

    /**
     * 内圆的外接矩形
     */
    private lateinit var mInnerRect: RectF

    /**
     * 选中状态下的外接矩形
     */
    private lateinit var mBigRectF: RectF
    private lateinit var mSmallRectF: RectF

    /**
     * 点击区域检测辅助region
     */
    private var mRegion: ArrayList<Region>?= null
    private lateinit var clip: Region

    /**
     * 被选中的item id
     */
    private var onSelectId: Int = NO_ITEM_SELECT

    /**
     * 被选中触发的回调事件
     */
    private var onSelectListener: ((selectId: Int, index: Int) -> Unit)? = null

    private var mDataArray: FloatArray? = null
    private var mColorArray: IntArray = intArrayOf(R.color.j_yellow, R.color.green, R.color.f_link, R.color.wrong_red, R.color.brown_bright)

    init {
        init(context, attrs, defStyleAttr)
        initPaint()
    }

    private fun init(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) {
        val ta: TypedArray = context!!.obtainStyledAttributes(attrs, R.styleable.RingView, defStyleAttr, 0)
        mArcWidth = ta.getDimensionPixelOffset(R.styleable.RingView_rv_arcWidth, context.resources.getDimensionPixelOffset(R.dimen.dp_20)).toFloat()
        mExtraWidth = ta.getDimensionPixelOffset(R.styleable.RingView_rv_extraWidth, DEFAULT_EXTRA_WIDTH.toInt()).toFloat()
        mOuterRadius = ta.getDimensionPixelOffset(R.styleable.RingView_rv_circleRadius, context.resources.getDimensionPixelOffset(R.dimen.margin_100)).toFloat()
        setAnimatorDuration(ta.getInteger(R.styleable.RingView_rv_duration, DEFAULT_ANIMATION_DURATION.toInt()).toLong())
        mInnerRadius = mOuterRadius - mArcWidth

        if (isInEditMode) {
            mDataArray = floatArrayOf(0.1f, 0.2f, 0.3f, 0.4f)
            onSelectId = 0
        }

        if (mInnerRadius <= 0) {
            throw IllegalArgumentException("circleRadius must set bigger than arcWidth!!!")
        }

        if (mInnerRadius < mExtraWidth) {
            throw IllegalArgumentException("circleRadius suggest set bigger than sum of arcWidth and extraWidth)!!!")
        }
        ta.recycle()
    }

    private fun initPaint() {
        mArcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL_AND_STROKE
        }

        mOuterRect = RectF()

        mInnerRect = RectF()

        mBigRectF = RectF()

        mSmallRectF = RectF()

        mArcPath = Path()

        clip = Region()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val size = ((mOuterRadius + mExtraWidth) * 2).toInt()
        setMeasuredDimension(measureView(widthMeasureSpec, size + paddingLeft + paddingRight),
                measureView(heightMeasureSpec, size + paddingTop + paddingBottom))
    }

    private fun measureView(measureSpec: Int, defaultSize: Int): Int {
        var result: Int
        val specMode = MeasureSpec.getMode(measureSpec)
        val specSize = MeasureSpec.getSize(measureSpec)
        if (specMode == MeasureSpec.EXACTLY) {
            result = specSize
        } else {
            result = defaultSize
            if (specMode == MeasureSpec.AT_MOST) {
                result = Math.min(result, specSize)
            }
        }
        return result
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        mOuterRadius = (Math.min(w - paddingLeft - paddingRight, h - paddingTop - paddingBottom) shr 1).toFloat() - mExtraWidth
        mCenterX = (w shr 1).toFloat()
        mCenterY = (h shr 1).toFloat()
        clip.set(-w, -h, w, h)

        setRectAndRadii()
    }

    private fun setRectAndRadii() {
        mInnerRadius = mOuterRadius - mArcWidth

        mOuterRect.set(-mOuterRadius, -mOuterRadius, mOuterRadius, mOuterRadius)

        mInnerRect.set(-mInnerRadius, -mInnerRadius, mInnerRadius, mInnerRadius)

        mBigRectF.set(-mOuterRadius - mExtraWidth,
                -mOuterRadius - mExtraWidth,
                mOuterRadius + mExtraWidth,
                mOuterRadius + mExtraWidth)

        mSmallRectF.set(-mInnerRadius + mExtraWidth,
                -mInnerRadius + mExtraWidth,
                mInnerRadius - mExtraWidth,
                mInnerRadius - mExtraWidth)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        canvas.translate(mCenterX, mCenterY)
        mDataArray?.let {
            var accumulateDegree = -90f
            for ((index, e) in it.withIndex()) {
                //将数据从百分比转化为度数（不是弧度！）
                val sweepAngle = e * 359.9f * mProgress
                mArcPaint.color = ContextCompat.getColor(context, mColorArray[index % mColorArray.size])

                resetArcPath(accumulateDegree, sweepAngle, index == onSelectId)
                mRegion?.get(index)?.setPath(mArcPath, clip)
                canvas.drawPath(mArcPath, mArcPaint)

                accumulateDegree += sweepAngle
            }
        }

        canvas.translate(-mCenterX, -mCenterY)
    }

    /**
     * @param degree 圆弧的度数
     * @param selected 是否被选中
     */
    private fun resetArcPath(startAngle: Float, degree: Float, selected: Boolean) {
        //保证从顶部开始绘制，因为Path的0度默认是x轴，所以设置开始角度为-90度，从上面开始绘制
        mArcPath.reset()
//        val startAngle = -90f
        //如果是选中的item 则展示选中状态
        if (selected) {
            /**
             * Path.arcTo 妙用
             * Append the specified arc to the path as a new contour. If the start of
             * the path is different from the path's current last point, then an
             * automatic lineTo() is added to connect the current contour to the
             * start of the arc. However, if the path is empty, then we call moveTo()
             * with the first point of the arc.
             *
             */
            mArcPath.arcTo(mBigRectF, startAngle, degree, false)
            mArcPath.arcTo(mSmallRectF, startAngle + degree, -degree, false)
        } else {
            mArcPath.arcTo(mOuterRect, startAngle, degree, false)
            mArcPath.arcTo(mInnerRect, startAngle + degree, -degree, false)
        }
        mArcPath.close()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (MotionEvent.ACTION_DOWN == event.action) {
            val x = event.x
            val y = event.y
            run breaking@{
                mRegion?.forEachIndexed { index, region ->
                    if (region.contains((x - mCenterX).toInt(), (y - mCenterY).toInt())) {
                        onSelectId = if (onSelectId == index) {
                            NO_ITEM_SELECT
                        } else {
                            index
                        }

                        invalidate()
                        onSelectListener?.invoke(onSelectId, index)
                        return@breaking
                    }
                }
            }
        }

        return super.onTouchEvent(event)
    }

    /**
     * 设置颜色数组
     */
    @Suppress("unused")
    fun setColorArray(colors: IntArray?) {
        colors?.let {
            this.mColorArray = it
        }
    }

    fun setOnSelectListener(listener: (selectId: Int, index: Int) -> Unit) {
        this.onSelectListener = listener
    }

    fun setArcWidth(arcWidth: Float) {
        this.mArcWidth = arcWidth
        setRectAndRadii()
        postInvalidate()
    }

    fun setExtraWidth(extraWidth: Float) {
        this.mExtraWidth = extraWidth
        setRectAndRadii()
        postInvalidate()
    }

    fun setAnimatorDuration(duration: Long) {
        mProgressAnimator.duration = duration
    }

    @Suppress("unused")
    fun setAnimatorInterpolator(interpolator: TimeInterpolator) {
        mProgressAnimator.interpolator = interpolator
    }

    fun setData(list: List<Float>?, animate: Boolean = true) {
        setData(list?.toFloatArray(), animate)
    }

    /**
     * 动画进度控制
     */
    @Keep
    @Suppress("unused")
    private fun setProgress(progress: Float) {
        this.mProgress = progress
        invalidate()
    }

    /**
     * @param dataArr 数据源
     * @param animate 是否展示动画
     */
    fun setData(dataArr: FloatArray?, animate: Boolean = true) {
        dataArr?.let {
            onSelectId = NO_ITEM_SELECT
            mDataArray = transformData(dataArr)

            if (!animate) {
                invalidate()
                return
            }

            startAnimation()
        }
    }

    fun startAnimation() {
        onSelectId = NO_ITEM_SELECT

        mProgressAnimator.let {
            if (it.isRunning) {
                it.cancel()
            }

            it.start()
        }
    }

    /**
     * 转化数据，并且初始化辅助Region数组
     */
    private fun transformData(data: FloatArray): FloatArray {
        val sum = data.sum()
        val array = FloatArray(data.size)
        data.forEachIndexed { index, d ->
            array[index] = d / sum
            mRegion?.add(Region())
        }
        return array
    }


    override fun onSaveInstanceState(): Parcelable? {
        val data = Bundle()
        data.putParcelable("superData", super.onSaveInstanceState())
        data.putFloatArray("data_array", mDataArray)
        return data
    }

    override fun onRestoreInstanceState(state: Parcelable) {
        val data = state as Bundle
        val superData = data.getParcelable<Parcelable>("superData")
        super.onRestoreInstanceState(superData)

        mDataArray = data.getFloatArray("data_array")
        initPaint()
        startAnimation()
    }
}