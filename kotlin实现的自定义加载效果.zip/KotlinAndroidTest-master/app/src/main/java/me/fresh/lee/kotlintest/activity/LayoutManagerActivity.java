package me.fresh.lee.kotlintest.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import me.fresh.lee.kotlintest.widget.CustomLayoutManagerRemould2;

/**
 * @author lihuayong
 * @version 1.0
 * @description LayoutManagerActivity
 * @date 2019-08-08 14:38
 */
public class LayoutManagerActivity extends AppCompatActivity {

    private static final int DATA_SIZE = 50;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        RecyclerView recyclerView = new RecyclerView(this);
        recyclerView.setLayoutManager(new CustomLayoutManagerRemould2());

        SimpleAdapter adapter = new SimpleAdapter();
        adapter.setData(generateTestData());
        recyclerView.setAdapter(adapter);

        setContentView(recyclerView);

    }

    private List<String> generateTestData() {
        List<String> testData = new ArrayList<>();
        for (int i = 0; i < DATA_SIZE; i++) {
            testData.add(String.format(Locale.getDefault(), "第%d条数据", i));
        }
        return testData;
    }


    private class SimpleAdapter extends RecyclerView.Adapter<ViewHolder> {

        private List<String> data;

        void setData(List<String> list) {
            data = list;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

            log("onCreateViewHolder");
            return new ViewHolder(new TextView(parent.getContext()));
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            log("onBindViewHolder : " + position);

            holder.bind(data.get(position));
        }

        @Override
        public int getItemCount() {
            return data == null ? 0 : data.size();
        }
    }

    private class ViewHolder extends RecyclerView.ViewHolder {

        private TextView textView;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = (TextView) itemView;
            RecyclerView.LayoutParams layoutParams = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 100);
            textView.setGravity(Gravity.CENTER);
            textView.setLayoutParams(layoutParams);
        }

        void bind(CharSequence s) {
            textView.setText(s);
        }
    }

    void log(String s) {
        Log.d("LayoutManager", s);
    }
}


