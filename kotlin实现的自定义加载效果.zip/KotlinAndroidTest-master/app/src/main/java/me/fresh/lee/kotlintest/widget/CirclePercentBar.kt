package me.fresh.lee.kotlintest.widget

import android.animation.ValueAnimator
import android.content.Context
import android.content.res.TypedArray
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import androidx.core.content.ContextCompat
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import me.fresh.lee.kotlintest.R
import me.fresh.lee.kotlintest.util.RaFloatArrayEvaluator


/**
 *
 * @Description:
 * @Author:         lihuayong
 * @CreateDate:     2019/2/15 下午3:21
 * @UpdateUser:
 * @UpdateDate:     2019/2/15 下午3:21
 * @UpdateRemark:
 * @Version:        1.0
 */
class CirclePercentBar : View {
    private var mArcWidth: Float = 0f
    private var mCircleRadius: Int = 0

    private lateinit var arcCirclePaint: Paint
    private lateinit var arcPaint: Paint
    private lateinit var arcRectF: RectF

    private var mDataArray: FloatArray? = null
    private var mColorArray: IntArray = intArrayOf(R.color.j_yellow, R.color.green, R.color.f_link, R.color.wrong_red, R.color.brown_bright)

    constructor(context: Context) : this(context, null)

    constructor(context: Context, attrs: AttributeSet?) : this(context, attrs, 0)

    constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        init(context, attrs, defStyleAttr)
        initPaint()
    }

    private fun init(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) {
        val ta: TypedArray = context!!.obtainStyledAttributes(attrs, R.styleable.CirclePercentBar, defStyleAttr, 0)
        mArcWidth = ta.getDimensionPixelOffset(R.styleable.CirclePercentBar_arcWidth, context.resources.getDimensionPixelOffset(R.dimen.dp_20)).toFloat()
        mCircleRadius = ta.getDimensionPixelOffset(R.styleable.CirclePercentBar_circleRadius, context.resources.getDimensionPixelOffset(R.dimen.margin_100))
        ta.recycle()

        if (isInEditMode) {
            mDataArray = floatArrayOf(60f, 10f, 25f, 5f)
        }
    }

    private fun initPaint() {
        arcCirclePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = mArcWidth
            color = ContextCompat.getColor(context, R.color.white)
            strokeCap = Paint.Cap.ROUND
        }

        arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = mArcWidth
            strokeCap = Paint.Cap.BUTT
        }

        //圆弧的外接矩形
        arcRectF = RectF()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        setMeasuredDimension(measureView(widthMeasureSpec), measureView(heightMeasureSpec))
    }

    private fun measureView(measureSpec: Int): Int {
        var result: Int
        val specMode = View.MeasureSpec.getMode(measureSpec)
        val specSize = View.MeasureSpec.getSize(measureSpec)
        if (specMode == View.MeasureSpec.EXACTLY) {
            result = specSize
        } else {
            result = mCircleRadius * 2
            if (specMode == View.MeasureSpec.AT_MOST) {
                result = Math.min(result, specSize)
            }
        }
        return result
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        arcRectF.set((width shr 1) - mCircleRadius + mArcWidth / 2,
                (height shr 1) - mCircleRadius + mArcWidth / 2,
                (width shr 1) + mCircleRadius - mArcWidth / 2,
                (height shr 1) + mCircleRadius - mArcWidth / 2)
        canvas.drawArc(arcRectF, 0f, 360f, false, arcCirclePaint)

        if (mDataArray == null) {
            return
        }
        //ensure start to draw on the top
        canvas.rotate(-90f, (width shr 1).toFloat(), (height shr 1).toFloat())

        var acc = 0f
        for ((index, e) in mDataArray!!.withIndex()) {
            arcPaint.color = ContextCompat.getColor(context, mColorArray[index % mColorArray.size])
            canvas.drawArc(arcRectF, 360 * acc / 100, 360 * e / 100, false, arcPaint)
            acc += e
        }

        //rotate back
        canvas.rotate(90f, (width shr 1).toFloat(), (height shr 1).toFloat())
    }

    fun setData(dataArr: FloatArray, animate: Boolean) {
        mDataArray = dataArr
        if (!animate) {
            invalidate()
            return
        }

        ValueAnimator.ofObject(RaFloatArrayEvaluator(), FloatArray(dataArr.size), dataArr).apply {
            duration = 500L
            addUpdateListener {
                val values = animatedValue as FloatArray
                mDataArray = values
                invalidate()
            }
            interpolator = DecelerateInterpolator()
        }.start()
    }
}