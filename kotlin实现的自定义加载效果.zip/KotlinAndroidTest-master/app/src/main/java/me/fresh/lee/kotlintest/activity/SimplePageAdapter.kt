package me.fresh.lee.kotlintest.activity

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentStatePagerAdapter
import me.fresh.lee.kotlintest.activity.draw.SimpleFragment

/**
 *
 * @description    SimplePageAdapter
 * @author         lihuayong
 * @date           2019-08-15 16:23
 * @version        1.0
 */
class SimplePageAdapter(fm: FragmentManager, private val titles: List<String>) : FragmentStatePagerAdapter(fm) {
    override fun getItem(position: Int): Fragment {
        val fragment = SimpleFragment()
        return when (position) {
            0 -> fragment.apply { setData(100) }
            1 -> fragment.apply { setData(5) }
            2 -> fragment.apply { setData(1) }
            else -> fragment.apply { setData(100) }
        }
    }

    override fun getCount(): Int {
        return 3
    }

    override fun getPageTitle(position: Int): CharSequence? {
        return titles[position]
    }
}