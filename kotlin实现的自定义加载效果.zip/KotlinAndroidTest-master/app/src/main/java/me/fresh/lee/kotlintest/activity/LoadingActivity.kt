package me.fresh.lee.kotlintest.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_point_rotation.loading_view
import me.fresh.lee.kotlintest.R

/**
 *
 * @description    LoadingActivity
 * @author         lihuayong
 * @date           2019-08-30 11:13
 * @version        1.0
 */
class LoadingActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_point_rotation)

        loading_view.setOnClickListener {
            loading_view.start()
        }
    }
}