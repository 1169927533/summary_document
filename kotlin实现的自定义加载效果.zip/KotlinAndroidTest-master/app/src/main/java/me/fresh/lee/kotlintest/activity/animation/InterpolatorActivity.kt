package me.fresh.lee.kotlintest.activity.animation

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.AccelerateInterpolator
import android.view.animation.AnticipateOvershootInterpolator
import android.view.animation.BounceInterpolator
import android.view.animation.CycleInterpolator
import android.view.animation.Interpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.view.animation.PathInterpolator
import android.widget.Button
import android.widget.RadioGroup
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomsheet.BottomSheetDialog
import kotlinx.android.synthetic.main.activity_interpolator.btn_interpolator
import kotlinx.android.synthetic.main.activity_interpolator.btn_path
import kotlinx.android.synthetic.main.activity_interpolator.btn_start
import kotlinx.android.synthetic.main.activity_interpolator.coordinate_view
import kotlinx.android.synthetic.main.activity_interpolator.seekBar1
import kotlinx.android.synthetic.main.activity_interpolator.seekBar2
import kotlinx.android.synthetic.main.activity_interpolator.seekBar3
import kotlinx.android.synthetic.main.activity_interpolator.seekBar4
import kotlinx.android.synthetic.main.activity_interpolator.trace_view
import kotlinx.android.synthetic.main.dialog_select_interpolator.rb_acc
import kotlinx.android.synthetic.main.dialog_select_interpolator.rb_acc_dec
import kotlinx.android.synthetic.main.dialog_select_interpolator.rb_anti_overshoot
import kotlinx.android.synthetic.main.dialog_select_interpolator.rb_bounce
import kotlinx.android.synthetic.main.dialog_select_interpolator.rb_cycle
import kotlinx.android.synthetic.main.dialog_select_interpolator.rb_linear
import kotlinx.android.synthetic.main.dialog_select_interpolator.rb_overshoot
import me.fresh.lee.kotlintest.R
import me.fresh.lee.kotlintest.widget.CoordinateView

class InterpolatorActivity : AppCompatActivity() {

    private lateinit var selectInterpolatorDialog: BottomSheetDialog

    private lateinit var radioGroup: RadioGroup

    private lateinit var interpolator: Interpolator

    private lateinit var btnInterpolator: Button

    private var controlX: Float = 0f
    private var controlY: Float = 0f
    private var controlX2: Float = 0f
    private var controlY2: Float = 0f

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_interpolator)
        btnInterpolator = btn_interpolator

        selectInterpolatorDialog = BottomSheetDialog(this).apply {
            setContentView(R.layout.dialog_select_interpolator)
            window?.decorView?.apply {
                radioGroup = findViewById(R.id.radio_group)
                radioGroup.setOnCheckedChangeListener { _, checkedId ->
                    when (checkedId) {
                        R.id.rb_linear -> {
                            interpolator = LinearInterpolator()
                            btnInterpolator.text = rb_linear.text
                        }
                        R.id.rb_acc -> {
                            interpolator = AccelerateInterpolator()
                            btnInterpolator.text = rb_acc.text
                        }
                        R.id.rb_acc_dec -> {
                            interpolator = AccelerateDecelerateInterpolator()
                            btnInterpolator.text = rb_acc_dec.text
                        }
                        R.id.rb_bounce -> {
                            interpolator = BounceInterpolator()
                            btnInterpolator.text = rb_bounce.text
                        }
                        R.id.rb_overshoot -> {
                            interpolator = OvershootInterpolator()
                            btnInterpolator.text = rb_overshoot.text
                        }
                        R.id.rb_anti_overshoot -> {
                            interpolator = AnticipateOvershootInterpolator()
                            btnInterpolator.text = rb_anti_overshoot.text
                        }
                        R.id.rb_cycle -> {
                            interpolator = CycleInterpolator(2f)
                            btnInterpolator.text = rb_cycle.text
                        }
                        else -> {
                            interpolator = LinearInterpolator()
                            btnInterpolator.text = rb_linear.text
                        }
                    }

                    selectInterpolatorDialog.dismiss()
                }
            }
        }

        interpolator = LinearInterpolator()

        btn_start.setOnClickListener {
            trace_view.start(interpolator)
            coordinate_view.setFunction(object : CoordinateView.Function {
                override fun f(x: Float): Float {
                    return interpolator.getInterpolation(x)
                }
            })
            coordinate_view.reDraw()
        }

        btn_interpolator.setOnClickListener {
            selectInterpolatorDialog.show()
        }

        seekBar1.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                controlX = progress.toFloat()
            }

        })

        seekBar2.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                controlY = progress.toFloat()
            }

        })

        seekBar3.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                controlX2 = progress.toFloat()
            }

        })

        seekBar4.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                controlY2 = progress.toFloat()
            }

        })

        btn_path.setOnClickListener {
            btnInterpolator.text = "Bezier Curve"
            interpolator = PathInterpolator(controlX / 100f, controlY / 100f, controlX2 / 100f, controlY2 / 100f)
            trace_view.start(interpolator)
            coordinate_view.setFunction(object : CoordinateView.Function {
                override fun f(x: Float): Float {
                    return interpolator.getInterpolation(x)
                }
            })
            coordinate_view.reDraw()
        }

        coordinate_view.setFunction(object : CoordinateView.Function {
            override fun f(x: Float): Float {
                return interpolator.getInterpolation(x)
            }
        })
    }
}