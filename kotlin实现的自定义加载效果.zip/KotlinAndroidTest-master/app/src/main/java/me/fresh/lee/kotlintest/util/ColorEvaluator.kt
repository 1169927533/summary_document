package me.fresh.lee.kotlintest.util

import android.animation.TypeEvaluator


/**
 *
 * @Description:
 * @Author:         lihuayong
 * @CreateDate:     2019/2/21 下午3:00
 * @UpdateUser:
 * @UpdateDate:     2019/2/21 下午3:00
 * @UpdateRemark:
 * @Version:        1.0
 */
class ColorEvaluator : TypeEvaluator<String> {

    private var mCurrentR = -1
    private var mCurrentG = -1
    private var mCurrentB = -1

    override fun evaluate(fraction: Float, startValue: String, endValue: String): String {
        val sR: Int = startValue.substring(1, 3).toInt(16)
        val sG: Int = startValue.substring(3, 5).toInt(16)
        val sB: Int = startValue.substring(5, 7).toInt(16)

        val eR: Int = endValue.substring(1, 3).toInt(16)
        val eG: Int = endValue.substring(3, 5).toInt(16)
        val eB: Int = endValue.substring(5, 7).toInt(16)

        if (mCurrentR == -1) {
            mCurrentR = sR
        }
        if (mCurrentG == -1) {
            mCurrentG = sG
        }
        if (mCurrentB == -1) {
            mCurrentB = sB
        }

        val diffR = Math.abs(sR - eR)
        val diffG = Math.abs(sG - eG)
        val diffB = Math.abs(sB - eB)
        val colorDiff = diffR + diffG + diffB

        if (mCurrentR != eR) {
            mCurrentR = getCurrentColor(sR, eR, colorDiff, 0, fraction)
        } else if (mCurrentG != eG) {
            mCurrentR = getCurrentColor(sG, eG, colorDiff, diffR, fraction)
        } else if (mCurrentB != eB) {
            mCurrentB = getCurrentColor(sB, eB, colorDiff, diffR + diffG, fraction)
        }

        return "#" + getHexString(mCurrentR) + getHexString(mCurrentG) + getHexString(mCurrentB)

    }

    private fun getCurrentColor(startColor: Int, endColor: Int, colorDiff: Int, offset: Int, fraction: Float): Int {
        var currentColor: Int
        if (startColor > endColor) {
            currentColor = (startColor - (fraction * colorDiff - offset)).toInt()
            if (currentColor < endColor) {
                currentColor = endColor
            }
        } else {
            currentColor = (startColor + (fraction * colorDiff - offset)).toInt()
            if (currentColor > endColor) {
                currentColor = endColor
            }
        }
        return currentColor
    }

    /**
     * 将10进制颜色值转换成16进制。
     */
    private fun getHexString(value: Int): String {
        var hexString = Integer.toHexString(value)
        if (hexString.length == 1) {
            hexString = "0$hexString"
        }
        return hexString
    }
}