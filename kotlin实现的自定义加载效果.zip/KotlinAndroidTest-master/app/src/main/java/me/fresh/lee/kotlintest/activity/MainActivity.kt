package me.fresh.lee.kotlintest.activity

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import me.fresh.lee.kotlintest.R
import me.fresh.lee.kotlintest.activity.animation.AnimationActivity
import me.fresh.lee.kotlintest.activity.animation.AnimatorActivity
import me.fresh.lee.kotlintest.activity.animation.InterpolatorActivity
import me.fresh.lee.kotlintest.activity.animation.LayoutChangeActivity
import me.fresh.lee.kotlintest.activity.animation.LikeButtonActivity
import me.fresh.lee.kotlintest.activity.draw.*
import me.fresh.lee.kotlintest.widget.RingView

/**
 *
 * @description    MainActivity
 * @author         lihuayong
 * @date           2019-07-04 11:33
 * @version        1.0
 */
class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btn_test.setOnClickListener {
            navigation(TestActivity::class.java)
        }

        btn_interpolator.setOnClickListener {
            navigation(InterpolatorActivity::class.java)
        }

        btn_animation.setOnClickListener {
            navigation(AnimationActivity::class.java)
        }

        btn_animator.setOnClickListener {
            navigation(AnimatorActivity::class.java)
        }

        btn_layout_change.setOnClickListener {
            navigation(LayoutChangeActivity::class.java)
        }

        btn_canvas_camera.setOnClickListener {
            navigation(MapViewActivity::class.java)
        }

        btn_thumbs_up.setOnClickListener {
            navigation(ThumbsUpActivity::class.java)
        }

        btn_like_button.setOnClickListener {
            navigation(LikeButtonActivity::class.java)
        }

        btn_bezier.setOnClickListener {
            navigation(BezierCircleActivity::class.java)
        }

        btn_shadow.setOnClickListener {
            navigation(BitmapShadowActivity::class.java)
        }

        btn_scratch_card.setOnClickListener {
            navigation(ScratchCardActivity::class.java)
        }

        btn_my_glide.setOnClickListener {
            navigation(MyGlideTestActivity::class.java)
        }

        btn_fish.setOnClickListener {
            navigation(FishActivity::class.java)
        }

        btn_flow_layout.setOnClickListener {
            navigation(FlowLayoutActivity::class.java)
        }

        btn_layout_manager.setOnClickListener {
            navigation(LayoutManagerActivity::class.java)
        }

        btn_cover_layout.setOnClickListener {
            navigation(CoverFlowActivity::class.java)
        }

        btn_sticky_tab.setOnClickListener {
            navigation(StickActivity::class.java)
        }

        btn_ring.setOnClickListener {
            navigation(RingActivity::class.java)
        }

        btn_loading.setOnClickListener {
            navigation(LoadingActivity::class.java)
        }
    }

    private fun navigation(clazz: Class<out Any>) {
        val intent = Intent(this, clazz)
        startActivity(intent)
    }
}