package me.fresh.lee.kotlintest.activity.draw

import android.graphics.drawable.Animatable
import android.graphics.drawable.AnimatedVectorDrawable
import android.os.Build
import android.os.Bundle
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_fish.btn_expand
import kotlinx.android.synthetic.main.activity_fish.btn_shrink
import kotlinx.android.synthetic.main.activity_fish.imageview_search_bar_anim
import kotlinx.android.synthetic.main.activity_fish.iv_fish
import me.fresh.lee.kotlintest.R
import me.fresh.lee.kotlintest.widget.carp.RedCarpDrawable


/**
 *
 * @description    FishActivity
 * @author         lihuayong
 * @date           2019-07-30 15:48
 * @version        1.0
 */
class FishActivity : AppCompatActivity() {

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_fish)

        val fishDrawable = RedCarpDrawable()
        fishDrawable.mainAngle = 120f
        iv_fish.setImageDrawable(fishDrawable)


        val drawable = imageview_search_bar_anim.drawable
        if (drawable is Animatable) {
            (drawable as Animatable).start()
        }

        btn_shrink.setOnClickListener {
            val shrink = getDrawable(R.drawable.avd_trim_path_searchbar_reverse)
            imageview_search_bar_anim.setImageDrawable(shrink)
            (shrink as Animatable).start()

        }

        btn_expand.setOnClickListener {
            val expand = getDrawable(R.drawable.avd_trim_path_searchbar)
            imageview_search_bar_anim.setImageDrawable(expand)
            (expand as Animatable).start()
        }
    }
}