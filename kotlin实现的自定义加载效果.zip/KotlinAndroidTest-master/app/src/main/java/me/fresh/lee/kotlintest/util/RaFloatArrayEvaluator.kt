package me.fresh.lee.kotlintest.util

import android.animation.TypeEvaluator

/**
 *
 * @Description:
 * @Author:         lihuayong
 * @CreateDate:     2019/2/22 上午10:25
 * @UpdateUser:
 * @UpdateDate:     2019/2/22 上午10:25
 * @UpdateRemark:
 * @Version:        1.0
 */
class RaFloatArrayEvaluator : TypeEvaluator<FloatArray> {

    private val mArray: FloatArray? = null

    override fun evaluate(fraction: Float, startValue: FloatArray, endValue: FloatArray): FloatArray {
        var array: FloatArray? = mArray
        if (array == null) {
            array = FloatArray(startValue.size)
        }

        for (i in array.indices) {
            val start = startValue[i]
            val end = endValue[i]
            array[i] = start + fraction * (end - start)
        }
        return array
    }
}