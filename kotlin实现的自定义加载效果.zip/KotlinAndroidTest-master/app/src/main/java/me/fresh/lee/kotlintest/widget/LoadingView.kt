package me.fresh.lee.kotlintest.widget

import android.animation.Animator
import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Path
import android.util.AttributeSet
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.animation.PathInterpolator
import android.widget.LinearLayout
import kotlinx.android.synthetic.main.view_roration_circle.view.pv_1
import kotlinx.android.synthetic.main.view_roration_circle.view.pv_2
import kotlinx.android.synthetic.main.view_roration_circle.view.pv_3
import kotlinx.android.synthetic.main.view_roration_circle.view.pv_4
import me.fresh.lee.kotlintest.R

/**
 *
 * @description    LoadingView
 * @author         lihuayong
 * @date           2019-08-30 10:44
 * @version        1.0
 */
class LoadingView @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {
    companion object {
        const val ANIMATION_DURATION = 800L
    }

    private var mItemOne: PointView
    private var mItemTwo: PointView
    private var mItemThree: PointView
    private var mItemFour: PointView

    private var mItemRadius: Int = 0
    private var mCy: Int = 0
    private var mCx1: Int = 0
    private var mCx2: Int = 0
    private var mCx3: Int = 0
    private var mCx4: Int = 0
    private var mCx1_2: Int = 0
    private var mCx2_3: Int = 0
    private var mCx3_4: Int = 0
    private var mBigRadius: Int = 0
    private var mSmallRadius: Int = 0
    private var mMiddleRadius: Int = 0

    private val interpolator = PathInterpolator(0f, 0f, 0.3f, 1f)

    private val set_1 = AnimatorSet()
    private val set_2 = AnimatorSet()
    private val set_3 = AnimatorSet()
    private val set_4 = AnimatorSet()

    private lateinit var step1_1: ObjectAnimator
    private lateinit var step1_2: ObjectAnimator

    private lateinit var step2_1: ObjectAnimator
    private lateinit var step2_2: ObjectAnimator

    private lateinit var step3_1: ObjectAnimator
    private lateinit var step3_2: ObjectAnimator
    private lateinit var step3_3: ObjectAnimator
    private lateinit var step3_4: ObjectAnimator

    private lateinit var step4_1: ObjectAnimator
    private lateinit var step4_2: ObjectAnimator
    private lateinit var step4_3: ObjectAnimator
    private lateinit var step4_4: ObjectAnimator


    init {
        LayoutInflater.from(context).inflate(R.layout.view_roration_circle, this, true)
        mItemOne = pv_1
        mItemTwo = pv_2
        mItemThree = pv_3
        mItemFour = pv_4
    }

    /**
     * @param target  target view
     * @param rx 旋转中心 x坐标
     * @param ry 旋转中心 y坐标
     * @param radius 旋转半径
     * @param startAngle 开始角度
     * @param cw 是否顺时针
     */
    private fun getAnimator(target: View, rx: Int, ry: Int, radius: Int, startAngle: Float, cw: Boolean): ObjectAnimator {
        val path = Path()
        val sweepAngle = if (cw) {
            180f
        } else {
            -180f
        }
        path.arcTo((rx - radius + mItemRadius).toFloat(), (ry - radius + mItemRadius).toFloat(), (rx + radius + mItemRadius).toFloat(), (ry + radius + mItemRadius).toFloat(), startAngle, sweepAngle, false)
        return ObjectAnimator.ofFloat(target, "x", "y", path).apply {
            duration = ANIMATION_DURATION
        }
    }

    fun start() {
        if (set_1.isRunning || set_2.isRunning || set_3.isRunning || set_4.isRunning) {
            return
        }
        /**
         * 只初始化一次，初始化各个属性其实不应该在这里设置的，懒得弄了
         */
        if (mCy == 0) {
            mItemRadius = (mItemOne.left - mItemOne.right) shr 1
            mCy = (mItemOne.top + mItemOne.bottom) shr 1
            mCx1 = (mItemOne.left + mItemOne.right) shr 1
            mCx2 = (mItemTwo.left + mItemTwo.right) shr 1
            mCx3 = (mItemThree.left + mItemThree.right) shr 1
            mCx4 = (mItemFour.left + mItemFour.right) shr 1

            mCx1_2 = (mCx1 + mCx2) shr 1
            mCx2_3 = (mCx2 + mCx3) shr 1
            mCx3_4 = (mCx3 + mCx4) shr 1

            mSmallRadius = mCx1_2 - mCx1
            mMiddleRadius = mCx2 - mCx1
            mBigRadius = mCx2_3 - mCx1

            step1_1 = getAnimator(mItemOne, mCx2, mCy, mMiddleRadius, 180f, true)
            step1_2 = getAnimator(mItemThree, mCx2, mCy, mMiddleRadius, 0f, true)
            set_1.duration = ANIMATION_DURATION
            set_1.interpolator = interpolator
            set_1.play(step1_1).with(step1_2)
            set_1.addListener(object : Animator.AnimatorListener {
                override fun onAnimationRepeat(animation: Animator?) {
                }

                override fun onAnimationEnd(animation: Animator?) {
                    val tmp: PointView = mItemOne
                    mItemOne = mItemThree
                    mItemThree = tmp
                    Log.d("xxxx", "swap 1 and 3")
                    step2_1.target = mItemTwo
                    step2_2.target = mItemFour
                    set_2.start()
                }

                override fun onAnimationCancel(animation: Animator?) {
                }

                override fun onAnimationStart(animation: Animator?) {
                }

            })

            step2_1 = getAnimator(mItemTwo, mCx3, mCy, mMiddleRadius, 180f, true)
            step2_2 = getAnimator(mItemFour, mCx3, mCy, mMiddleRadius, 0f, true)
            set_2.duration = ANIMATION_DURATION
            set_2.interpolator = interpolator
            set_2.play(step2_1).with(step2_2)
            set_2.addListener(object : Animator.AnimatorListener {
                override fun onAnimationRepeat(animation: Animator?) {
                }

                override fun onAnimationEnd(animation: Animator?) {
                    val tmp: PointView = mItemTwo
                    mItemTwo = mItemFour
                    mItemFour = tmp
                    Log.d("xxxx", "swap 2 and 4")
                    step3_1.target = mItemOne
                    step3_2.target = mItemFour
                    step3_3.target = mItemTwo
                    step3_4.target = mItemThree
                    set_3.start()
                }

                override fun onAnimationCancel(animation: Animator?) {
                }

                override fun onAnimationStart(animation: Animator?) {
                }
            })

            step3_1 = getAnimator(mItemOne, mCx2_3, mCy, mBigRadius, 180f, true)
            step3_2 = getAnimator(mItemFour, mCx2_3, mCy, mBigRadius, 0f, true)
            step3_3 = getAnimator(mItemTwo, mCx2_3, mCy, mSmallRadius, 180f, false)
            step3_4 = getAnimator(mItemThree, mCx2_3, mCy, mSmallRadius, 0f, false)
            set_3.duration = ANIMATION_DURATION
            set_3.interpolator = interpolator
            set_3.play(step3_1).with(step3_2).with(step3_3).with(step3_4)
            set_3.addListener(object : Animator.AnimatorListener {
                override fun onAnimationRepeat(animation: Animator?) {
                }

                override fun onAnimationEnd(animation: Animator?) {
                    val tmp: PointView = mItemOne
                    mItemOne = mItemFour
                    mItemFour = tmp

                    val tmp1: PointView = mItemTwo
                    mItemTwo = mItemThree
                    mItemThree = tmp1

                    step4_1.target = mItemOne
                    step4_2.target = mItemTwo
                    step4_3.target = mItemThree
                    step4_4.target = mItemFour
                    set_4.start()
                }

                override fun onAnimationCancel(animation: Animator?) {
                }

                override fun onAnimationStart(animation: Animator?) {
                }
            })

            step4_1 = getAnimator(mItemOne, mCx1_2, mCy, mSmallRadius, 180f, true)
            step4_2 = getAnimator(mItemTwo, mCx1_2, mCy, mSmallRadius, 0f, true)
            step4_3 = getAnimator(mItemThree, mCx3_4, mCy, mSmallRadius, 180f, true)
            step4_4 = getAnimator(mItemFour, mCx3_4, mCy, mSmallRadius, 0f, true)
            set_4.duration = ANIMATION_DURATION
            set_4.interpolator = interpolator
            set_4.play(step4_1).with(step4_2).with(step4_3).with(step4_4)
            set_4.addListener(object : Animator.AnimatorListener {
                override fun onAnimationRepeat(animation: Animator?) {
                }

                override fun onAnimationEnd(animation: Animator?) {
                    val tmp: PointView = mItemOne
                    mItemOne = mItemTwo
                    mItemTwo = tmp

                    val tmp1: PointView = mItemFour
                    mItemFour = mItemThree
                    mItemThree = tmp1
                    step1_1.target = mItemOne
                    step1_2.target = mItemThree
                    set_1.start()
                }

                override fun onAnimationCancel(animation: Animator?) {
                }

                override fun onAnimationStart(animation: Animator?) {
                }
            })
        }

        set_1.start()
    }

    fun stop(){
        if(set_1.isRunning) {
            set_1.cancel()
        }

        if(set_2.isRunning) {
            set_2.cancel()
        }

        if(set_3.isRunning) {
            set_3.cancel()
        }

        if(set_4.isRunning) {
            set_4.cancel()
        }
    }
}