package me.fresh.lee.kotlintest.widget;

import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.view.animation.PathInterpolator;

import androidx.annotation.Keep;
import androidx.annotation.Nullable;

import me.fresh.lee.kotlintest.R;

/**
 * @author lihuayong
 * @version 1.0
 * @description ThumbsUpView
 * @date 2019/7/6 11:03
 */
@SuppressWarnings("unused")
@Keep
public class ThumbsUpView_old extends View {

    //圆圈颜色
    private static final int START_COLOR = 0x00e24d3d;
    private static final int END_COLOR = 0xffe24d3d;
    //缩放动画的时间
    private static final int SCALE_DURING = 150;
    //圆圈扩散动画的时间
    private static final int RADIUS_DURING = 100;

    private static final float SCALE_MIN = 0.01f;
    private static final float SCALE_MAX = 1f;

    private Bitmap mThumbUp;
    private Bitmap mShining;
    private Bitmap mThumbNormal;
    private Paint mBitmapPaint;

    private float mThumbWidth;
    private float mThumbHeight;
    private float mShiningWidth;
    private float mShiningHeight;

    private PointF mShiningPoint;
    private PointF mThumbPoint;
    private PointF mCirclePoint;

    private float mRadiusMax;
    private float mRadiusMin;
    private float mRadius;
    private Path mClipPath;
    private Paint mCirclePaint;

    private boolean mIsThumbUp = false;

    private AnimatorSet thumbsUpAnim;
    private AnimatorSet thumbsDownAnim;

    private ArgbEvaluator argbEvaluator =  new ArgbEvaluator();

    public ThumbsUpView_old(Context context) {
        this(context, null);
    }

    public ThumbsUpView_old(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ThumbsUpView_old(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        initBitmapInfo();

        mCirclePaint = new Paint();
        mCirclePaint.setAntiAlias(true);
        mCirclePaint.setStyle(Paint.Style.STROKE);
        mCirclePaint.setStrokeWidth(ViewExtKt.dip2px(getContext(), 2));

        mCirclePoint = new PointF();
        mCirclePoint.x = mThumbPoint.x + mThumbWidth / 2;
        mCirclePoint.y = mThumbPoint.y + mThumbHeight / 2;

        mRadiusMax = Math.max(mCirclePoint.x - getPaddingLeft(), mCirclePoint.y - getPaddingTop()) - ViewExtKt.dip2px(getContext(), 7);
        //这个值是根据点击效果调整得到的
        mRadiusMin = ViewExtKt.dip2px(getContext(), 1);
        mClipPath = new Path();
        mClipPath.addCircle(mCirclePoint.x, mCirclePoint.y, mRadiusMax, Path.Direction.CW);
    }

    private void initBitmapInfo() {
        mBitmapPaint = new Paint();
        mBitmapPaint.setAntiAlias(true);

        resetBitmap();

        mThumbWidth = mThumbNormal.getWidth();
        mThumbHeight = mThumbNormal.getHeight();

        mShiningWidth = mShining.getWidth();
        mShiningHeight = mShining.getHeight();

        mShiningPoint = new PointF();
        mThumbPoint = new PointF();
        //这个相对位置是在布局中试出来的
        mShiningPoint.x = getPaddingLeft() + ViewExtKt.dip2px(getContext(), 12);
        mShiningPoint.y = getPaddingTop() + ViewExtKt.dip2px(getContext(), 5);
        mThumbPoint.x = getPaddingLeft() + ViewExtKt.dip2px(getContext(), 10);
        mThumbPoint.y = getPaddingTop() + ViewExtKt.dip2px(getContext(), 18);
    }

    private int getContentWidth() {
        float minLeft = Math.min(mShiningPoint.x, mThumbPoint.x);
        float maxRight = Math.max(mShiningPoint.x + mShiningWidth, mThumbPoint.x + mThumbWidth);
        return (int) (maxRight - minLeft) + ViewExtKt.dip2px(getContext(), 20);
    }

    private int getContentHeight() {
        float minTop = Math.min(mShiningPoint.y, mThumbPoint.y);
        float maxBottom = Math.max(mShiningPoint.y + mShiningHeight, mThumbPoint.y + mThumbHeight);
        return (int) (maxBottom - minTop) + ViewExtKt.dip2px(getContext(), 20);
    }

    private void resetBitmap() {
        mThumbUp = BitmapFactory.decodeResource(getResources(), R.drawable.ic_messages_like_selected);
        Matrix matrix = new Matrix();
        matrix.postScale(0.01f, 0.01f);
        mThumbUp = Bitmap.createBitmap(mThumbUp, 0, 0, mThumbUp.getWidth(), mThumbUp.getHeight(),
                matrix, true);
        mThumbNormal = BitmapFactory.decodeResource(getResources(), R.drawable.ic_messages_like_unselected);
        mShining = BitmapFactory.decodeResource(getResources(), R.drawable.ic_messages_like_selected_shining);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mIsThumbUp) {
            //先绘制 非点赞bitmap的缩小动画
            canvas.drawBitmap(mThumbNormal, mThumbPoint.x, mThumbPoint.y, mBitmapPaint);
            if (mClipPath != null) {
                canvas.save();
                canvas.clipPath(mClipPath);
                canvas.drawBitmap(mShining, mShiningPoint.x, mShiningPoint.y, mBitmapPaint);
                canvas.restore();
                canvas.drawCircle(mCirclePoint.x, mCirclePoint.y, mRadius, mCirclePaint);
            }
            canvas.drawBitmap(mThumbUp, mThumbPoint.x, mThumbPoint.y, mBitmapPaint);
        } else {
            canvas.drawBitmap(mThumbNormal, mThumbPoint.x, mThumbPoint.y, mBitmapPaint);
            canvas.drawBitmap(mThumbUp, mThumbPoint.x, mThumbPoint.y, mBitmapPaint);
        }
    }

    public void thumbsUpAnim() {
        //已经是点赞状态了， 直接返回
        if (mIsThumbUp) {
            return;
        }
        interruptAnimIfRunning();
        mClipPath = null;
        mIsThumbUp = true;
        ObjectAnimator scaleOut = ObjectAnimator.ofFloat(this, "NotThumbUpScale", SCALE_MAX, SCALE_MIN);
        scaleOut.setDuration(SCALE_DURING);

        ObjectAnimator scaleIn = ObjectAnimator.ofFloat(this, "thumbUpScale", SCALE_MIN, SCALE_MAX);
        scaleIn.setDuration(SCALE_DURING);
        scaleIn.setInterpolator(new OvershootInterpolator());

        ObjectAnimator circleScale = ObjectAnimator.ofFloat(this, "circleScale", mRadiusMin, mRadiusMax);
        circleScale.setDuration(RADIUS_DURING);

        ObjectAnimator circleColor = ObjectAnimator.ofArgb(this, "circleColor", END_COLOR, START_COLOR);
        circleColor.setDuration(RADIUS_DURING);
        circleColor.setInterpolator(new PathInterpolator(0.9f, 0f, 0.9f, 0f));

        thumbsUpAnim = new AnimatorSet();
        thumbsUpAnim.play(scaleIn).with(circleScale).with(circleColor).after(scaleOut);
        thumbsUpAnim.start();
    }

    public void thumbsDownAnim() {
        //已经是取消点赞状态了， 直接返回
        if (!mIsThumbUp) {
            return;
        }
        interruptAnimIfRunning();
        mIsThumbUp = false;
        ObjectAnimator scaleOut = ObjectAnimator.ofFloat(this, "thumbUpScale", SCALE_MAX, SCALE_MIN);
        scaleOut.setDuration(SCALE_DURING);

        ObjectAnimator scaleIn = ObjectAnimator.ofFloat(this, "NotThumbUpScale", SCALE_MIN, SCALE_MAX);
        scaleIn.setDuration(SCALE_DURING);
        scaleIn.setInterpolator(new OvershootInterpolator());

        thumbsDownAnim = new AnimatorSet();
        thumbsDownAnim.play(scaleIn).after(scaleOut);
        thumbsDownAnim.start();
    }

    private void interruptAnimIfRunning() {
        if (thumbsDownAnim != null && thumbsDownAnim.isRunning()) {
            thumbsDownAnim.end();
        }
        if (thumbsUpAnim != null && thumbsUpAnim.isRunning()) {
            thumbsUpAnim.end();
        }
    }

    private void setCircleColor(int argb) {
        mCirclePaint.setColor(argb);
        invalidate();
    }

    private void setNotThumbUpScale(float scale) {
        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale);
        mThumbNormal = BitmapFactory.decodeResource(getResources(), R.drawable.ic_messages_like_unselected);
        mThumbNormal = Bitmap.createBitmap(mThumbNormal, 0, 0, mThumbNormal.getWidth(), mThumbNormal.getHeight(),
                matrix, true);
        invalidate();
    }

    private void setThumbUpScale(float scale) {
        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale);
        mThumbUp = BitmapFactory.decodeResource(getResources(), R.drawable.ic_messages_like_selected);
        mThumbUp = Bitmap.createBitmap(mThumbUp, 0, 0, mThumbUp.getWidth(), mThumbUp.getHeight(),
                matrix, true);
        invalidate();
    }

    private void setShiningScale(float scale) {
        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale);
        mShining = BitmapFactory.decodeResource(getResources(), R.drawable.ic_messages_like_selected_shining);
        mShining = Bitmap.createBitmap(mShining, 0, 0, mShining.getWidth(), mShining.getHeight(),
                matrix, true);
        invalidate();
    }

    private void setCircleScale(float radius) {
        mRadius = radius;
        mClipPath = new Path();
        mClipPath.addCircle(mCirclePoint.x, mCirclePoint.y, mRadius, Path.Direction.CW);
        invalidate();
    }

    public interface ThumbUpClickListener {
        //点赞回调
        void thumbUpFinish();

        //取消回调
        void thumbDownFinish();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(ViewExtKt.getDefaultMeasureSize(widthMeasureSpec, getContentWidth() + getPaddingLeft() + getPaddingRight()),
                ViewExtKt.getDefaultMeasureSize(heightMeasureSpec, getContentHeight() + getPaddingTop() + getPaddingBottom()));
    }

    @Override
    protected Parcelable onSaveInstanceState() {
        Bundle data = new Bundle();
        data.putParcelable("superData", super.onSaveInstanceState());
        data.putBoolean("isThumbUp", mIsThumbUp);
        return data;
    }

    @Override
    protected void onRestoreInstanceState(Parcelable state) {
        Bundle data = (Bundle) state;
        Parcelable superData = data.getParcelable("superData");
        super.onRestoreInstanceState(superData);
        mIsThumbUp = data.getBoolean("isThumbUp", false);
        init();
    }
}
