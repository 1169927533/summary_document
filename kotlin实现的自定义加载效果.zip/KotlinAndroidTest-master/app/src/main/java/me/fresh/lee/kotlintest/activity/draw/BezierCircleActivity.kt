package me.fresh.lee.kotlintest.activity.draw

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_bezier_circle.*
import me.fresh.lee.kotlintest.R

/**
 *
 * @description    BezierCircleActivity
 * @author         lihuayong
 * @date           2019/7/11 22:18
 * @version        1.0
 */
class BezierCircleActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bezier_circle)

        bezier_circle.setOnClickListener {
            bezier_circle.startAnimator()
        }
    }
}