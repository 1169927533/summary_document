package me.fresh.lee.kotlintest.widget

import android.content.Context
import android.view.View

/**
 *
 * @description    VewExt
 * @author         lihuayong
 * @date           2019/7/5 22:51
 * @version        1.0
 */

fun dip2px(context: Context, dpValue: Float): Int {
    val scale = context.resources.displayMetrics.density
    return (dpValue * scale + 0.5f).toInt()
}

fun sp2px(context: Context, spValue: Float): Int {
    val fontScale = context.resources.displayMetrics.scaledDensity
    return (spValue * fontScale + 0.5f).toInt()
}

fun getDefaultMeasureSize(measureSpec: Int, defaultSize: Int): Int {
    var result = defaultSize
    val specMode = View.MeasureSpec.getMode(measureSpec)
    val specSize = View.MeasureSpec.getSize(measureSpec)
    when (specMode) {
        View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.AT_MOST -> {
        }
        View.MeasureSpec.EXACTLY -> {
            result = specSize
            result = Math.max(result, defaultSize)
        }
    }
    return result
}

fun mapValueFromRangeToRange(value: Double, fromLow: Double, fromHigh: Double, toLow: Double, toHigh: Double): Double {
    return toLow + (value - fromLow) / (fromHigh - fromLow) * (toHigh - toLow)
}

fun clamp(value: Double, low: Double, high: Double): Double {
    return Math.min(Math.max(value, low), high)
}