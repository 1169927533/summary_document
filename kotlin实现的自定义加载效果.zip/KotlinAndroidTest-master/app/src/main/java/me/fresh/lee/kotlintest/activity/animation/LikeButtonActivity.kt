package me.fresh.lee.kotlintest.activity.animation

import android.graphics.drawable.BitmapDrawable
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.mikepenz.community_material_typeface_library.CommunityMaterial
import com.mikepenz.iconics.IconicsDrawable
import kotlinx.android.synthetic.main.activity_like_button.heart_button
import kotlinx.android.synthetic.main.activity_like_button.smile_button
import kotlinx.android.synthetic.main.activity_like_button.star_button
import kotlinx.android.synthetic.main.activity_like_button.thumb_button
import me.fresh.lee.kotlintest.R
import me.fresh.lee.kotlintest.widget.likebutton.LikeButton
import me.fresh.lee.kotlintest.widget.likebutton.OnAnimationEndListener
import me.fresh.lee.kotlintest.widget.likebutton.OnLikeListener

/**
 *
 * @description    LikeButtonActivity
 * @author         lihuayong
 * @date           2019-07-08 16:36
 * @version        1.0
 */
class LikeButtonActivity : AppCompatActivity(), OnLikeListener, OnAnimationEndListener {
    override fun liked(likeButton: LikeButton?) {
        Toast.makeText(this, "Liked!", Toast.LENGTH_SHORT).show()
    }

    override fun unLiked(likeButton: LikeButton?) {
        Toast.makeText(this, "Disliked!", Toast.LENGTH_SHORT).show()
    }

    override fun onAnimationEnd(likeButton: LikeButton?) {
        Log.d("====", "Animation End for %s$likeButton")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_like_button)

        star_button.setOnAnimationEndListener(this)
        star_button.setOnLikeListener(this)

        heart_button.setOnAnimationEndListener(this)
        heart_button.setOnLikeListener(this)

        thumb_button.setOnAnimationEndListener(this)
        thumb_button.setOnLikeListener(this)
        thumb_button.isLiked = true

        smile_button.setOnAnimationEndListener(this)
        smile_button.setOnLikeListener(this)

        usingCustomIcons()
    }

    private fun usingCustomIcons() {

        //shown when the button is in its default state or when unLiked.
        smile_button.setUnlikeDrawable(BitmapDrawable(resources, IconicsDrawable(this, CommunityMaterial.Icon.cmd_emoticon).colorRes(android.R.color.darker_gray).sizeDp(25).toBitmap()))

        //shown when the button is liked!
        smile_button.setLikeDrawable(BitmapDrawable(resources, IconicsDrawable(this, CommunityMaterial.Icon.cmd_emoticon).colorRes(android.R.color.holo_purple).sizeDp(25).toBitmap()))
    }
}