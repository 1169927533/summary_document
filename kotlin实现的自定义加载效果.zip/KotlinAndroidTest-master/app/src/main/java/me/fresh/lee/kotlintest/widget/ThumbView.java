package me.fresh.lee.kotlintest.widget;

import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.TypeEvaluator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Property;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Interpolator;
import android.view.animation.OvershootInterpolator;

import me.fresh.lee.kotlintest.R;

/**
 * @author lihuayong
 * @version 1.0
 * @description ThumbView
 * @date 2019-07-08 14:28
 */
public class ThumbView extends View {

    /**
     * 圆圈颜色
     */
    private static final int START_COLOR = 0xffe24d3d;
    private static final int END_COLOR = 0x00e24d3d;
    /**
     * 缩放动画的时间
     */
    private static final int SCALE_DURING = 150;

    private static final float SCALE_MIN = 0.01f;
    private static final float SCALE_MAX = 1f;

    private Bitmap mThumbUp;
    private Bitmap mShining;
    private Bitmap mThumbNormal;

    private Bitmap cacheThumbUp = BitmapFactory.decodeResource(getResources(), R.drawable.ic_messages_like_selected);

    private Paint mBitmapPaint;

    private float mThumbWidth;
    private float mThumbHeight;
    private float mShiningWidth;
    private float mShiningHeight;

    private PointF mShiningPoint;
    private PointF mThumbPoint;
    private PointF mCirclePoint;

    private float mRadiusMax;
    private float mRadiusMin;
    private Path mClipPath;
    private Paint mCirclePaint;

    private boolean mIsThumbUp = false;

    private AnimatorSet thumbsUpAnim;
    private AnimatorSet thumbsDownAnim;

    public ThumbView(Context context) {
        this(context, null);
    }

    public ThumbView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ThumbView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        setFocusable(true);
        setClickable(true);
        initBitmapInfo();

        mCirclePaint = new Paint();
        mCirclePaint.setAntiAlias(true);
        mCirclePaint.setStyle(Paint.Style.STROKE);
        mCirclePaint.setStrokeWidth(ViewExtKt.dip2px(getContext(), 2));

        mCirclePoint = new PointF();
        mCirclePoint.x = mThumbPoint.x + mThumbWidth / 2;
        mCirclePoint.y = mThumbPoint.y + mThumbHeight / 2;

        mRadiusMax = Math.max(mCirclePoint.x - getPaddingLeft(), mCirclePoint.y - getPaddingTop()) - ViewExtKt.dip2px(getContext(), 7);
        //这个值是根据点击效果调整得到的
        mRadiusMin = ViewExtKt.dip2px(getContext(), 1);
        mClipPath = new Path();
        mClipPath.addCircle(mCirclePoint.x, mCirclePoint.y, mRadiusMax, Path.Direction.CW);
    }

    private void initBitmapInfo() {
        mBitmapPaint = new Paint();
        mBitmapPaint.setAntiAlias(true);

        resetBitmap();

        mThumbWidth = mThumbNormal.getWidth();
        mThumbHeight = mThumbNormal.getHeight();

        mShiningWidth = mShining.getWidth();
        mShiningHeight = mShining.getHeight();

        mShiningPoint = new PointF();
        mThumbPoint = new PointF();
        //这个相对位置是在布局中试出来的
        mShiningPoint.x = getPaddingLeft() + ViewExtKt.dip2px(getContext(), 12);
        mShiningPoint.y = getPaddingTop() + ViewExtKt.dip2px(getContext(), 5);
        mThumbPoint.x = getPaddingLeft() + ViewExtKt.dip2px(getContext(), 10);
        mThumbPoint.y = getPaddingTop() + ViewExtKt.dip2px(getContext(), 18);
    }

    private int getContentWidth() {
        float minLeft = Math.min(mShiningPoint.x, mThumbPoint.x);
        float maxRight = Math.max(mShiningPoint.x + mShiningWidth, mThumbPoint.x + mThumbWidth);
        return (int) (maxRight - minLeft) + ViewExtKt.dip2px(getContext(), 20);
    }

    private int getContentHeight() {
        float minTop = Math.min(mShiningPoint.y, mThumbPoint.y);
        float maxBottom = Math.max(mShiningPoint.y + mShiningHeight, mThumbPoint.y + mThumbHeight);
        return (int) (maxBottom - minTop) + ViewExtKt.dip2px(getContext(), 20);
    }

    private void resetBitmap() {
        mThumbUp = BitmapFactory.decodeResource(getResources(), R.drawable.ic_messages_like_selected);
        Matrix matrix = new Matrix();
        matrix.postScale(0.01f, 0.01f);
        mThumbUp = Bitmap.createBitmap(mThumbUp, 0, 0, mThumbUp.getWidth(), mThumbUp.getHeight(),
                matrix, true);
        mThumbNormal = BitmapFactory.decodeResource(getResources(), R.drawable.ic_messages_like_unselected);
        mShining = BitmapFactory.decodeResource(getResources(), R.drawable.ic_messages_like_selected_shining);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (mIsThumbUp) {
            if (mClipPath != null) {
                canvas.save();
                canvas.clipPath(mClipPath);
                canvas.drawBitmap(mShining, mShiningPoint.x, mShiningPoint.y, mBitmapPaint);
                canvas.restore();
                canvas.drawCircle(mCirclePoint.x, mCirclePoint.y, mViewProperty.circleScale, mCirclePaint);
            }
        }
        canvas.drawBitmap(mThumbNormal, mThumbPoint.x, mThumbPoint.y, mBitmapPaint);
        canvas.drawBitmap(mThumbUp, mThumbPoint.x, mThumbPoint.y, mBitmapPaint);
    }

    public void thumbsUpAnim() {
        //已经是点赞状态了， 直接返回
        if (mIsThumbUp) {
            return;
        }
        interruptAnimIfRunning();
        mClipPath = null;
        mIsThumbUp = true;
        ObjectAnimator scaleOut = ObjectAnimator.ofFloat(this, "NotThumbUpScale", SCALE_MAX, SCALE_MIN);
        scaleOut.setDuration(SCALE_DURING);

        ObjectAnimator animator = getThumbUpAnimator();
        thumbsUpAnim = new AnimatorSet();
        thumbsUpAnim.play(animator).after(scaleOut);
        thumbsUpAnim.start();
    }

    public void thumbsDownAnim() {
        //已经是取消点赞状态了， 直接返回
        if (!mIsThumbUp) {
            return;
        }
        interruptAnimIfRunning();
        mIsThumbUp = false;
        ObjectAnimator scaleOut = ObjectAnimator.ofFloat(this, "thumbUpScale", SCALE_MAX, SCALE_MIN);
        scaleOut.setDuration(SCALE_DURING);

        ObjectAnimator scaleIn = ObjectAnimator.ofFloat(this, "NotThumbUpScale", SCALE_MIN, SCALE_MAX);
        scaleIn.setDuration(SCALE_DURING);
        scaleIn.setInterpolator(new OvershootInterpolator());

        thumbsDownAnim = new AnimatorSet();
        thumbsDownAnim.play(scaleIn).after(scaleOut);
        thumbsDownAnim.start();
    }

    private void interruptAnimIfRunning() {
        if (thumbsDownAnim != null && thumbsDownAnim.isRunning()) {
            thumbsDownAnim.end();
        }
        if (thumbsUpAnim != null && thumbsUpAnim.isRunning()) {
            thumbsUpAnim.end();
        }
    }

    private void setNotThumbUpScale(float scale) {
        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale);
        mThumbNormal = BitmapFactory.decodeResource(getResources(), R.drawable.ic_messages_like_unselected);
        mThumbNormal = Bitmap.createBitmap(mThumbNormal, 0, 0, mThumbNormal.getWidth(), mThumbNormal.getHeight(),
                matrix, true);
        invalidate();
    }

    private void setThumbUpScale(float scale) {
        Matrix matrix = new Matrix();
        matrix.postScale(scale, scale);
        mThumbUp = BitmapFactory.decodeResource(getResources(), R.drawable.ic_messages_like_selected);
        mThumbUp = Bitmap.createBitmap(mThumbUp, 0, 0, mThumbUp.getWidth(), mThumbUp.getHeight(),
                matrix, true);
        invalidate();
    }

    public interface ThumbUpClickListener {
        /**
         * 点赞回调
         */
        void thumbUpFinish();

        /**
         * 取消回调
         */
        void thumbDownFinish();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(ViewExtKt.getDefaultMeasureSize(widthMeasureSpec, getContentWidth() + getPaddingLeft() + getPaddingRight()),
                ViewExtKt.getDefaultMeasureSize(heightMeasureSpec, getContentHeight() + getPaddingTop() + getPaddingBottom()));
    }

    private float x;
    private float y;

    @Override
    public boolean performClick() {
        Log.d("======", "performClick");
        if (mIsThumbUp) {
            thumbsDownAnim();
        } else {
            thumbsUpAnim();
        }
        return super.performClick();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getAction();
        Log.d("======", "click  x = " + event.getX() + ", y = " + event.getY());
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                x = event.getX();
                y = event.getY();
                break;
            case MotionEvent.ACTION_UP:
                performClick();
                return true;
            default:
                break;
        }
        return super.onTouchEvent(event);
    }

    @Override
    protected Parcelable onSaveInstanceState() {
        Bundle data = new Bundle();
        data.putParcelable("superData", super.onSaveInstanceState());
        data.putBoolean("isThumbUp", mIsThumbUp);
        return data;
    }

    @Override
    protected void onRestoreInstanceState(Parcelable state) {
        Bundle data = (Bundle) state;
        Parcelable superData = data.getParcelable("superData");
        super.onRestoreInstanceState(superData);
        mIsThumbUp = data.getBoolean("isThumbUp", false);
        init();
    }

    private ViewProperty mViewProperty = new ViewProperty(SCALE_MIN, mRadiusMin, START_COLOR);

    private void setViewProperty(ViewProperty value) {
        mViewProperty = value;
        mCirclePaint.setColor(mViewProperty.circleColor);
        mClipPath = new Path();
        mClipPath.addCircle(mCirclePoint.x, mCirclePoint.y, mViewProperty.circleScale, Path.Direction.CW);

        Matrix matrix = new Matrix();
        matrix.postScale(mViewProperty.thumbUpScale, mViewProperty.thumbUpScale);
        mThumbUp = cacheThumbUp;
        mThumbUp = Bitmap.createBitmap(mThumbUp, 0, 0, mThumbUp.getWidth(), mThumbUp.getHeight(),
                matrix, true);
        invalidate();
    }

    public static final Property<ThumbView, ViewProperty> THUMB_UP_PROGRESS = new Property<ThumbView, ViewProperty>(ViewProperty.class, "mViewProperty") {
        @Override
        public ViewProperty get(ThumbView object) {
            return object.mViewProperty;
        }

        @Override
        public void set(ThumbView object, ViewProperty value) {
            object.setViewProperty(value);
        }
    };

    private ObjectAnimator getThumbUpAnimator() {
        return ObjectAnimator.ofObject(this, THUMB_UP_PROGRESS,
                new ViewPropertyEvaluator(),
                new ViewProperty(SCALE_MIN, mRadiusMin, START_COLOR),
                new ViewProperty(SCALE_MAX, mRadiusMax, END_COLOR));
    }

    class ViewPropertyEvaluator implements TypeEvaluator<ViewProperty> {

        ArgbEvaluator argbEvaluator = new ArgbEvaluator();
        ViewProperty cache = new ViewProperty();
        Interpolator overshoot = new OvershootInterpolator(4f);

        @Override
        public ViewProperty evaluate(float fraction, ViewProperty startValue, ViewProperty endValue) {
            float thumbUpScale = startValue.thumbUpScale + overshoot.getInterpolation(fraction) * (endValue.thumbUpScale - startValue.thumbUpScale);
            float circleScale = startValue.circleScale + fraction * (endValue.circleScale - startValue.circleScale);

            int color = (int) argbEvaluator.evaluate(fraction, startValue.circleColor, endValue.circleColor);
            return cache.set(thumbUpScale, circleScale, color);
        }
    }

    class ViewProperty {
        float thumbUpScale;
        float circleScale;
        int circleColor;

        ViewProperty() {

        }

        ViewProperty(float thumbUpScale, float circleScale, int circleColor) {
            this.thumbUpScale = thumbUpScale;
            this.circleScale = circleScale;
            this.circleColor = circleColor;
        }

        ViewProperty set(float thumbUpScale, float circleScale, int circleColor) {
            this.thumbUpScale = thumbUpScale;
            this.circleScale = circleScale;
            this.circleColor = circleColor;
            return this;
        }
    }

}
