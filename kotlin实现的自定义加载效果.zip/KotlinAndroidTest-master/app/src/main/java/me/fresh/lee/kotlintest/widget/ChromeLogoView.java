package me.fresh.lee.kotlintest.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Region;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.ColorInt;

/**
 * @author lihuayong
 * @version 1.0
 * @description ChromeLogoView 绘制一个Chrome Logo
 * @date 2019-07-09 14:54
 */
public class ChromeLogoView extends View {

    private static final int DEFAULT_WIDTH = 100;
    private static final int DEFAULT_HEIGHT = 100;
    private static final float SQRT_3 = (float) Math.sqrt(3);

    /**
     * the smaller blue circle_white inside, the radius ratio
     */
    private final static float INNER_RADIUS_RATIO = 400f / 1024f;

    @ColorInt
    private final static int COLOR_YELLOW = 0xFFF8CC5F;
    @ColorInt
    private final static int COLOR_RED = 0xFFCC5A4C;
    @ColorInt
    private final static int COLOR_GREEN = 0xFF4C9E66;
    @ColorInt
    private final static int COLOR_BLUE = 0xFF5A8CEE;
    private int[] colors = new int[]{COLOR_RED, COLOR_GREEN, COLOR_YELLOW};

    /**
     * view width
     */
    private int mWidth = DEFAULT_WIDTH;

    /**
     * view height
     */

    private int mHeight = DEFAULT_HEIGHT;

    /**
     * logo radius
     */
    private int mRadius = DEFAULT_WIDTH >> 1;

    /**
     * logo center point
     */
    private PointF pointO;

    /**
     * path start point
     */
    private PointF pointA;

    private PointF pointC;

    private Path itemPath;
    private Paint itemPaint;

    /**
     * regions for handling click area event
     */
    private Region region;
    private Region clip;

    private float x;
    private float y;

    public ChromeLogoView(Context context) {
        this(context, null);
    }

    public ChromeLogoView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ChromeLogoView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        pointO = new PointF();
        pointA = new PointF();
        pointC = new PointF();

        region = new Region();
        clip = new Region();

        itemPath = new Path();
        itemPaint = new Paint();
        itemPaint.setColor(colors[0]);
        itemPaint.setAntiAlias(true);
        itemPaint.setStyle(Paint.Style.FILL_AND_STROKE);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        setMeasuredDimension(ViewExtKt.getDefaultMeasureSize(widthMeasureSpec, DEFAULT_WIDTH),
                ViewExtKt.getDefaultMeasureSize(heightMeasureSpec, DEFAULT_HEIGHT));
    }


    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        mWidth = w;
        mHeight = h;
        mRadius = Math.min(mWidth, mHeight) >> 1;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        //init basic info
        pointO.set(mWidth >> 1, mHeight >> 1);
        float innerRadius = (mRadius >> 1);

        //设置Path的起点坐标
        pointA.set(pointO.x - (mRadius >> 2) * SQRT_3, pointO.y + (mRadius >> 2));
        pointC.set(pointO.x + innerRadius * SQRT_3, pointO.y - innerRadius);

        //draw one of the parts
        itemPath.reset();
        //绘制弧AB
        itemPath.moveTo(pointA.x, pointA.y);
        itemPath.arcTo(pointO.x - innerRadius, pointO.y - innerRadius,
                pointO.x + innerRadius, pointO.y + innerRadius,
                150f, 120f, true);

        //绘制线段BC
        itemPath.lineTo(pointC.x, pointC.y);

        //绘制弧CD
        itemPath.arcTo(pointO.x - mRadius, pointO.y - mRadius,
                pointO.x + mRadius, pointO.y + mRadius,
                -30f, -120f, true);

        //绘制线段DA
        itemPath.lineTo(pointA.x, pointA.y);
        itemPath.close();

        //绘制单个 1/3的图形
        itemPaint.setColor(colors[0]);
        canvas.drawPath(itemPath, itemPaint);

        //rotate canvas and draw another part
        canvas.rotate(-120f, pointO.x, pointO.y);
        itemPaint.setColor(colors[1]);
        canvas.drawPath(itemPath, itemPaint);

        //continue rotate canvas and draw the last part
        canvas.rotate(-120f, pointO.x, pointO.y);
        itemPaint.setColor(colors[2]);
        canvas.drawPath(itemPath, itemPaint);

        //draw the inner circle_white
        itemPaint.setColor(COLOR_BLUE);
        canvas.drawCircle(pointO.x, pointO.y, mRadius * INNER_RADIUS_RATIO, itemPaint);

        clip.set(0, 0, mWidth, mHeight);
        region.setPath(itemPath, clip);
    }

    @Override
    public boolean performClick() {
        return super.performClick();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getAction();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                x = event.getX();
                y = event.getY();
                break;
            case MotionEvent.ACTION_UP:
                double angle120 = 2f / 3 * Math.PI;
                double angle120_ = -2f / 3 * Math.PI;
                if (region.contains((int) x, (int) y)) {
                    Toast.makeText(getContext(), "点击红色区域", Toast.LENGTH_SHORT).show();
                } else if (region.contains((int) (pointO.x + (x - pointO.x) * Math.cos(angle120_) - (y - pointO.y) * Math.sin(angle120)),
                        (int) (pointO.y + (x - pointO.x) * Math.sin(angle120_) + (y - pointO.y) * Math.cos(angle120_)))) {
                    Toast.makeText(getContext(), "点击黄色区域", Toast.LENGTH_SHORT).show();
                } else if (region.contains((int) (pointO.x + (x - pointO.x) * Math.cos(angle120) - (y - pointO.y) * Math.sin(angle120)),
                        (int) (pointO.y + (x - pointO.x) * Math.sin(angle120) + (y - pointO.y) * Math.cos(angle120)))) {
                    Toast.makeText(getContext(), "点击绿色区域", Toast.LENGTH_SHORT).show();
                }
                performClick();
                break;
            case MotionEvent.ACTION_CANCEL:
                break;
            default:
                break;
        }
        return super.onTouchEvent(event);

    }
}
