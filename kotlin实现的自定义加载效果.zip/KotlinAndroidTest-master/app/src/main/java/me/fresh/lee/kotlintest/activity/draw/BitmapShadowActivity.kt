package me.fresh.lee.kotlintest.activity.draw

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_bitmap_shadow.cat
import kotlinx.android.synthetic.main.activity_bitmap_shadow.v_chrome
import me.fresh.lee.kotlintest.R
import me.fresh.lee.kotlintest.widget.drawable.ChromeDrawable
import me.fresh.lee.kotlintest.widget.explosion.BooleanFactory
import me.fresh.lee.kotlintest.widget.explosion.ExplosionField

/**
 *
 * @description    BitmapShadowActivity
 * @author         lihuayong
 * @date           2019-07-16 16:07
 * @version        1.0
 */
class BitmapShadowActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_bitmap_shadow)

        v_chrome.background = ChromeDrawable()

        val explosionField = ExplosionField(this, BooleanFactory())
        explosionField.addListener(cat)
        explosionField.addListener(v_chrome)
    }
}