package me.fresh.lee.kotlintest.widget

import android.content.Context
import android.content.res.TypedArray
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import  android.view.View
import me.fresh.lee.kotlintest.R

/**
 *
 * @description    PointView
 * @author         lihuayong
 * @date           2019-08-30 10:20
 * @version        1.0
 */
class PointView @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var mPaint: Paint = Paint()

    init {
        mPaint.color = Color.YELLOW
        initAttrs(context, attrs, defStyleAttr)
    }

    private fun initAttrs(context: Context, attrs: AttributeSet?, defStyleAttr: Int) {
        val ta: TypedArray = context.obtainStyledAttributes(attrs, R.styleable.PointView, defStyleAttr, 0)
        setColor(ta.getColor(R.styleable.PointView_pv_color, Color.RED))
        ta.recycle()
    }


    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        setMeasuredDimension(measureView(widthMeasureSpec, 40), measureView(heightMeasureSpec, 40))
    }

    private fun measureView(measureSpec: Int, defaultSize: Int): Int {
        var result: Int
        val specMode = MeasureSpec.getMode(measureSpec)
        val specSize = MeasureSpec.getSize(measureSpec)
        if (specMode == MeasureSpec.EXACTLY) {
            result = specSize
        } else {
            result = defaultSize
            if (specMode == MeasureSpec.AT_MOST) {
                result = Math.min(result, specSize)
            }
        }
        return result
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)
        val w = width
        val h = height
        val radius = Math.min(w, h) shr 1
        canvas?.drawCircle((w shr 1).toFloat(), (h shr 1).toFloat(), radius.toFloat(), mPaint)
    }

    fun setColor(color: Int) {
        mPaint.color = color
        invalidate()
    }
}