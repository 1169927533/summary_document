package me.fresh.lee.kotlintest.util

import java.util.*

/**
 * Created by lihuayong on 2018/9/21.
 */
object DateUtils {
    /**
     * 获取发布信息时长的描述
     * 1、上传当个自然日： 1小时内显示 刚刚更新； 1小时后显示 XX小时前
     * 2、上传当个自然日之后显示  X天前
     * @param date  消息发布日期
     * @return  发布信息时长的描述
     */
    @JvmStatic fun getPublishTimeDescription(date: Long): String {
        val now = Date(System.currentTimeMillis())
        val nd = 1000 * 60 * 60 * 24   //1天的 毫秒数
        val nh = 1000 * 60 * 60       //1 小时的毫秒数

        val publishDate = Date(date)
        val dayDiff = now.day - publishDate.day
        when {
            dayDiff > 0 -> return dayDiff.toString() + "天前"
            //return new StringBuilder().append(dayDiff).append("天前").toString();
            dayDiff == 0 -> {
                val diff = now.time - date
                val hour = diff % nd / nh  // 计算差多少小时

                return if (diff > 0) {  //系统当前时间大于（晚于）消息发布时间
                    if (hour >= 1) {
                        hour.toString() + "小时前"
                        //return new StringBuilder().append(hour).append("小时前").toString();
                    } else {
                        "刚刚更新"
                    }
                } else {
                    "wrong date!"   //系统当前时间比 发布时间还早，这在实际情况中是不可能的。
                }

            }
            else -> //throw new IllegalArgumentException("wrong publish date!");
                return "wrong date!"      //系统当前时间比 发布时间还早，这在实际情况中是不可能的。
        }

    }
}