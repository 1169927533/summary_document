package me.fresh.lee.kotlintest.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.MaskFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;

import me.fresh.lee.kotlintest.R;

/**
 * @author lihuayong
 * @version 1.0
 * @description BitmapShadowView
 * @date 2019-07-16 15:57
 */
public class BitmapShadowView extends View {

    private static final int DEFAULT_PADDING = 20;
    private static final int DEFAULT_RADIUS = 100;

    private int mDx = DEFAULT_PADDING;
    private int mDy = DEFAULT_PADDING;
    private int mRadius = DEFAULT_RADIUS;
    private int mShadowColor = Color.GRAY;

    private Rect mShadowRect;
    private Rect mBitmapRect;
    private Paint paint;

    private Bitmap bitmap, alphaBitmap;

    private MaskFilter filter = new BlurMaskFilter(DEFAULT_RADIUS, BlurMaskFilter.Blur.NORMAL);

    public BitmapShadowView(Context context) {
        this(context, null);
    }

    public BitmapShadowView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public BitmapShadowView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        mShadowRect = new Rect();
        mBitmapRect = new Rect();

        paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(mShadowColor);

        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.BitmapShadowView);
        setDx(ta.getDimensionPixelOffset(R.styleable.BitmapShadowView_shadowDx, DEFAULT_PADDING));
        setDy(ta.getDimensionPixelOffset(R.styleable.BitmapShadowView_shadowDy, DEFAULT_PADDING));
        setRadius(ta.getDimensionPixelOffset(R.styleable.BitmapShadowView_shadowRadius, DEFAULT_RADIUS));
        setShadowColor(ta.getColor(R.styleable.BitmapShadowView_shadowColor, Color.GRAY));
        int bitmapRes = ta.getResourceId(R.styleable.BitmapShadowView_src, -1);
        if (bitmapRes == -1) {
            throw new IllegalArgumentException("bitmap shadow view must set bitmap, use attribute src");
        }
        setBitmap(BitmapFactory.decodeResource(getResources(), bitmapRes));
        ta.recycle();

        mBitmapRect.set(0, 0, alphaBitmap.getWidth(), alphaBitmap.getHeight());
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int width = getWidth() - mDx;
        int height = alphaBitmap.getHeight() / alphaBitmap.getWidth() * width;

        //绘制阴影
        paint.setMaskFilter(filter);
        paint.setColor(mShadowColor);
        mShadowRect.set(mDx, mDy, width, height);
        canvas.drawBitmap(alphaBitmap, null, mShadowRect, paint);

        //绘制Bitmap
        paint.setMaskFilter(null);
        mBitmapRect.set(0, 0, width, height);
        canvas.drawBitmap(bitmap, null, mBitmapRect, paint);
    }

    private void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
        alphaBitmap = bitmap.extractAlpha();
    }

    public int getDx() {
        return mDx;
    }

    public void setDx(int dx) {
        this.mDx = dx;
        postInvalidate();
    }

    public int getDy() {
        return mDy;
    }

    public void setDy(int dy) {
        this.mDy = dy;
        postInvalidate();
    }

    public int getRadius() {
        return mRadius;
    }

    public void setRadius(int radius) {
        this.mRadius = radius;
        filter = new BlurMaskFilter(mRadius, BlurMaskFilter.Blur.NORMAL);
        postInvalidate();
    }

    public int getShadowColor() {
        return mShadowColor;
    }

    public void setShadowColor(int shadowColor) {
        this.mShadowColor = shadowColor;
        paint.setColor(mShadowColor);
        postInvalidate();
    }
}
