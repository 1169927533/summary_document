package me.fresh.lee.kotlintest.activity.draw;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import me.fresh.lee.kotlintest.R;
import me.fresh.lee.kotlintest.widget.MapView;

/**
 * @author lihuayong
 * @version 1.0
 * @description MapViewActivity
 * @date 2019-07-05 19:12
 */
public class MapViewActivity extends AppCompatActivity {

    private Handler handler = new Handler();
    private MapView mapView;
    private Runnable runnable;
    private final AnimatorSet set = new AnimatorSet();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_view);
        initView();
    }

    /**
     * 整个动画被拆分成为三个部分
     * 1、绕Y轴3D旋转45度
     * 2、绕Z轴3D旋转270度
     * 3、不变的那一半（上半部分）绕Y轴旋转30度（注意，这里canvas已经旋转了270度，计算第三个动效参数时要注意）
     */
    private void initView() {
        mapView = findViewById(R.id.map_layout);

        ObjectAnimator animator1 = ObjectAnimator.ofFloat(mapView, "degreeY", 0, -45);
        animator1.setDuration(1000);
        animator1.setStartDelay(500);

        ObjectAnimator animator2 = ObjectAnimator.ofFloat(mapView, "degreeZ", 0, 270);
        animator2.setDuration(800);
        animator2.setStartDelay(500);

        ObjectAnimator animator3 = ObjectAnimator.ofFloat(mapView, "fixDegreeY", 0, 30);
        animator3.setDuration(500);
        animator3.setStartDelay(500);

        runnable = () -> runOnUiThread(() -> {
            mapView.reset();
            Log.d("======", "will memory leak?");
            set.start();
        });

        set.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                handler.postDelayed(runnable, 500);
            }
        });
        set.playSequentially(animator1, animator2, animator3);
        set.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("=====", "onDestroy");
        set.end();
        if (handler != null) {
            handler.removeCallbacks(runnable);
        }
    }
}
