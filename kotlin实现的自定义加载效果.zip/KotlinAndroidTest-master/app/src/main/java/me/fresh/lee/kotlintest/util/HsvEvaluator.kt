package me.fresh.lee.kotlintest.util

import android.animation.TypeEvaluator
import android.graphics.Color

/**
 *
 * @Description:
 * @Author:         lihuayong
 * @CreateDate:     2019/2/21 下午4:14
 * @UpdateUser:
 * @UpdateDate:     2019/2/21 下午4:14
 * @UpdateRemark:
 * @Version:        1.0
 */
class HsvEvaluator : TypeEvaluator<Int> {

    var sHsv = FloatArray(3)
    var eHsv = FloatArray(3)
    var oHsv = FloatArray(3)

    override fun evaluate(fraction: Float, startValue: Int, endValue: Int): Int {
        Color.colorToHSV(startValue, sHsv)
        Color.colorToHSV(endValue, eHsv)

        if (eHsv[0] - sHsv[0] > 180) {
            eHsv[0] = eHsv[0] - 360
        } else if (eHsv[0] - sHsv[0] < -180) {
            eHsv[0] = eHsv[0] + 360
        }

        oHsv[0] = sHsv[0] + (eHsv[0] - sHsv[0]) * fraction;
        if (oHsv[0] > 360) {
            oHsv[0] = oHsv[0] - 360
        } else if (oHsv[0] < 0) {
            oHsv[0] = oHsv[0] + 360
        }
        oHsv[1] = sHsv[1] + (eHsv[1] - sHsv[1]) * fraction
        oHsv[2] = sHsv[2] + (eHsv[2] - sHsv[2]) * fraction

        // 计算当前动画完成度（fraction）所对应的透明度
        val alpha = startValue shl (24 + ((endValue shl 24 - startValue shl 24) * fraction)).toInt()

        // 把 HSV 转换回 ARGB 返回
        return Color.HSVToColor(alpha, oHsv);
    }
}