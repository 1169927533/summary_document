package me.fresh.lee.kotlintest.widget;

import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import androidx.annotation.ColorInt;
import androidx.annotation.Keep;
import androidx.annotation.Nullable;

import me.fresh.lee.kotlintest.R;

/**
 * @author lihuayong
 * @version 1.0
 * @description BezierCircleView
 * @date 2019/7/11 20:54
 */
@SuppressWarnings("unused")
@Keep
public class BezierCircleView extends View {
    private static final float BEZIER_FACTOR = 0.551915f;
    private static final float THRESHOLD_L = 0.5f;   //离开圆的阈值
    private static final float THRESHOLD_M = 0.8f;  //最大值的阈值
    private static final float THRESHOLD_A = 0.9f;  //到达下个圆框的阈值
    private static final float BOUND_RADIO = 0.55f;  //进入另一个圆的回弹效果

    private static final int DEFAULT_COUNT = 4;

    private int mWidth;
    private int mHeight;

    private int mRadius = 80;

    private boolean direction = true; //方向 , true是位置向右(0->1)

    /**
     * 当前圆的位置
     */
    private int currentPosition = 0;
    private int nextPosition = 1; //圆要到达的下一个位置

    private float[] bezPos; //记录每一个圆心x轴的位置
    private float[] xPivotPos;  //根据圆心x轴+mRadius，划分成不同的区域 ,主要为了判断触摸x轴的位置

    /**
     * 指示器总共数目
     */
    private int totalCount = DEFAULT_COUNT;

    /**
     * 动画时长
     */
    private int mAnimationDuration = 500;

    @ColorInt
    private int mFillColor;
    @ColorInt
    private int mBorderColor;

    private PointF p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11;

    private float rRadio = 1;  //P2,3,4 x轴倍数
    private float lRadio = 1;  //P8,9,10倍数
    private float tbRadio = 1;  //y轴缩放倍数

    private Path mPath;
    private Paint mPaint;
    private Paint mBorderPaint;
    private Matrix matrix;

    private ValueAnimator animator;
    private TimeInterpolator interpolator = new DecelerateInterpolator();
    private float animatedValue;
    private boolean isAnimating = false;

    public BezierCircleView(Context context) {
        this(context, null);
    }

    public BezierCircleView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public BezierCircleView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
        initAttr(context, attrs);
    }

    private void initAttr(Context context, AttributeSet attrs) {
        TypedArray ta = context.obtainStyledAttributes(attrs, R.styleable.BezierCircleView);
        setRadius(ta.getDimensionPixelSize(R.styleable.BezierCircleView_bcv_radius, 100));
        setFillColor(ta.getColor(R.styleable.BezierCircleView_bcv_fill_color, Color.RED));
        setBorderColor(ta.getColor(R.styleable.BezierCircleView_bcv_border_color, Color.YELLOW));
        ta.recycle();
    }

    private void init() {

        mPath = new Path();
        matrix = new Matrix();
        matrix.preScale(-1, 1);
        mPaint = new Paint();
        mPaint.setAntiAlias(true);
        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setStrokeWidth(2f);
        mPaint.setColor(mFillColor);

        mBorderPaint = new Paint();
        mBorderPaint.setAntiAlias(true);
        mBorderPaint.setStyle(Paint.Style.STROKE);
        mBorderPaint.setStrokeWidth(2f);
        mBorderPaint.setColor(mBorderColor);

        updateRadius();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        canvas.translate(0, mHeight >> 1);


        for (int i = 0; i < totalCount; i++) {
            canvas.drawCircle(bezPos[i], 0, mRadius - 2, mBorderPaint);   //绘制圆框
        }
        if (animatedValue == 1) {
            canvas.drawCircle(bezPos[currentPosition], 0, mRadius, mPaint);
            return;
        }

        canvas.translate(bezPos[currentPosition], 0);

        if (0 < animatedValue && animatedValue <= THRESHOLD_L) { //还没离开圆框的时候
            rRadio = 1f + animatedValue * 2;                         //  [1,2]
            lRadio = 1f;
            tbRadio = 1f;
        }
        if (THRESHOLD_L < animatedValue && animatedValue <= THRESHOLD_M) {
            rRadio = 2 - mapTo0_1(THRESHOLD_L, THRESHOLD_M) * 0.5f;          //  [2,1.5]
            lRadio = 1 + mapTo0_1(THRESHOLD_L, THRESHOLD_M) * 0.5f;          // [1,1.5]
            tbRadio = 1 - mapTo0_1(THRESHOLD_L, THRESHOLD_M) / 3;           // [1 , 2/3]
        }
        if (THRESHOLD_M < animatedValue && animatedValue <= THRESHOLD_A) {
            rRadio = 1.5f - mapTo0_1(THRESHOLD_M, THRESHOLD_A) * 0.5f;     //  [1.5,1]
            lRadio = 1.5f - mapTo0_1(THRESHOLD_M, THRESHOLD_A) * (1.5f - BOUND_RADIO);      //反弹效果，进场 内弹boundRadio
            tbRadio = (mapTo0_1(THRESHOLD_M, THRESHOLD_A) + 2) / 3;        // [ 2/3,1]
        }
        if (THRESHOLD_A < animatedValue && animatedValue <= 1f) {
            rRadio = 1;
            tbRadio = 1;
            lRadio = BOUND_RADIO + mapTo0_1(THRESHOLD_A, 1) * (1 - BOUND_RADIO);     //反弹效果，饱和
        }
        if (animatedValue == 1 || animatedValue == 0) {  //防止极其粗暴的滑动
            rRadio = 1f;
            lRadio = 1f;
            tbRadio = 1f;
        }

        boolean isTrans = false;
        float transX = (nextPosition - currentPosition) * (mWidth * 1f / (totalCount + 1));
        if (THRESHOLD_L <= animatedValue && animatedValue <= THRESHOLD_A) {
            isTrans = true;

            transX = transX * (animatedValue - THRESHOLD_L) / (THRESHOLD_A - THRESHOLD_L);
        }
        if (THRESHOLD_A < animatedValue && animatedValue <= 1) {
            isTrans = true;
        }
        if (isTrans) {
            canvas.translate(transX, 0);
        }

        bounce2RightRound();

        if (!direction) {
            mPath.transform(matrix);
        }

        canvas.drawPath(mPath, mPaint);
    }

    /**
     * 通过 path 将向右弹射的动画绘制出来
     * 如果要绘制向左的动画，只要设置path的transform(matrix)即可
     */
    private void bounce2RightRound() {
        mPath.reset();
        mPath.moveTo(p0.x, p0.y * tbRadio);
        mPath.cubicTo(p1.x, p1.y * tbRadio, p2.x * rRadio, p2.y, p3.x * rRadio, p3.y);
        mPath.cubicTo(p4.x * rRadio, p4.y, p5.x, p5.y * tbRadio, p6.x, p6.y * tbRadio);
        mPath.cubicTo(p7.x, p7.y * tbRadio, p8.x * lRadio, p8.y, p9.x * lRadio, p9.y);
        mPath.cubicTo(p10.x * lRadio, p10.y, p11.x, p11.y * tbRadio, p0.x, p0.y * tbRadio);
        mPath.close();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        mWidth = w;
        mHeight = h;
        initCountPos();
        invalidate();
    }

    //    @Override
//    public boolean onTouchEvent(MotionEvent event) {
//
//        switch (event.getAction()) {
//            case MotionEvent.ACTION_MOVE:
//            case MotionEvent.ACTION_DOWN
//
//                p2 = new PointF(event.getX(), event.getY() - mRadius * BEZIER_FACTOR);
//                p3 = new PointF(event.getX(), event.getY());
//                p4 = new PointF(event.getX(), event.getY() + mRadius * BEZIER_FACTOR);
//
//                Log.d("=====", " x = " + event.getX() + ",  y = " + event.getY());
//                invalidate();
//                break;
//        }
//
//        return true;
//    }

    private void initCountPos() {
        bezPos = new float[totalCount];
        xPivotPos = new float[totalCount];
        for (int i = 0; i < totalCount; i++) {
            bezPos[i] = mWidth * 1f / (totalCount + 1) * (i + 1);
            xPivotPos[i] = mWidth * 1f / (totalCount + 1) * (i + 1) + mRadius;
        }
    }

    private int getIndicatorMargin() {
        if (totalCount == 1) {
            return 0;
        }
        int availableWidth = mWidth - getPaddingLeft() - getPaddingRight();
        return (availableWidth - totalCount * 2 * mRadius) / (totalCount - 1);
    }

    private float mapTo0_1(float minValue, float maxValue) {
        return (animatedValue - minValue) / (maxValue - minValue);
    }

    //////////////////////////////////////////////////////////////////////////////
    //////////                                                          //////////
    //////////                  public methods                          //////////
    //////////                                                          //////////
    //////////////////////////////////////////////////////////////////////////////

    public void startAnimator() {
        if (animator != null) {
            if (animator.isRunning()) {
                return;
            }
            animator.start();
        } else {
            animator = ValueAnimator.ofFloat(0, 1f).setDuration(1500);
            animator.setInterpolator(interpolator);
            animator.addUpdateListener(animation -> {
                animatedValue = (float) animation.getAnimatedValue();
                invalidate();
            });

            animator.addListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animator) {
                    isAnimating = true;
                }

                @Override
                public void onAnimationEnd(Animator animator) {
                    isAnimating = false;
                    currentPosition = nextPosition;
                    if (nextPosition >= totalCount - 1 && direction) {
                        direction = false;
                    }

                    if (nextPosition <= 0 && !direction) {
                        direction = true;
                    }

                    if (direction) {
                        nextPosition++;
                    } else {
                        nextPosition--;
                    }

                }

                @Override
                public void onAnimationCancel(Animator animator) {
                    isAnimating = false;
                    currentPosition = nextPosition;
                }

                @Override
                public void onAnimationRepeat(Animator animator) {
                }
            });

            animator.start();
        }
    }

    //////////////////////////////////////////////////////////////////////////////
    //////////                                                          //////////
    //////////              getter and setter                           //////////
    //////////                                                          //////////
    //////////////////////////////////////////////////////////////////////////////

    public int getRadius() {
        return mRadius;
    }

    public void setRadius(int radius) {
        this.mRadius = radius;
        updateRadius();
    }

    private void updateRadius() {
        p0 = new PointF(0, -mRadius);//mRadius圆的半径
        p6 = new PointF(0, mRadius);

        p1 = new PointF(mRadius * BEZIER_FACTOR, -mRadius);//bezFactor即0.5519...
        p5 = new PointF(mRadius * BEZIER_FACTOR, mRadius);

        p2 = new PointF(mRadius, -mRadius * BEZIER_FACTOR);
        p4 = new PointF(mRadius, mRadius * BEZIER_FACTOR);

        p3 = new PointF(mRadius, 0);
        p9 = new PointF(-mRadius, 0);

        p11 = new PointF(-mRadius * BEZIER_FACTOR, -mRadius);
        p7 = new PointF(-mRadius * BEZIER_FACTOR, mRadius);

        p10 = new PointF(-mRadius, -mRadius * BEZIER_FACTOR);
        p8 = new PointF(-mRadius, mRadius * BEZIER_FACTOR);
    }

    public int getFillColor() {
        return mFillColor;
    }

    public void setFillColor(@ColorInt int fillColor) {
        this.mFillColor = fillColor;
        mPaint.setColor(mFillColor);
        invalidate();
    }

    public int getBorderColorColor() {
        return mFillColor;
    }

    public void setBorderColor(@ColorInt int borderColor) {
        this.mBorderColor = borderColor;
        mBorderPaint.setColor(mBorderColor);
        invalidate();
    }

    public int getCurrentPosition() {
        return currentPosition;
    }

    public void setCurrentPosition(int currentPosition) {
        this.currentPosition = currentPosition;
    }

    public int getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }

    public int getAnimationDuration() {
        return mAnimationDuration;
    }

    public void setAnimationDuration(int duration) {
        mAnimationDuration = duration;
    }

}
