package me.fresh.lee.kotlintest.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

/**
 * @author lihuayong
 * @version 1.0
 * @description PathRotateView
 * @date 2019-08-22 18:15
 */
public class PathRotateView extends View {

    private Path path;
    private Path dstPath;
    private Paint paint;
    private Paint paint2;

    public PathRotateView(Context context) {
        super(context);
        init();
    }

    public PathRotateView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public PathRotateView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        paint2 = new Paint();
        paint2.setColor(Color.BLUE);
        paint2.setStrokeWidth(20);
        paint2.setStyle(Paint.Style.FILL_AND_STROKE);
        paint2.setAntiAlias(true);

        paint = new Paint();
        paint.setColor(Color.RED);
        paint.setStrokeWidth(20);
        paint.setStyle(Paint.Style.FILL_AND_STROKE);
        paint.setAntiAlias(true);

        path = new Path();
        dstPath = new Path();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int cx = getWidth() >> 1;
        int cy = getHeight() >> 1;

        path.moveTo(0, 0);
        path.lineTo(0 + 200, 0);
//        canvas.translate(cx, cy);

        Matrix matrix = new Matrix();
        matrix.setRotate(10);
        path.transform(matrix, dstPath);
        canvas.translate(cx, cy);
        canvas.drawLine(0,0 ,50,0, paint2);

        canvas.drawPath(dstPath, paint);

    }
}
