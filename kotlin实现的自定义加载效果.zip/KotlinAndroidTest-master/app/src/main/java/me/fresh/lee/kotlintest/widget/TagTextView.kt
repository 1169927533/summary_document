package me.fresh.lee.kotlintest.widget

import android.content.Context
import androidx.appcompat.widget.AppCompatTextView
import android.util.AttributeSet
import android.util.Log
import android.view.View
import me.fresh.lee.kotlintest.R

/**
 * Created by lihuayong on 2018/9/21.
 */
class TagTextView : AppCompatTextView {

    private var mStateFixedInvest = false
    private var mStateShareOutBonus = false
    private var mStateRedeem = false
    private var mState: Int = 0

    //文字背景对应的状态（定投、分红、赎回等），可以扩展
    companion object {
        const val STATE_FIXED_INVEST = 0
        const val STATE_SHARE_OUT_BONUS = 1
        const val STATE_REDEEM = 2
    }

    private val STATE_LIST1 = intArrayOf(R.attr.state_fixed_invest)
    private val STATE_LIST2 = intArrayOf(R.attr.state_share_out_bonus)
    private val STATE_LIST3 = intArrayOf(R.attr.state_redeem)

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        initView(context, attrs)
    }

    constructor(context: Context, attrs: AttributeSet, defStyleAttr: Int) : super(context, attrs, defStyleAttr) {
        initView(context, attrs)
    }

    private fun initView(context: Context, attrs: AttributeSet?) {
        if (attrs != null) {
            val a = context.obtainStyledAttributes(attrs, R.styleable.TagTextView)
            mStateFixedInvest = a.getBoolean(R.styleable.TagTextView_state_fixed_invest, false)
            mStateShareOutBonus = a.getBoolean(R.styleable.TagTextView_state_share_out_bonus, false)
            mStateRedeem = a.getBoolean(R.styleable.TagTextView_state_redeem, false)
            a.recycle()
            if (mStateFixedInvest) {
                setState(STATE_FIXED_INVEST)
                return
            }
            if (mStateShareOutBonus) {
                setState(STATE_SHARE_OUT_BONUS)
                return
            }
            if (mStateRedeem) {
                setState(STATE_REDEEM)
                return
            }
        }
    }

    fun setState(state: Int) {
        changeState(state)
        refreshDrawableState()
    }

    private fun changeState(state: Int) {
        this.mState = state
        mStateFixedInvest = STATE_FIXED_INVEST == state
        mStateShareOutBonus = STATE_SHARE_OUT_BONUS == state
        mStateRedeem = STATE_REDEEM == state
    }

    private fun hasSystemState(state: IntArray): Boolean {
        val length = state.size
        for (i in 0 until length) {
            if (state[i] == android.R.attr.state_pressed || state[i] == android.R.attr.state_checked ||
                    state[i] == android.R.attr.state_selected || state[i] == android.R.attr.state_focused) {
                return true
            }
        }
        return false
    }

    override fun onCreateDrawableState(extraSpace: Int): IntArray {
        Log.i("LEE", "onCreateDrawableState")
        val drawableState = super.onCreateDrawableState(extraSpace + 1)
        if (hasSystemState(drawableState)) {
            return super.onCreateDrawableState(extraSpace)
        }

        if (mStateFixedInvest) {
            View.mergeDrawableStates(drawableState, STATE_LIST1)
        }
        if (mStateShareOutBonus) {
            View.mergeDrawableStates(drawableState, STATE_LIST2)
        }
        if (mStateRedeem) {
            View.mergeDrawableStates(drawableState, STATE_LIST3)
        }

        return drawableState

    }
}