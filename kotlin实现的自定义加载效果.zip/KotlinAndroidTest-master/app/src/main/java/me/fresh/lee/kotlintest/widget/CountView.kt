package me.fresh.lee.kotlintest.widget

import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.os.Bundle
import android.os.Parcelable
import android.util.AttributeSet
import android.util.Log
import android.view.View
import androidx.annotation.Keep
import me.fresh.lee.kotlintest.R

/**
 *
 * @description    CountView
 * @author         lihuayong
 * @date           2019/7/5 22:38
 * @version        1.0
 */
class CountView @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    /**
     * text 画笔
     */
    private lateinit var mTextPaint: Paint

    /**
     * text size
     */
    private var mTextSize: Float = DEFAULT_TEXT_SIZE

    /**
     * text color
     */
    private var mTextColor: Int = DEFAULT_TEXT_COLOR

    /**
     * text animation end color
     */
    private var mEndTextColor: Int = DEFAULT_TEXT_COLOR

    /**
     * 计数
     */
    private var mCount = 0
    /**
     * mTexts[0]是不变的部分，mTexts[1]原来的部分，mTexts[2]变化后的部分
     */
    private lateinit var mTexts: Array<String>

    /**
     * text 坐标
     */
    private lateinit var mTextPoints: Array<PointF>

    private var mMaxOffsetY: Float = 0.toFloat()
    private var mMinOffsetY: Float = 0.toFloat()

    private var mOldOffsetY: Float = 0.toFloat()
    private var mNewOffsetY: Float = 0.toFloat()

    /**
     * 是否是增大
     */
    private var bigger = true

    companion object {
        private const val DEFAULT_TEXT_COLOR = 0xffcccccc.toInt()
        private const val DEFAULT_TEXT_SIZE = 15f
        private const val COUNT_ANIM_DURING = 250
    }

    init {
        val typedArray = context.obtainStyledAttributes(attrs, R.styleable.CountView)
        mCount = typedArray.getInt(R.styleable.CountView_cv_count, 0)
        mTextColor = typedArray.getColor(R.styleable.CountView_cv_text_color, DEFAULT_TEXT_COLOR)
        mTextSize = typedArray.getDimension(R.styleable.CountView_cv_text_size, sp2px(context, 15f).toFloat())
        typedArray.recycle()

        init()
    }

    private fun init() {
        mTexts = arrayOf("", "", "")
        mTextPoints = arrayOf(PointF(), PointF(), PointF())
        calculateChangeNum(0)

        mMinOffsetY = 0f
        mMaxOffsetY = mTextSize

        mEndTextColor = Color.argb(0, Color.red(mTextColor), Color.green(mTextColor), Color.blue(mTextColor))

        mTextPaint = Paint()
        mTextPaint.isAntiAlias = true
        mTextPaint.textSize = mTextSize
        mTextPaint.color = mTextColor
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(getDefaultMeasureSize(widthMeasureSpec, getContentWidth() + paddingLeft + paddingRight),
                getDefaultMeasureSize(heightMeasureSpec, getContentHeight() + paddingTop + paddingBottom))
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)

        calculateLocation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        //不变的部分
        mTextPaint.color = mTextColor
        canvas.drawText(mTexts[0], mTextPoints[0].x, mTextPoints[0].y, mTextPaint)

        //变化前部分
        canvas.drawText(mTexts[1], mTextPoints[1].x, mTextPoints[1].y, mTextPaint)

        //变化后部分
        canvas.drawText(mTexts[2], mTextPoints[2].x, mTextPoints[2].y, mTextPaint)

        Log.d("======", "x = ${mTextPoints[2].x},y = ${mTextPoints[2].y}")
        Log.d("======", "width = ${this.width}, height = ${this.height}")
    }

    override fun onSaveInstanceState(): Parcelable? {
        val data = Bundle()
        data.putParcelable("superData", super.onSaveInstanceState())
        data.putInt("count", mCount)
        data.putFloat("textSize", mTextSize)
        data.putInt("textColor", mTextColor)
        return data
    }

    override fun onRestoreInstanceState(state: Parcelable) {
        val data = state as Bundle
        val superData = data.getParcelable<Parcelable>("superData")
        super.onRestoreInstanceState(superData)

        mCount = data.getInt("count", 0)
        mTextSize = data.getFloat("textSize", sp2px(context, DEFAULT_TEXT_SIZE).toFloat())
        mTextColor = data.getInt("textColor", DEFAULT_TEXT_COLOR)

        init()
    }

    private fun getContentWidth(): Int {
        return Math.ceil(mTextPaint.measureText(mCount.toString()).toDouble()).toInt()
    }

    private fun getContentHeight(): Int {
        return mTextSize.toInt()
    }

    @Suppress("unused")
    @Keep
    fun setTextOffsetY(offsetY: Float) {
        this.mOldOffsetY = offsetY//变大是从[0,1]，变小是[0,-1]
        if (bigger) {//从下到上[-1,0]
            this.mNewOffsetY = offsetY - mMaxOffsetY
        } else {//从上到下[1,0]
            this.mNewOffsetY = mMaxOffsetY + offsetY
        }
        calculateLocation()
        postInvalidate()
    }

    private fun calculateLocation() {
        val text = mCount.toString()
        val textWidth = mTextPaint.measureText(text) / text.length
        val unChangeWidth = textWidth * mTexts[0].length

        val fontMetrics = mTextPaint.fontMetricsInt
        val y = (paddingTop + (getContentHeight() - fontMetrics.bottom - fontMetrics.top) / 2).toFloat()

        mTextPoints[0].x = paddingLeft.toFloat()
        mTextPoints[1].x = (paddingLeft + unChangeWidth)
        mTextPoints[2].x = (paddingLeft + unChangeWidth)

        mTextPoints[0].y = y
        mTextPoints[1].y = y - mOldOffsetY
        mTextPoints[2].y = y - mNewOffsetY
    }

    fun calculateChangeNum(change: Int) {
        if (change == 0) {
            mTexts[0] = mCount.toString()
            mTexts[1] = ""
            mTexts[2] = ""
            return
        }

        val oldNum = mCount.toString()
        val newNum = (mCount + change).toString()

        for (i in 0 until oldNum.length) {
            val oldC = oldNum[i]
            val newC = newNum[i]
            if (oldC != newC) {
                mTexts[0] = if (i == 0) "" else newNum.substring(0, i)
                mTexts[1] = oldNum.substring(i)
                mTexts[2] = newNum.substring(i)
                break
            }
        }
        mCount += change
        startAnim(change > 0)
    }

    private fun startAnim(isToBigger: Boolean) {
        bigger = isToBigger
        val textOffsetY = ObjectAnimator.ofFloat(this, "textOffsetY", mMinOffsetY, if (isToBigger) mMaxOffsetY else -mMaxOffsetY)
        textOffsetY.duration = COUNT_ANIM_DURING.toLong()
        textOffsetY.start()
    }

}