package me.fresh.lee.kotlintest.activity

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Html
import android.text.SpannableString
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import me.fresh.lee.kotlintest.R
import me.fresh.lee.kotlintest.adapter.RollingTextAdapter
import me.fresh.lee.kotlintest.bean.Course
import me.fresh.lee.kotlintest.bean.LOLPlayer
import me.fresh.lee.kotlintest.bean.RollMessage
import me.fresh.lee.kotlintest.util.DateUtils
import me.fresh.lee.kotlintest.widget.CircleCheckbox
import me.fresh.lee.kotlintest.widget.CirclePercentBar
import me.fresh.lee.kotlintest.widget.MyClickableSpan
import me.fresh.lee.kotlintest.widget.TextViewSwitcher
import kotlinx.android.synthetic.main.activity_test.*
import kotlinx.android.synthetic.main.layout_rolling_text_item.view.*
import java.util.*


class TestActivity : BaseActivity() {
    private val tag = "TAG_MainActivity"

    private val data = ArrayList<RollMessage>()

    private val courses = ArrayList<Course>()

    private var containerLayout: LinearLayout? = null

    private var circlePercentBar: CirclePercentBar? = null

    private lateinit var checkBox: CircleCheckbox
    private var mNameArray: Array<String> = arrayOf("黄金", "货币", "港股", "美股", "其他")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setTheme(R.style.AppTheme)
        setContentView(R.layout.activity_test)

        title = "主页"
        initData()

        checkBox = findViewById(R.id.cb_circle)
        checkBox.setOnClickListener {
            checkBox.toggle()
        }

//        circle_bar.setData(arrayOf(10f, 30f, 15f, 35f, 10f))

        with(tvLink!!) {
            this.text = Html.fromHtml("<a href='https://www.baidu.com'>点我</a>")
            val ss = SpannableString("点我访问百度")
//        ss.setSpan(URLSpan("https://www.baidu.com"), 0, 6, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            ss.setSpan(object : MyClickableSpan() {
                override fun onClick(view: View?) {
                    view!!.context.startActivity(Intent().apply {
                        action = Intent.ACTION_VIEW
                        data = Uri.parse("https://www.baidu.com")
                    })
                }
            }, 0, 6, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            this.text = ss
//        tvLink.autoLinkMask = Linkify.WEB_URLS
            this.movementMethod = LinkMovementMethod.getInstance()
        }

        with(text_flipper!!) {
            setFlipInterval(3000)
            setOnItemClickListener(object : TextViewSwitcher.OnItemClickListener {
                override fun onClick(position: Int) {
//                Toast.makeText(this@TestActivity, "item 被点击$position", Toast.LENGTH_SHORT).show()
                    data[position].display(this@TestActivity)
                }
            })

            setAdapter(object : RollingTextAdapter() {
                override fun getCount(): Int {
                    return data.size
                }

                override fun getView(context: Context, position: Int): View {
                    return View.inflate(context, R.layout.layout_rolling_text_item, null).apply {
                        tv_content.text = data[position].message
                        tv_content_2.text = data[(position + 1) % data.size].message
                        tv_date.text = DateUtils.getPublishTimeDescription(data[position].publishDate)
                        tv_date_2.text = DateUtils.getPublishTimeDescription(data[(position + 1) % data.size].publishDate)
                    }
                }
            })
            startFlipping()
        }

        tag_text.setOnClickListener {
            Log.i(tag, "click TextView ")
            var f1 = (25 * Math.random()).toFloat()
            var f2 = (35 * Math.random()).toFloat()
            var f3 = (30 * Math.random()).toFloat()
            var f4 = (10 * Math.random()).toFloat()
            var f5 = 100 - f1 - f2 - f3 - f4

            circle_bar.setData(floatArrayOf(f1, f2, f3, f4, f5), true)
            me.fresh.lee.kotlintest.util.AnimationUtils.startTextColorAnimator(tvColorTest)
        }

        fun getCircleRotation(): Animation {
            return AnimationUtils.loadAnimation(this@TestActivity, R.anim.circle_rorate_anim).apply {
                interpolator = LinearInterpolator()
            }
        }

        btn_control.setOnClickListener {
        }

        containerLayout = findViewById(R.id.ll_container)

        val uzi = LOLPlayer("uzi", 21, "bottom")
        val letme = uzi.copy(name = "letme", position = "top")
        val ming = LOLPlayer("ming", 20, "support")
        Log.d(tag, uzi.toString())
        Log.d(tag, letme.toString())
        Log.d(tag, ming.toString())
    }


    private fun initData() {
        val nd = (1000 * 60 * 60 * 24).toLong()
        val nh = (1000 * 60 * 60).toLong()
        val nm = (1000 * 60).toLong()
        data.add(RollMessage("手中雕刻生花 刀锋千转蜿蜒成画", R.mipmap.tab_assets_select, System.currentTimeMillis() - nd - nh))
        data.add(RollMessage("盛名功德塔 是桥畔某处人家", R.mipmap.zqb_asset_status_ic_1, System.currentTimeMillis() - 3 * nd - nh))
        data.add(RollMessage("春风绕过发梢红纱 刺绣赠他", R.mipmap.tab_more_select, System.currentTimeMillis() - 5 * nh))
        data.add(RollMessage("眉目刚烈拟作妆嫁", R.mipmap.zqb_asset_status_ic_6, System.currentTimeMillis() - 16 * nm))
        data.add(RollMessage("轰烈流沙枕上白发 杯中酒比划", R.mipmap.zqb_asset_status_ic_1, System.currentTimeMillis() - 16 * nh))
        data.add(RollMessage("年少风雅鲜衣怒马 也不过一刹那", R.mipmap.zqb_asset_status_ic_5, System.currentTimeMillis() - 8 * nh))
        data.add(RollMessage("难免疏漏儿时檐下 莫测变化", R.mipmap.zqb_asset_status_ic_6, System.currentTimeMillis() - 3 * nm))
        data.add(RollMessage("隔却山海 转身从容煎茶", R.mipmap.zqb_asset_status_ic_8, System.currentTimeMillis() - nd + nh))
        data.add(RollMessage("一生长 重寄一段过往", R.mipmap.zqb_asset_status_ic_8, System.currentTimeMillis() - nd + nh))
        for (i in 0..19) {
            courses.add(Course(i, "title$i"))
        }

    }

    private fun resetData() {
        val nd = (1000 * 60 * 60 * 24).toLong()
        val nh = (1000 * 60 * 60).toLong()
        val nm = (1000 * 60).toLong()
        data.clear()
        data.add(RollMessage("Passion is sweet", R.mipmap.tab_assets_select, System.currentTimeMillis() - nd - nh))
        data.add(RollMessage("Love makes weak", R.mipmap.zqb_asset_status_ic_1, System.currentTimeMillis() - 3 * nd - nh))
        data.add(RollMessage("You said you cherised freedom so", R.mipmap.tab_more_select, System.currentTimeMillis() - 5 * nh))
        data.add(RollMessage("You refused to let it go", R.mipmap.zqb_asset_status_ic_6, System.currentTimeMillis() - 16 * nm))
        data.add(RollMessage("Follow your faith ", R.mipmap.zqb_asset_status_ic_1, System.currentTimeMillis() - 16 * nh))
        data.add(RollMessage("Love and hate", R.mipmap.zqb_asset_status_ic_5, System.currentTimeMillis() - 8 * nh))
        data.add(RollMessage("never failed to seize the day", R.mipmap.zqb_asset_status_ic_6, System.currentTimeMillis() - 3 * nm))
        data.add(RollMessage("Don't give yourself away", R.mipmap.zqb_asset_status_ic_8, System.currentTimeMillis() - nd + nh))
        data.add(RollMessage("Oh when the night falls", R.mipmap.zqb_asset_status_ic_8, System.currentTimeMillis() - nd + nh))
        for (i in 0..19) {
            courses.add(Course(i, "title$i"))
        }
    }

    public override fun onResume() {
        super.onResume()
    }

    override fun onPause() {
        super.onPause()
    }

}
