package me.fresh.lee.kotlintest.inflater

import android.content.Context
import android.view.View
import android.view.ViewGroup

/**
 * Created by lihuayong on 2018/9/21.
 */
interface DataViewInflater<T> {
    fun inflate(context: Context, parent: ViewGroup?, data: T?): View?
}