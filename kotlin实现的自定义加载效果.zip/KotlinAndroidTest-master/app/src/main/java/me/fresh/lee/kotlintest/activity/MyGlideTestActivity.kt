package me.fresh.lee.kotlintest.activity

import android.app.Activity
import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.activity_my_glide_test.*
import me.fresh.lee.kotlintest.R
import me.fresh.lee.kotlintest.glidee.Glidee
import me.fresh.lee.kotlintest.glidee.RequestListener

/**
 *
 * @description    MyGlideTestActivity
 * @author         lihuayong
 * @date           2019/7/20 0:14
 * @version        1.0
 */
class MyGlideTestActivity : AppCompatActivity() {

    companion object {
        private const val REQUEST_EXTERNAL_STORAGE: Int = 0x1002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_glide_test)

        verifyStoragePermission(this)
    }

    private fun verifyStoragePermission(activity: Activity) {
//        try {
//            val permission = ActivityCompat.checkSelfPermission(activity,
//                    "android.permission.WRITE_EXTERNAL_STORAGE")
//            if (permission != PackageManager.PERMISSION_GRANTED) {
//                ActivityCompat.requestPermissions(activity, PERMISSION_STORAGE, REQUEST_EXTERNAL_STORAGE)
//            }
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }

    }

    fun single(view: View) {
        val imageView = ImageView(this)
        imageView.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        imageView.scaleType = ImageView.ScaleType.CENTER_CROP
        ll_pic_container.addView(imageView)

        Glidee.with(this).load("https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1563563878686&di=79af2f7a368daec84b6b0ca7363abc50&imgtype=0&src=http%3A%2F%2Fwww.33lc.com%2Farticle%2FUploadPic%2F2012-8%2F2012831183573135.jpg")
                .placeHolder(R.drawable.cat)
                .listener(object : RequestListener {
                    override fun onSuccess(bitmap: Bitmap?) {
                        Toast.makeText(this@MyGlideTestActivity, "下载成功", Toast.LENGTH_SHORT).show()
                    }

                    override fun onFailure() {
                        Toast.makeText(this@MyGlideTestActivity, "下载失败", Toast.LENGTH_SHORT).show()
                    }

                })
                .into(imageView)
    }

    private val urlArray = arrayOf("https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1563566012043&di=b9f68b9ee88f0b98457ddc8041951f0d&imgtype=0&src=http%3A%2F%2Fhbimg.b0.upaiyun.com%2Fceab4f97e8786d456e5f044cdec25642c1740eafae69-Gjui5l_fw658",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1563566090124&di=f576f6ee1c6ad7be480db9704a1930bb&imgtype=0&src=http%3A%2F%2Fimg.tupianzj.com%2Fuploads%2Fallimg%2F160618%2F9-16061PT417.jpg",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1563566099957&di=4ec2c017e9d33113de2d2d8d014c519f&imgtype=0&src=http%3A%2F%2Fimg.mp.itc.cn%2Fupload%2F20160321%2Fc40e1ef85ec44540ac5a2eeed9d12cf8_th.jpg",
            "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=2030621752,493134360&fm=26&gp=0.jpg",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1563566164004&di=e48f7f0b02b47b8f6289325c261c4d01&imgtype=0&src=http%3A%2F%2Fhbimg.b0.upaiyun.com%2Fc98fdb7d25fe47de2caf23ae0360eee0bb31e5022b750-z2qZqd_fw658",
            "https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=2821428106,2846644984&fm=26&gp=0.jpg",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1564160717&di=36f473e357e82d45b17e83a99b481c3b&imgtype=jpg&er=1&src=http%3A%2F%2Fimgk.zol.com.cn%2Fdiybbs%2F5137%2Fa5136813_s.jpg",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1563566313944&di=0fb066804cb50055122f7a6215fcd4be&imgtype=0&src=http%3A%2F%2Fimg1.ph.126.net%2FERQWPVnuiFjS0cn0jLHgoA%3D%3D%2F4850939748731994502.jpg",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1563566390307&di=991820be20bcc74cd841c7120d5f59df&imgtype=0&src=http%3A%2F%2Fpic1.win4000.com%2Fwallpaper%2F2017-12-22%2F5a3cebbee305b.jpg",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1563566414845&di=28488a52c56653ee354a51ad99764659&imgtype=0&src=http%3A%2F%2Fpic30.nipic.com%2F20130605%2F7447430_130608947000_2.jpg",
            "https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1563566577119&di=5d389bdf0d5a26e39ac8a67b8ea70fdf&imgtype=0&src=http%3A%2F%2Fp5.qhimg.com%2Ft012eff1293156dc0c6.jpg"
    )

    fun more(view: View) {
        for (i in 0 until 10) {
            val imageView = ImageView(this)
            imageView.layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            imageView.scaleType = ImageView.ScaleType.CENTER_CROP
            ll_pic_container.addView(imageView)

            Glidee.with(this).load(urlArray[i])
                    .placeHolder(R.drawable.cat)
                    .listener(object : RequestListener {
                        override fun onSuccess(bitmap: Bitmap?) {
                            Toast.makeText(this@MyGlideTestActivity, "下载成功", Toast.LENGTH_SHORT).show()
                        }

                        override fun onFailure() {
                            Toast.makeText(this@MyGlideTestActivity, "下载失败", Toast.LENGTH_SHORT).show()
                        }

                    })
                    .into(imageView)
        }
    }
}