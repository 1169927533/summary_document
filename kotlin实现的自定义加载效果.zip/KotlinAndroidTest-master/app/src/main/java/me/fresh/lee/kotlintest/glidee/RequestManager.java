package me.fresh.lee.kotlintest.glidee;

import java.util.concurrent.LinkedBlockingQueue;

/**
 * @author lihuayong
 * @version 1.0
 * @description RequestManager
 * @date 2019/7/19 23:55
 */
@SuppressWarnings("WeakerAccess")
public class RequestManager {

    //创建队列
    private LinkedBlockingQueue<BitmapRequest> requestQueue = new LinkedBlockingQueue<>();

    //船舰一个线程数组
    private BitmapDispatcher[] dispatchers;

    private static class HOLDER {
        private static RequestManager INSTANCE = new RequestManager();
    }

    private RequestManager() {
        start();
    }

    private void start() {
        stop();
        startAllDispatcher();
    }

    private void stop() {
        if (dispatchers != null && dispatchers.length > 0) {
            for (BitmapDispatcher dispatcher : dispatchers) {
                if (!dispatcher.isInterrupted()) {
                    dispatcher.interrupt();
                }
            }
        }
    }

    private void startAllDispatcher() {
        //获取手机支持的单个队列支持的线程数
        int threadCount = Runtime.getRuntime().availableProcessors();
        dispatchers = new BitmapDispatcher[threadCount];
        for (int i = 0; i < dispatchers.length; i++) {
            BitmapDispatcher dispatcher = new BitmapDispatcher(requestQueue);
            dispatcher.start();

            //将每个dispatcher存放到数组，方便统一管理
            dispatchers[i] = dispatcher;
        }
    }

    public static RequestManager getInstance() {
        return HOLDER.INSTANCE;
    }

    public void addBitmapRequest(BitmapRequest request) {
        if (request == null) {
            return;
        }

        if (!requestQueue.contains(request)) {
            requestQueue.add(request);
        }
    }
}
