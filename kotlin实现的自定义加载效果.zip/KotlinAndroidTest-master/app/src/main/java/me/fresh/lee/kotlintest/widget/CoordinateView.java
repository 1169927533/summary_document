package me.fresh.lee.kotlintest.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.ColorInt;
import androidx.annotation.Keep;
import androidx.annotation.Nullable;

/**
 * @author lee
 * @date 6/30/2019
 */

@SuppressWarnings({"unused", "FieldCanBeLocal"})
@Keep
public class CoordinateView extends View {

    private static final int DEFAULT_HEIGHT = 400;
    private static final int DEFAULT_WIDTH = 300;

    private static final int NUM_OF_MARK = 5;
    private static final int SIZE_OF_UNIT = 100;

    /**
     * Y轴 刻度值
     */
    private static final float Y_AXIS_TEXT_WIDTH = 80f;

    /**
     * X轴 刻度值
     */
    private static final float X_AXIS_TEXT_HEIGHT = 40f;

    /**
     * 上下左右padding
     */
    private static final float PADDING = 30f;

    /**
     * 坐标轴箭头部分长度
     */
    private static final float AXES_EXTRA = 40f;

    /**
     * 原点坐标
     */
    private float originX;
    private float originY;

    /**
     * 坐标轴
     */
    private float yAxisHeight;

    private float xAxisWidth;

    private int textSize = 32;

    /**
     * 坐标轴画笔
     */
    private Paint axisPaint;

    /**
     * 网格线画笔
     */
    private Paint gridLinesPaint;
    private Path gridLinesPath;

    /**
     * 函数曲线画笔
     */
    private Paint functionLinePaint;

    private Paint textPaint;

    @ColorInt
    private int gridLineColor = Color.CYAN;

    @ColorInt
    private int axesColor = Color.BLACK;

    @ColorInt
    private int axesTextColor = Color.BLACK;

    private Function function;


    public CoordinateView(Context context) {
        this(context, null);
    }

    public CoordinateView(Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CoordinateView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        initPaint();
    }

    private void initPaint() {
        axisPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        axisPaint.setColor(axesColor);
        axisPaint.setStyle(Paint.Style.STROKE);
        axisPaint.setStrokeWidth(2);

        gridLinesPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        gridLinesPaint.setColor(gridLineColor);
        gridLinesPaint.setStyle(Paint.Style.STROKE);
        gridLinesPaint.setStrokeWidth(2);
        gridLinesPaint.setPathEffect(new DashPathEffect(new float[]{5, 10}, 0));
        gridLinesPath = new Path();


        functionLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        functionLinePaint.setColor(Color.RED);
        functionLinePaint.setStyle(Paint.Style.STROKE);
        functionLinePaint.setStrokeWidth(2);

        textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        textPaint.setColor(axesTextColor);
        textPaint.setStyle(Paint.Style.FILL);
        textPaint.setTextSize(textSize);
        textPaint.setStrokeWidth(2);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        setMeasuredDimension(measureView(widthMeasureSpec), measureView(heightMeasureSpec));
    }

    private int measureView(int measureSpec) {
        int result;
        int specMode = View.MeasureSpec.getMode(measureSpec);
        int specSize = View.MeasureSpec.getSize(measureSpec);
        if (specMode == View.MeasureSpec.EXACTLY) {
            result = specSize;
        } else {
            result = DEFAULT_WIDTH * 2;
            if (specMode == View.MeasureSpec.AT_MOST) {
                result = Math.min(result, specSize);
            }
        }
        return result;

    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int width = getWidth();
        int height = getHeight();

        yAxisHeight = height - PADDING * 2 - AXES_EXTRA * 2;
        originX = PADDING + Y_AXIS_TEXT_WIDTH;
        originY = PADDING + AXES_EXTRA + yAxisHeight / 2.0f;
        drawAxes(canvas);
        drawFunctionLine(canvas);

    }

    private void drawAxes(Canvas canvas) {
        int height = getHeight();
        float yAxisBottomY = height - PADDING;
        float xAxisEndY = PADDING + yAxisHeight / 2.0f + AXES_EXTRA + Y_AXIS_TEXT_WIDTH;
        //绘制Y轴
        canvas.drawLine(originX, PADDING, originX, yAxisBottomY, axisPaint);

        float arrowLength = 20f;
        double degree = Math.PI / 6;
        //箭头
        canvas.drawLine(originX, PADDING, (float) (originX - arrowLength * Math.sin(degree)), (float) (PADDING + arrowLength * Math.cos(degree)), axisPaint);
        canvas.drawLine(originX, PADDING, (float) (originX + arrowLength * Math.sin(degree)), (float) (PADDING + arrowLength * Math.cos(degree)), axisPaint);

        //绘制X轴
        canvas.drawLine(originX, originY, xAxisEndY, originY, axisPaint);
        //箭头
        canvas.drawLine(xAxisEndY, originY, (float) (xAxisEndY - arrowLength * Math.cos(degree)), (float) (originY - arrowLength * Math.sin(degree)), axisPaint);
        canvas.drawLine(xAxisEndY, originY, (float) (xAxisEndY - arrowLength * Math.cos(degree)), (float) (originY + arrowLength * Math.sin(degree)), axisPaint);

        //单位长度
        float unit = yAxisHeight / 10;
        //画Y轴刻度线 以及网格线
        for (int i = -NUM_OF_MARK; i <= NUM_OF_MARK; i++) {
            canvas.drawLine(originX, originY + i * unit, originX - 10f, originY + i * unit, axisPaint);
            //网格线
            if (i != 0) {
                gridLinesPath.reset();
                gridLinesPath.moveTo(originX, originY + i * unit);
                gridLinesPath.lineTo(xAxisEndY - AXES_EXTRA, originY + i * unit);
                canvas.drawPath(gridLinesPath, gridLinesPaint);
                canvas.drawText(String.valueOf((float) 2 * i / 10f), originX - Y_AXIS_TEXT_WIDTH, originY + i * unit + 10f, textPaint);
            } else {
                canvas.drawText("O", originX - Y_AXIS_TEXT_WIDTH, originY + i * unit + 10f, textPaint);
            }
        }

        //画X轴刻度线
        for (int i = 1; i <= NUM_OF_MARK; i++) {
            canvas.drawLine(originX + i * unit, originY, originX + i * unit, originY + 10f, axisPaint);
            canvas.drawText(String.valueOf((float) 2 * i / 10f), originX + i * unit - 20f, originY + X_AXIS_TEXT_HEIGHT, textPaint);
        }
    }

    private void drawFunctionLine(Canvas canvas) {
        float unit;//函数  绘制100个点
        unit = yAxisHeight / 200;
        for (int deltaX = 1; deltaX <= SIZE_OF_UNIT; deltaX++) {
            if (function != null) {
                canvas.drawLine(originX + (deltaX - 1) * unit, originY + function.f((deltaX - 1) / 100f) * 100 * unit,
                        originX + deltaX * unit, originY + function.f(deltaX / 100f) * 100 * unit, functionLinePaint);
            }
        }
    }

    public void reDraw() {
        invalidate();
    }

    public void setFunction(Function f) {
        this.function = f;
    }

    public interface Function {
        /**
         * 函数 y = f(x)
         *
         * @param x x
         * @return y
         */
        float f(float x);
    }

    public int getGridLineColor() {
        return gridLineColor;
    }

    public void setGridLineColor(int gridLineColor) {
        this.gridLineColor = gridLineColor;
    }

    public int getAxesColor() {
        return axesColor;
    }

    public void setAxesColor(int axesColor) {
        this.axesColor = axesColor;
    }

    public int getAxesTextColor() {
        return axesTextColor;
    }

    public void setAxesTextColor(int axesTextColor) {
        this.axesTextColor = axesTextColor;
    }

    public int getTextSize() {
        return textSize;
    }

    public void setTextSize(int textSize) {
        this.textSize = textSize;
    }
}
