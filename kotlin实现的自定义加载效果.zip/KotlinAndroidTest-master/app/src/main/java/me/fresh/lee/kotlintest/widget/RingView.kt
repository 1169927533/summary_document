package me.fresh.lee.kotlintest.widget


import android.animation.FloatArrayEvaluator
import android.animation.TimeInterpolator
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.TypedArray
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Region
import android.os.Bundle
import android.os.Parcelable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat
import me.fresh.lee.kotlintest.R

/**
 *
 * @description    RingView 环状图
 * @author         lihuayong
 * @date           2019-08-16 17:51
 * @version        1.0
 */
class RingView @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    companion object {
        const val DEFAULT_ANIMATION_DURATION = 500L
        const val ITEM_UNSELECTED = -1
        const val DEFAULT_EXTRA_WIDTH = 20f
    }

    /**
     * 圆环宽度
     */
    private var mArcWidth: Float = 0f

    /**
     * 选中状态下额外的宽度
     */
    private var mExtraWidth: Float = DEFAULT_EXTRA_WIDTH

    private var mOuterRadius: Float = 0f
    private var mInnerRadius = 0f

    /**
     * 图形中心点
     */
    private var mCenterX = 0f
    private var mCenterY = 0f

    /**
     * path 绘制的辅助坐标
     */
    private var startX: Float = 0f
    private var startY: Float = 0f
    private var endX: Float = 0f
    private var endY: Float = 0f

    private lateinit var mArcPath: Path
    private lateinit var mArcPaint: Paint

    private var mAnimator: ValueAnimator? = null

    /**
     * 动画时长
     */
    private var mDuration = DEFAULT_ANIMATION_DURATION

    /**
     * 外圆的外接矩形
     */
    private lateinit var mOuterRect: RectF

    /**
     * 内圆的外接矩形
     */
    private lateinit var mInnerRect: RectF

    /**
     * 选中状态下的外接矩形
     */
    private lateinit var mBigRectF: RectF
    private lateinit var mSmallRectF: RectF

    /**
     * 点击区域检测辅助region
     */
    private var mRegion: ArrayList<Region>? = null
    private lateinit var clip: Region

    /**
     * 被选中的item id
     */
    private var onSelectId: Int = ITEM_UNSELECTED

    /**
     * 被选中触发的回调事件
     */
    private var onSelectListener: ((selectId: Int, index: Int) -> Unit)? = null

    private var mDataArray: FloatArray? = null
    private var mColorArray: IntArray = intArrayOf(R.color.j_yellow, R.color.green, R.color.f_link, R.color.wrong_red, R.color.brown_bright)

    init {
        init(context, attrs, defStyleAttr)
        initPaint()
    }

    private fun init(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) {
        val ta: TypedArray = context!!.obtainStyledAttributes(attrs, R.styleable.RingView, defStyleAttr, 0)
        mArcWidth = ta.getDimensionPixelOffset(R.styleable.RingView_rv_arcWidth, context.resources.getDimensionPixelOffset(R.dimen.dp_20)).toFloat()
        mExtraWidth = ta.getDimensionPixelOffset(R.styleable.RingView_rv_extraWidth, DEFAULT_EXTRA_WIDTH.toInt()).toFloat()
        mOuterRadius = ta.getDimensionPixelOffset(R.styleable.RingView_rv_circleRadius, context.resources.getDimensionPixelOffset(R.dimen.margin_100)).toFloat()
        mDuration = ta.getInteger(R.styleable.RingView_rv_duration, DEFAULT_ANIMATION_DURATION.toInt()).toLong()
        mInnerRadius = mOuterRadius - mArcWidth

        if (isInEditMode) {
            mDataArray = floatArrayOf(0.1f, 0.2f, 0.3f, 0.4f)
            onSelectId = 1
        }

        if (mInnerRadius <= 0) {
            throw IllegalArgumentException("circleRadius must set bigger than arcWidth!!!")
        }

        if (mInnerRadius < mExtraWidth) {
            throw IllegalArgumentException("circleRadius suggest set bigger than sum of arcWidth and extraWidth)!!!")
        }
        ta.recycle()
    }

    private fun initPaint() {
        mArcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL_AND_STROKE
        }

        mOuterRect = RectF()

        mInnerRect = RectF()

        mBigRectF = RectF()

        mSmallRectF = RectF()

        mArcPath = Path()

        clip = Region()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val size = ((mOuterRadius + mExtraWidth) * 2).toInt()
        setMeasuredDimension(measureView(widthMeasureSpec, size + paddingLeft + paddingRight),
                measureView(heightMeasureSpec, size + paddingTop + paddingBottom))
    }

    private fun measureView(measureSpec: Int, defaultSize: Int): Int {
        var result: Int
        val specMode = MeasureSpec.getMode(measureSpec)
        val specSize = MeasureSpec.getSize(measureSpec)
        if (specMode == MeasureSpec.EXACTLY) {
            result = specSize
        } else {
            result = defaultSize
            if (specMode == MeasureSpec.AT_MOST) {
                result = Math.min(result, specSize)
            }
        }
        return result
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        mOuterRadius = (Math.min(w - paddingLeft - paddingRight, h - paddingTop - paddingBottom) shr 1).toFloat() - mExtraWidth
        mCenterX = (w shr 1).toFloat()
        mCenterY = (h shr 1).toFloat()

        setRectAndRadii()

        clip.set(0, 0, w, h)
    }

    private fun setRectAndRadii() {
        mInnerRadius = mOuterRadius - mArcWidth

        mOuterRect.set(mCenterX - mOuterRadius,
                mCenterY - mOuterRadius,
                mCenterX + mOuterRadius,
                mCenterY + mOuterRadius)

        mInnerRect.set(mCenterX - mInnerRadius,
                mCenterY - mInnerRadius,
                mCenterX + mInnerRadius,
                mCenterY + mInnerRadius)

        mBigRectF.set(mCenterX - mOuterRadius - mExtraWidth,
                mCenterY - mOuterRadius - mExtraWidth,
                mCenterX + mOuterRadius + mExtraWidth,
                mCenterY + mOuterRadius + mExtraWidth)

        mSmallRectF.set(mCenterX - mInnerRadius + mExtraWidth,
                mCenterY - mInnerRadius + mExtraWidth,
                mCenterX + mInnerRadius - mExtraWidth,
                mCenterY + mInnerRadius - mExtraWidth)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        mDataArray?.let {
            //保证从顶部开始绘制，因为Path的0度默认是x轴，所以设置开始角度为-90度
            var startDegree = -90f
            for ((index, e) in it.withIndex()) {
                //将数据从百分比转化为度数（不是弧度！）
                val sweepDegree = e * 359.9f
                mArcPaint.color = ContextCompat.getColor(context, mColorArray[index % mColorArray.size])
                resetArcPath1(startDegree, sweepDegree, index)
                canvas.drawPath(mArcPath, mArcPaint)
                startDegree += sweepDegree

                mRegion?.get(index)?.setPath(mArcPath, clip)
                //另外一种绘制方式，绘制一段，旋转画布再继续绘制，这种方式方便绘制，但是不利于计算点击事件，故弃用
//                resetArcPath(sweepDegree)
//                canvas.drawPath(mArcPath, mArcPaint)
//                //旋转一下，开始绘制下一段圆弧
//                canvas.rotate(sweepDegree, mCenterX, mCenterY)
            }
        }
    }

    private fun resetArcPath(degree: Float) {
        mArcPath.reset()
        mArcPath.moveTo(startX, startY)
        mArcPath.lineTo(endX, endY)
        mArcPath.arcTo(mOuterRect, 0f, degree, false)
        mArcPath.lineTo(calculateX(mCenterX, mInnerRadius, degree),
                calculateY(mCenterY, mInnerRadius, degree))
        mArcPath.arcTo(mInnerRect, degree, -degree, false)
    }

    private fun resetArcPath1(startDegree: Float, degree: Float, index: Int) {
        val endDegree = startDegree + degree
        mArcPath.reset()
        mArcPath.moveTo(calculateX(mCenterX, mInnerRadius, startDegree),
                calculateY(mCenterY, mInnerRadius, startDegree))
        //如果是选中的item 则展示选中状态
        if (onSelectId == index) {
            mArcPath.lineTo(calculateX(mCenterX, mOuterRadius + mExtraWidth, startDegree),
                    calculateY(mCenterY, mOuterRadius + mExtraWidth, startDegree))
            mArcPath.arcTo(mBigRectF, startDegree, degree, false)
            mArcPath.lineTo(calculateX(mCenterX, mInnerRadius - mExtraWidth, endDegree),
                    calculateY(mCenterY, mInnerRadius - mExtraWidth, endDegree))
            mArcPath.arcTo(mSmallRectF, endDegree, -degree, false)
        } else {
            mArcPath.lineTo(calculateX(mCenterX, mOuterRadius, startDegree),
                    calculateY(mCenterY, mOuterRadius, startDegree))
            mArcPath.arcTo(mOuterRect, startDegree, degree, false)
            mArcPath.lineTo(calculateX(mCenterX, mInnerRadius, endDegree),
                    calculateY(mCenterY, mInnerRadius, endDegree))
            mArcPath.arcTo(mInnerRect, endDegree, -degree, false)
        }
        mArcPath.close()
    }

    private fun calculateX(x: Float, r: Float, degree: Float): Float {
        return (x + r * Math.cos(Math.toRadians(degree.toDouble()))).toFloat()
    }

    private fun calculateY(x: Float, r: Float, degree: Float): Float {
        return (x + r * Math.sin(Math.toRadians(degree.toDouble()))).toFloat()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (MotionEvent.ACTION_DOWN == event.action) {
            val x = event.x
            val y = event.y
            run breaking@{
                mRegion?.forEachIndexed { index, region ->
                    if (region.contains(x.toInt(), y.toInt())) {
                        onSelectId = if (onSelectId == index) {
                            ITEM_UNSELECTED
                        } else {
                            index
                        }

                        invalidate()
                        onSelectListener?.invoke(onSelectId, index)
                        return@breaking
                    }
                }
            }
        }

        return super.onTouchEvent(event)
    }

    /**
     * 设置颜色数组
     */
    fun setColorArray(colors: IntArray?) {
        colors?.let {
            this.mColorArray = it
        }
    }

    fun setOnSelectListener(listener: (selectId: Int, index: Int) -> Unit) {
        this.onSelectListener = listener
    }

    fun setArcWidth(arcWidth: Float) {
        this.mArcWidth = arcWidth
        setRectAndRadii()
        postInvalidate()
    }

    fun setExtraWidth(extraWidth: Float) {
        this.mExtraWidth = extraWidth
        setRectAndRadii()
        postInvalidate()
    }

    fun setDutation(duration: Long) {
        this.mDuration = duration
    }

    fun setData(list: List<Float>?, animate: Boolean = true, interpolator: TimeInterpolator = DecelerateInterpolator()) {
        setData(list?.toFloatArray(), animate, interpolator)
    }

    /**
     * @param dataArr 数据源
     * @param animate 是否展示动画
     * @param interpolator 动画插值器
     */
    fun setData(dataArr: FloatArray?, animate: Boolean = true, interpolator: TimeInterpolator = DecelerateInterpolator()) {
        dataArr?.let {
            onSelectId = ITEM_UNSELECTED
            mDataArray = transformData(dataArr)

            if (!animate) {
                invalidate()
                return
            }

            mAnimator = ValueAnimator.ofObject(FloatArrayEvaluator(FloatArray(it.size)), FloatArray(it.size), mDataArray).apply {
                this.duration = mDuration
                addUpdateListener {
                    val values = animatedValue as FloatArray
                    mDataArray = values
                    invalidate()
                }
                this.interpolator = interpolator
            }

            startAnimation()
        }
    }

    fun startAnimation() {
        onSelectId = ITEM_UNSELECTED
        mAnimator?.let {
            if (it.isRunning) {
                it.cancel()
            }

            it.start()
        }
    }

    /**
     * 转化数据，并且初始化辅助Region数组
     */
    private fun transformData(data: FloatArray): FloatArray {
        val sum = data.sum()
        mRegion = ArrayList(data.size)
        val array = FloatArray(data.size)
        data.forEachIndexed { index, d ->
            array[index] = d / sum
            mRegion?.add(Region())
        }
        return array
    }


    override fun onSaveInstanceState(): Parcelable? {
        val data = Bundle()
        data.putParcelable("superData", super.onSaveInstanceState())
        data.putFloatArray("data_array", mDataArray)
        return data
    }

    override fun onRestoreInstanceState(state: Parcelable) {
        val data = state as Bundle
        val superData = data.getParcelable<Parcelable>("superData")
        super.onRestoreInstanceState(superData)

        mDataArray = data.getFloatArray("data_array")
        initPaint()
        startAnimation()
    }
}