package me.fresh.lee.kotlintest.glidee;

import android.graphics.Bitmap;

/**
 * @author lihuayong
 * @version 1.0
 * @description RequestListener
 * @date 2019/7/19 23:01
 */
public interface RequestListener {
    void onSuccess(Bitmap bitmap);

    void onFailure();
}
