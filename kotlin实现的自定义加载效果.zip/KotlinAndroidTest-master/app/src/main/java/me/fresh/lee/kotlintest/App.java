package me.fresh.lee.kotlintest;

import android.app.Application;
import android.util.Log;

import me.fresh.lee.kotlintest.util.UtilsKt;

/**
 * @author lihuayong
 * @version 1.0
 * @description App
 * @date 2019-07-24 15:02
 */
public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("AppList",""+ UtilsKt.getInstalledAppList(this));
    }
}
