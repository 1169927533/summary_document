package me.fresh.lee.kotlintest.bean

import android.content.Context
import android.widget.Toast

/**
 * Created by lihuayong on 2018/9/21.
 */
data class RollMessage(var message: String, var imgId: Int, var publishDate: Long) {
    fun display(context: Context) {
        Toast.makeText(context, this.toString(), Toast.LENGTH_LONG).show()
    }
}
