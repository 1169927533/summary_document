package me.fresh.lee.kotlintest.widget.ring

import android.animation.ObjectAnimator
import android.content.Context
import android.content.res.TypedArray
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.annotation.Keep
import androidx.core.content.ContextCompat
import me.fresh.lee.kotlintest.R

/**
 *
 * @description    PieView1
 * @author         lihuayong
 * @date           2019/8/26 20:18
 * @version        1.0
 */
class PieView1 @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    companion object {
        const val DEFAULT_ANIMATION_DURATION = 500L
    }

    private var mArcWidth: Float = 0f
    private var mExtraWidth: Float = 0f
    private var mCircleRadius: Int = 0

    private lateinit var mArcPaint: Paint
    private lateinit var mArcRectF: RectF

    /**
     * 动画进度控制
     */
    private val mProgressAnimator: ObjectAnimator = ObjectAnimator.ofFloat(this, "progress", 0f, 1f)
            .apply {
                duration = DEFAULT_ANIMATION_DURATION
                this.interpolator = DecelerateInterpolator()
            }
    private var mProgress: Float = 1f

    private var mDataArray: FloatArray? = null
    private var mColorArray: IntArray = intArrayOf(R.color.j_yellow, R.color.green, R.color.f_link, R.color.wrong_red, R.color.brown_bright)

    init {
        init(context, attrs, defStyleAttr)
        initPaint()
    }

    private fun init(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) {
        val ta: TypedArray = context!!.obtainStyledAttributes(attrs, R.styleable.PieView1, defStyleAttr, 0)
        mArcWidth = ta.getDimensionPixelOffset(R.styleable.PieView1_pv_arcWidth, context.resources.getDimensionPixelOffset(R.dimen.dp_20)).toFloat()
        mExtraWidth = ta.getDimensionPixelOffset(R.styleable.PieView1_pv_extraWidth, context.resources.getDimensionPixelOffset(R.dimen.dp_30)).toFloat()
        mCircleRadius = ta.getDimensionPixelOffset(R.styleable.PieView1_pv_circleRadius, context.resources.getDimensionPixelOffset(R.dimen.margin_100))
        ta.recycle()

        if (isInEditMode) {
            mDataArray = floatArrayOf(0.1f, 0.2f, 0.3f, 0.4f)
        }
    }

    private fun initPaint() {
        mArcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = mArcWidth
            strokeCap = Paint.Cap.BUTT
        }

        //圆弧的外接矩形
        mArcRectF = RectF()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        setMeasuredDimension(measureView(widthMeasureSpec), measureView(heightMeasureSpec))
    }

    private fun measureView(measureSpec: Int): Int {
        var result: Int
        val specMode = View.MeasureSpec.getMode(measureSpec)
        val specSize = View.MeasureSpec.getSize(measureSpec)
        if (specMode == View.MeasureSpec.EXACTLY) {
            result = specSize
        } else {
            result = mCircleRadius * 2
            if (specMode == View.MeasureSpec.AT_MOST) {
                result = Math.min(result, specSize)
            }
        }
        return result
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        mArcRectF.set((width shr 1) - mCircleRadius + mArcWidth / 2,
                (height shr 1) - mCircleRadius + mArcWidth / 2,
                (width shr 1) + mCircleRadius - mArcWidth / 2,
                (height shr 1) + mCircleRadius - mArcWidth / 2)

        mDataArray?.let {
            //ensure start to draw on the top
            canvas.rotate(-90f, (width shr 1).toFloat(), (height shr 1).toFloat())

            var acc = 0f
            for ((index, e) in it.withIndex()) {
                val angle = e * 359.9f * mProgress
                mArcPaint.color = ContextCompat.getColor(context, mColorArray[index % mColorArray.size])
                canvas.drawArc(mArcRectF, acc, angle, false, mArcPaint)
                acc += angle
            }

            //rotate back
            canvas.rotate(90f, (width shr 1).toFloat(), (height shr 1).toFloat())
        }
    }


    /**
     * 转化数据
     */
    private fun transformData(data: FloatArray): FloatArray {
        val sum = data.sum()
        val array = FloatArray(data.size)
        data.forEachIndexed { index, d ->
            array[index] = d / sum
        }
        return array
    }

    fun setData(dataArr: FloatArray, animate: Boolean) {
        mDataArray = transformData(dataArr)
        if (!animate) {
            invalidate()
            return
        }

        startAnimation()
    }

    fun startAnimation() {
        mProgressAnimator.let {
            if (it.isRunning) {
                it.cancel()
            }

            it.start()
        }
    }

    /**
     * 动画进度控制
     */
    @Keep
    @Suppress("unused")
    private fun setProgress(progress: Float) {
        this.mProgress = progress
        invalidate()
    }

}