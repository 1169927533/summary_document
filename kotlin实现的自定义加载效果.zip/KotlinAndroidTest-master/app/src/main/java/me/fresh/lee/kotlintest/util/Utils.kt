package me.fresh.lee.kotlintest.util

import android.app.Activity
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Point
import android.os.Build
import android.view.WindowManager
import android.renderscript.ScriptIntrinsicBlur
import android.renderscript.Allocation
import android.renderscript.Element
import android.renderscript.RenderScript
import android.util.Log


/**
 *
 * @description    Utils
 * @author         lihuayong
 * @date           2019-07-01 16:24
 * @version        1.0
 */

/**
 * get bitmap from resource
 * when Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP,
 * [attention!!!] there will be some problem when directly use
 * BitmapFactory.decodeResource from resource
 */
fun getBitmap(context: Context, vectorDrawableId: Int): Bitmap? {
    var bitmap: Bitmap? = null
    if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
        val vectorDrawable = context.getDrawable(vectorDrawableId)
        if (vectorDrawable != null) {
            bitmap = Bitmap.createBitmap(vectorDrawable.intrinsicWidth,
                    vectorDrawable.intrinsicHeight, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap!!)
            vectorDrawable.setBounds(0, 0, canvas.width, canvas.height)
            vectorDrawable.draw(canvas)
        }
    } else {
        bitmap = BitmapFactory.decodeResource(context.resources, vectorDrawableId)
    }
    return bitmap
}

fun Activity.getScreenSize(): Point {
    val wm = this.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    val outSize = Point()
    wm.defaultDisplay.getSize(outSize)
    return outSize
}

fun Context.dp2px(dimen: Int): Int {
    val scale = this.resources.displayMetrics.density
    return (dimen * scale + 0.5f).toInt()
}

/**
 * 方法描述：获得应用安装的程序列表
 */
fun getInstalledAppList(context: Context): String {
    var result = ""
    // 获取手机内所有应用
    val packageInfoList = context.packageManager.getInstalledPackages(0)
    for (packageInfo in packageInfoList) {
        // 判断是否为非系统预装的应用程序
        if (packageInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM <= 0) {
            result = if (result.isEmpty()) {
                packageInfo.applicationInfo.loadLabel(context.packageManager).toString()
            } else {
                result + "," + packageInfo.applicationInfo.loadLabel(context.packageManager).toString()
            }
        }
    }
    return result
}

fun gasussBlur(context: Context, source: Bitmap, radius: Int): Bitmap {
    //(1)
    val renderScript = RenderScript.create(context)

    Log.i("gasussBlur", "scale size:" + source.width + "*" + source.height)

    // Allocate memory for Renderscript to work with
    //(2)
    val input = Allocation.createFromBitmap(renderScript, source)
    val output = Allocation.createTyped(renderScript, input.type)
    //(3)
    // Load up an instance of the specific script that we want to use.
    val scriptIntrinsicBlur = ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript))
    //(4)
    scriptIntrinsicBlur.setInput(input)
    //(5)
    // Set the blur radius
    scriptIntrinsicBlur.setRadius(radius.toFloat())
    //(6)
    // Start the ScriptIntrinisicBlur
    scriptIntrinsicBlur.forEach(output)
    //(7)
    // Copy the output to the blurred bitmap
    output.copyTo(source)
    //(8)
    renderScript.destroy()

    return source
}

private fun getStatusBarHeight(res: Resources): Int {
    return res.getDimensionPixelOffset(res.getIdentifier("status_bar_height", "dimen", "android"))
}