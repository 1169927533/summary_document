package me.fresh.lee.kotlintest.widget


import android.animation.ObjectAnimator
import android.content.Context
import android.content.res.TypedArray
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Region
import android.os.Bundle
import android.os.Parcelable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.annotation.Keep
import androidx.core.content.ContextCompat
import me.fresh.lee.kotlintest.R
import java.io.Serializable

/**
 *
 * @description    RingView 环状图
 * @author         lihuayong
 * @date           2019-08-16 17:51
 * @version        1.0
 */
class PieView @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    companion object {
        const val DEFAULT_ANIMATION_DURATION = 500L
        const val ITEM_UNSELECTED = -1
        const val DEFAULT_EXTRA_WIDTH_PERCENT = 0.1f
        const val DEFAULT_ARC_WIDTH_PERCENT = 0.2f

        const val ASSET_TYPE_P2P = "P2P" // 网贷

        const val ASSET_TYPE_FUND = "FUND" // 基金

        const val ASSET_TYPE_BALANCE = "BALANCE" // 可用余额

        const val ASSET_TYPE_BANK = "BANK_FINANCE" //银行理财

        const val ASSET_TYPE_WALLET = "WALLET" // 宜钱包

        const val ASSET_TYPE_MONEY_PLUS = "MONEY_PLUS" // 零钱+

        const val ASSET_TYPE_OLD_WALLET = "OLD_WALLET" // 旧版宜钱包
    }

    private val COLOR_P2P = R.color.cbase_asset_p2p
    private val COLOR_FUND = R.color.cbase_asset_fund
    private val COLOR_BALANCE = R.color.cbase_asset_balance
    private val COLOR_BANK = R.color.cbase_asset_bank
    private val COLOR_WALLET = R.color.cbase_asset_wallet
    private val COLOR_MONEY_PLUS = R.color.cbase_asset_money
    private val COLOR_OLD_WALLET = R.color.cbase_asset_old_wallet
    private val COLOR_DEFAULT = R.color.cbase_asset_default


    /**
     * 圆环宽度
     */
    private var mArcWidthPercent: Float = DEFAULT_ARC_WIDTH_PERCENT

    /**
     * 选中状态下额外的宽度
     */
    private var mExtraWidthPercent: Float = DEFAULT_EXTRA_WIDTH_PERCENT

    private var mOuterRadius: Float = 0f
    private var mInnerRadius = 0f

    /**
     * 图形中心点
     */
    private var mCenterX = 0f
    private var mCenterY = 0f

    private lateinit var mArcPath: Path
    private lateinit var mArcPaint: Paint

    private var mProgressAnimator: ObjectAnimator? = null

    /**
     * 动画时长
     */
    private var mDuration = DEFAULT_ANIMATION_DURATION

    /**
     * 外圆的外接矩形
     */
    private lateinit var mOuterRect: RectF

    /**
     * 内圆的外接矩形
     */
    private lateinit var mInnerRect: RectF

    /**
     * 选中状态下的外接矩形
     */
    private lateinit var mBigRectF: RectF
    private lateinit var mSmallRectF: RectF

    /**
     * 点击区域检测辅助region
     */
    private var mRegion: ArrayList<Region>? = null
    private lateinit var clip: Region

    /**
     * 被选中的item id
     */
    private var onSelectId: Int = ITEM_UNSELECTED

    /**
     * 被选中触发的回调事件
     */
    private var onSelectListener: ((selectId: Int, index: Int) -> Unit)? = null

    private var mProgress: Float = 1f
    private var mItems: ArrayList<PieItem>? = null

    init {
        init(context, attrs, defStyleAttr)
        initPaint()
    }

    private fun init(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) {
        val ta: TypedArray = context!!.obtainStyledAttributes(attrs, R.styleable.RingView, defStyleAttr, 0)
        mArcWidthPercent = ta.getFloat(R.styleable.RingView_rv_arcWidth, DEFAULT_ARC_WIDTH_PERCENT)
        mExtraWidthPercent = ta.getFloat(R.styleable.RingView_rv_extraWidth, DEFAULT_EXTRA_WIDTH_PERCENT)
        mOuterRadius = ta.getDimensionPixelOffset(R.styleable.RingView_rv_circleRadius, 0).toFloat()
        mDuration = ta.getInteger(R.styleable.RingView_rv_duration, DEFAULT_ANIMATION_DURATION.toInt()).toLong()
        mInnerRadius = mOuterRadius - mOuterRadius * mArcWidthPercent

        if (isInEditMode) {
            mItems = arrayListOf(PieItem(ASSET_TYPE_FUND, 0.1), PieItem(ASSET_TYPE_MONEY_PLUS, 0.2), PieItem(ASSET_TYPE_WALLET, 0.3), PieItem(ASSET_TYPE_P2P, 0.4))
            onSelectId = 1
        }

        if (mArcWidthPercent < 0 || mArcWidthPercent > 1 - mExtraWidthPercent) {
            throw IllegalArgumentException("ArcWidth must set bigger than 0, and smaller than 1 - extraWidth")
        }

        ta.recycle()
    }

    private fun initPaint() {
        mArcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL_AND_STROKE
        }

        mOuterRect = RectF()

        mInnerRect = RectF()

        mBigRectF = RectF()

        mSmallRectF = RectF()

        mArcPath = Path()

        clip = Region()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        val size = ((mOuterRadius + mOuterRadius * mExtraWidthPercent) * 2).toInt()
        setMeasuredDimension(measureView(widthMeasureSpec, size + paddingLeft + paddingRight),
                measureView(heightMeasureSpec, size + paddingTop + paddingBottom))
    }

    private fun measureView(measureSpec: Int, defaultSize: Int): Int {
        var result: Int
        val specMode = MeasureSpec.getMode(measureSpec)
        val specSize = MeasureSpec.getSize(measureSpec)
        if (specMode == MeasureSpec.EXACTLY) {
            result = specSize
        } else {
            result = defaultSize
            if (specMode == MeasureSpec.AT_MOST) {
                result = Math.min(result, specSize)
            }
        }
        return result
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        mCenterX = (w shr 1).toFloat()
        mCenterY = (h shr 1).toFloat()

        setRectAndRadii(w, h)

        clip.set(0, 0, w, h)
    }

    private fun setRectAndRadii(w: Int, h: Int) {
        mOuterRadius = (Math.min(w - paddingLeft - paddingRight, h - paddingTop - paddingBottom) shr 1).toFloat() / (1 + mExtraWidthPercent)
        mInnerRadius = mOuterRadius - mOuterRadius * mArcWidthPercent
        val extraWidth = mOuterRadius * mExtraWidthPercent
        mOuterRect.set(mCenterX - mOuterRadius,
                mCenterY - mOuterRadius,
                mCenterX + mOuterRadius,
                mCenterY + mOuterRadius)

        mInnerRect.set(mCenterX - mInnerRadius,
                mCenterY - mInnerRadius,
                mCenterX + mInnerRadius,
                mCenterY + mInnerRadius)

        mBigRectF.set(mCenterX - mOuterRadius - extraWidth,
                mCenterY - mOuterRadius - extraWidth,
                mCenterX + mOuterRadius + extraWidth,
                mCenterY + mOuterRadius + extraWidth)

        mSmallRectF.set(mCenterX - mInnerRadius + extraWidth,
                mCenterY - mInnerRadius + extraWidth,
                mCenterX + mInnerRadius - extraWidth,
                mCenterY + mInnerRadius - extraWidth)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        mItems?.let {
            //保证从顶部开始绘制，因为Path的0度默认是x轴，所以设置开始角度为-90度
            var startDegree = -90f
            for ((index, e) in it.withIndex()) {
                //将数据从百分比转化为度数（不是弧度！）
                val sweepDegree: Float = (e.proportion * 359.9f).toFloat() * mProgress
                mArcPaint.color = ContextCompat.getColor(context, getPaintColor(e.type))
                resetArcPath(startDegree, sweepDegree, index)
                canvas.drawPath(mArcPath, mArcPaint)
                startDegree += sweepDegree

                mRegion?.get(index)?.setPath(mArcPath, clip)
            }
        }
    }

    private fun resetArcPath(startDegree: Float, degree: Float, index: Int) {
        val endDegree = startDegree + degree
        mArcPath.reset()
        mArcPath.moveTo(calculateX(mCenterX, mInnerRadius, startDegree),
                calculateY(mCenterY, mInnerRadius, startDegree))
        //如果是选中的item 则展示选中状态
        if (onSelectId == index) {
            mArcPath.lineTo(calculateX(mCenterX, mOuterRadius + mExtraWidthPercent, startDegree),
                    calculateY(mCenterY, mOuterRadius + mExtraWidthPercent, startDegree))
            mArcPath.arcTo(mBigRectF, startDegree, degree, false)
            mArcPath.lineTo(calculateX(mCenterX, mInnerRadius - mExtraWidthPercent, endDegree),
                    calculateY(mCenterY, mInnerRadius - mExtraWidthPercent, endDegree))
            mArcPath.arcTo(mSmallRectF, endDegree, -degree, false)
        } else {
            mArcPath.lineTo(calculateX(mCenterX, mOuterRadius, startDegree),
                    calculateY(mCenterY, mOuterRadius, startDegree))
            mArcPath.arcTo(mOuterRect, startDegree, degree, false)
            mArcPath.lineTo(calculateX(mCenterX, mInnerRadius, endDegree),
                    calculateY(mCenterY, mInnerRadius, endDegree))
            mArcPath.arcTo(mInnerRect, endDegree, -degree, false)
        }
        mArcPath.close()
    }

    private fun getPaintColor(type: String): Int {
        return when (type) {
            ASSET_TYPE_P2P -> COLOR_P2P
            ASSET_TYPE_FUND -> COLOR_FUND
            ASSET_TYPE_MONEY_PLUS -> COLOR_MONEY_PLUS
            ASSET_TYPE_OLD_WALLET -> COLOR_OLD_WALLET
            ASSET_TYPE_WALLET -> COLOR_WALLET
            ASSET_TYPE_BANK -> COLOR_BANK
            ASSET_TYPE_BALANCE -> COLOR_BALANCE
            else -> COLOR_DEFAULT
        }
    }

    private fun calculateX(x: Float, r: Float, degree: Float): Float {
        return (x + r * Math.cos(Math.toRadians(degree.toDouble()))).toFloat()
    }

    private fun calculateY(x: Float, r: Float, degree: Float): Float {
        return (x + r * Math.sin(Math.toRadians(degree.toDouble()))).toFloat()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (MotionEvent.ACTION_DOWN == event.action) {
            val x = event.x
            val y = event.y
            run breaking@{
                mRegion?.forEachIndexed { index, region ->
                    if (region.contains(x.toInt(), y.toInt())) {
                        onSelectId = if (onSelectId == index) {
                            ITEM_UNSELECTED
                        } else {
                            index
                        }

                        invalidate()
                        onSelectListener?.invoke(onSelectId, index)
                        return@breaking
                    }
                }
            }
        }

        return super.onTouchEvent(event)
    }

    fun setOnSelectListener(listener: (selectId: Int, index: Int) -> Unit) {
        this.onSelectListener = listener
    }

    fun setArcWidth(arcWidth: Float) {
        this.mArcWidthPercent = arcWidth
        setRectAndRadii(width, height)
        postInvalidate()
    }

    fun setExtraWidth(extraWidth: Float) {
        this.mExtraWidthPercent = extraWidth
        setRectAndRadii(width, height)
        postInvalidate()
    }

    fun setAnimatorDuration(duration: Long) {
        this.mDuration = duration
        mProgressAnimator?.duration = mDuration
    }

    @Keep
    fun setProgress(progress: Float) {
        this.mProgress = progress
        invalidate()
    }

    fun setData(list: ArrayList<PieItem>?) {
        onSelectId = ITEM_UNSELECTED
        list?.let {
            mItems = transformData(filterData(list))
            mProgressAnimator = ObjectAnimator.ofFloat(this, "progress", 0f, 1f)
                    .apply {
                        duration = mDuration
                        interpolator = DecelerateInterpolator()
                    }
            mProgressAnimator?.start()
        }
    }

    /**
     * 过滤空值
     */
    private fun filterData(list: List<PieItem>): ArrayList<PieItem> {
        val nList = ArrayList<PieItem>()
        for (i in list.indices) {
            if (list[i].proportion - 0.0001f > 0) {
                nList.add(list[i])
            }
        }
        return nList
    }

    /**
     * 转化数据，并且初始化辅助Region数组
     */
    private fun transformData(data: ArrayList<PieItem>): ArrayList<PieItem> {
        val sum = data.sumByDouble { it.proportion }
        mRegion = ArrayList(data.size)
        data.forEachIndexed { index, d ->
            data[index].proportion = d.proportion / sum
            mRegion?.add(Region())
        }
        return data
    }

    fun startAnimation() {
        onSelectId = ITEM_UNSELECTED
        mProgressAnimator?.let {
            if (it.isRunning) {
                it.end()
            }

            it.start()
        }
    }

    /**
     * 将所有块重置为未选中状态
     */
    fun resume() {
        if (onSelectId != ITEM_UNSELECTED) {
            onSelectId = ITEM_UNSELECTED
            invalidate()
        }
    }

    override fun onSaveInstanceState(): Parcelable? {
        val data = Bundle()
        data.putParcelable("superData", super.onSaveInstanceState())
        data.putSerializable("data_array", mItems)
        return data
    }

    override fun onRestoreInstanceState(state: Parcelable) {
        val data = state as Bundle
        val superData = data.getParcelable<Parcelable>("superData")
        super.onRestoreInstanceState(superData)

        mItems = data.getSerializable("data_array") as ArrayList<PieItem>?
        initPaint()
        startAnimation()
    }

    /**
     * 单个资产类型
     */
    class PieItem(var type: String, var proportion: Double) : Serializable
}