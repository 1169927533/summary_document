package me.fresh.lee.kotlintest.widget.explosion;

import android.graphics.Bitmap;
import android.graphics.Rect;

/**
 * @author lihuayong
 * @version 1.0
 * @description AbstractParticleFactory
 * @date 2019-07-13 20:36
 */
public abstract class AbstractParticleFactory {

    public AbstractParticleFactory() {

    }

    /**
     * 生成粒子
     *
     * @param bitmap bitmap
     * @param rect   rect
     * @return 生成粒子集合
     */
    public abstract AbstractParticle[][] generateParticles(Bitmap bitmap, Rect rect);
}
