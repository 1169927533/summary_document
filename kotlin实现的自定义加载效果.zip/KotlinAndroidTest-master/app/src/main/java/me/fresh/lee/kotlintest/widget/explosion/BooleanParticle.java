package me.fresh.lee.kotlintest.widget.explosion;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;

import static me.fresh.lee.kotlintest.widget.explosion.Utils.RANDOM;

/**
 * @author lihuayong
 * @version 1.0
 * @description BooleanParticle
 * @date 2019-07-13 22:11
 */
public class BooleanParticle extends AbstractParticle {

    private float radius = 8f;

    private float alpha;
    private Rect mBound;

    public BooleanParticle(int color, float x, float y, Rect bound) {
        super(color, x, y);
        mBound = bound;
    }

    @Override
    protected void draw(Canvas canvas, Paint paint) {
        paint.setColor(color);
        //这样透明颜色就不是黑色
        paint.setAlpha((int) (Color.alpha(color) * alpha));
        canvas.drawCircle(cx, cy, radius, paint);
    }

    @Override
    protected void calculate(float factor) {
        //制定粒子爆炸规则
        cx = cx + factor * RANDOM.nextInt(mBound.width()) * (RANDOM.nextFloat() - 0.5f);
        cy = cy + factor * RANDOM.nextInt(mBound.height()) * (RANDOM.nextFloat() - 0.5f);

        radius = radius - factor * RANDOM.nextInt(2);

        alpha = (1f - factor) * (1 + RANDOM.nextFloat());
    }
}
