package me.fresh.lee.kotlintest.widget

import android.text.TextPaint
import android.text.style.ClickableSpan

/**
 * Created by lihuayong on 2018/9/25.
 */
abstract class MyClickableSpan : ClickableSpan() {

    override fun updateDrawState(ds: TextPaint?) {
        super.updateDrawState(ds)
        ds!!.isUnderlineText = false
    }
}