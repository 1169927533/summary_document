package me.fresh.lee.kotlintest.util

import android.content.Context
import android.widget.Toast

object ToastUtils {

    fun showToast(context: Context, text: String?, duration: Int = Toast.LENGTH_SHORT) {
        Toast.makeText(context, text, duration).show()
    }

    fun showToast(context: Context, resId: Int, duration: Int = Toast.LENGTH_SHORT) {
        showToast(context, context.resources.getString(resId), duration)
    }

}