package me.fresh.lee.kotlintest.activity.draw

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import me.fresh.lee.kotlintest.R

/**
 *
 * @description    FlowLayoutActivity
 * @author         lihuayong
 * @date           2019-08-01 16:02
 * @version        1.0
 */
class FlowLayoutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_flow_layout)
    }
}