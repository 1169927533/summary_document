package me.fresh.lee.kotlintest.widget.explosion;

import android.graphics.Bitmap;
import android.graphics.Rect;

/**
 * @author lihuayong
 * @version 1.0
 * @description BooleanFactory
 * @date 2019-07-13 22:13
 */
public class BooleanFactory extends AbstractParticleFactory {

    private static final int PART_WH = 8;

    @Override
    public AbstractParticle[][] generateParticles(Bitmap bitmap, Rect rect) {
        int w = rect.width();
        int h = rect.height();
        int partWCount = w / PART_WH;
        int partHCount = h / PART_WH;

        //单个粒子在对应的bitmap中所占的大小

        int bitmap_part_w = bitmap.getWidth() / partWCount;
        int bitmap_part_h = bitmap.getHeight() / partWCount;

        AbstractParticle[][] particles = new AbstractParticle[partHCount][partWCount];

        for (int row = 0; row < partHCount; row++) {  //行
            for (int column = 0; column < partWCount; column++) {  //列
                //获取当前粒子所在位置颜色
                int color = bitmap.getPixel(column * bitmap_part_w, row * bitmap_part_h);

                float x = rect.left + PART_WH * column;
                float y = rect.top + PART_WH * row;

                particles[row][column] = new BooleanParticle(color, x, y, rect);
            }
        }
        return particles;
    }
}
