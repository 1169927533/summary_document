package me.fresh.lee.kotlintest.activity.draw

import android.animation.ObjectAnimator
import android.graphics.Color
import android.os.Bundle
import android.view.animation.AccelerateDecelerateInterpolator
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.drawable.DrawableCompat
import kotlinx.android.synthetic.main.activity_thumbs_up.*
import me.fresh.lee.kotlintest.R
import me.fresh.lee.kotlintest.widget.WaterView
import me.fresh.lee.kotlintest.widget.explosion.BooleanFactory
import me.fresh.lee.kotlintest.widget.explosion.ExplosionField
import me.fresh.lee.kotlintest.widget.likebutton.DotsView

/**
 *
 * @description    ThumbsUpActivity
 * @author         lihuayong
 * @date           2019/7/5 23:13
 * @version        1.0
 */
class ThumbsUpActivity : AppCompatActivity() {

    private lateinit var dotsView: DotsView
    private lateinit var waterView: WaterView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_thumbs_up)

        val explosionField = ExplosionField(this, BooleanFactory())
        explosionField.addListener(btn_add)
        explosionField.addListener(btn_sub)
        explosionField.addListener(logo)
        explosionField.addListener(like1)
        explosionField.addListener(like2)
        explosionField.addListener(like3)
        explosionField.addListener(like4)
        explosionField.addListener(like5)

//        like4.drawable.setTint(Color.parseColor("#2891f7"))
//        like5.drawable.setTint(Color.parseColor("#e3a600"))

        DrawableCompat.setTint(like4.drawable, Color.parseColor("#2891f7"))
        DrawableCompat.setTint(like5.drawable, Color.parseColor("#e3a600"))

        dotsView = dots
        waterView = water_view

        dotsView.setSize(200, 200)
        val dotsAnimator = ObjectAnimator.ofFloat<DotsView>(dotsView, DotsView.DOTS_PROGRESS, 0f, 1f)
        dotsAnimator.duration = 900
        dotsAnimator.startDelay = 50
        dotsAnimator.interpolator = AccelerateDecelerateInterpolator()


        btn_add.setOnClickListener {
            count_view.calculateChangeNum(1)
            thumbs_up.thumbsUpAnim()
            dotsAnimator.start()
            waterView.reset()
        }

        btn_sub.setOnClickListener {
            count_view.calculateChangeNum(-1)
            thumbs_up.thumbsDownAnim()
            dotsView.currentProgress = 0f
        }
    }
}