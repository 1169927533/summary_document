package me.fresh.lee.kotlintest.widget.drawable

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.drawable.Drawable
import androidx.annotation.ColorInt

/**
 *
 * @description    ChromeDrawable
 * @author         lihuayong
 * @date           2019-07-30 11:15
 * @version        1.0
 */
class ChromeDrawable : Drawable() {
    companion object {
        private const val DEFAULT_WIDTH = 100
        private const val DEFAULT_HEIGHT = 100

        /**
         * the smaller blue circle_white inside, the radius ratio
         */
        private const val INNER_RADIUS_RATIO = 400f / 1024f

        @ColorInt
        private const val COLOR_YELLOW = -0x733a1
        @ColorInt
        private const val COLOR_RED = -0x33a5b4
        @ColorInt
        private const val COLOR_GREEN = -0xb3619a
        @ColorInt
        private const val COLOR_BLUE = -0xa57312
    }

    private var SQRT_3 = Math.sqrt(3.0).toFloat()

    private val colors = intArrayOf(COLOR_RED, COLOR_GREEN, COLOR_YELLOW)

    /**
     * view width
     */
    private var mWidth = DEFAULT_WIDTH

    /**
     * view height
     */

    private var mHeight = DEFAULT_HEIGHT

    /**
     * logo radius
     */
    private var mRadius = DEFAULT_WIDTH shr 1

    /**
     * logo center point
     */
    private var pointO: PointF = PointF()

    /**
     * path start point
     */
    private var pointA: PointF = PointF()

    private var pointC: PointF = PointF()

    private val itemPath: Path = Path()
    private val itemPaint: Paint = Paint()

    init {
        itemPaint.color = colors[0]
        itemPaint.isAntiAlias = true
        itemPaint.style = Paint.Style.FILL_AND_STROKE
    }

    override fun getIntrinsicHeight(): Int {
        return mHeight
    }

    override fun getIntrinsicWidth(): Int {
        return mWidth
    }

    override fun onBoundsChange(bounds: Rect?) {
        super.onBoundsChange(bounds)
        mWidth = bounds?.width() ?: 0
        mHeight = bounds?.height() ?: 0
        mRadius = Math.min(mWidth, mHeight) shr 1
    }


    override fun draw(canvas: Canvas) {
        //init basic info
        pointO.set((mWidth shr 1).toFloat(), (mHeight shr 1).toFloat())
        val innerRadius = (mRadius shr 1).toFloat()

        //设置Path的起点坐标
        pointA.set(pointO.x - (mRadius shr 2) * SQRT_3, pointO.y + (mRadius shr 2))
        pointC.set(pointO.x + innerRadius * SQRT_3, pointO.y - innerRadius)

        //draw one of the parts
        itemPath.reset()
        //绘制弧AB
        itemPath.moveTo(pointA.x, pointA.y)
        itemPath.arcTo(pointO.x - innerRadius, pointO.y - innerRadius,
                pointO.x + innerRadius, pointO.y + innerRadius,
                150f, 120f, true)

        //绘制线段BC
        itemPath.lineTo(pointC.x, pointC.y)

        //绘制弧CD
        itemPath.arcTo(pointO.x - mRadius, pointO.y - mRadius,
                pointO.x + mRadius, pointO.y + mRadius,
                -30f, -120f, true)

        //绘制线段DA
        itemPath.lineTo(pointA.x, pointA.y)
        itemPath.close()

        //绘制单个 1/3的图形
        itemPaint.color = colors[0]
        canvas.drawPath(itemPath, itemPaint)

        //rotate canvas and draw another part
        canvas.rotate(-120f, pointO.x, pointO.y)
        itemPaint.color = colors[1]
        canvas.drawPath(itemPath, itemPaint)

        //continue rotate canvas and draw the last part
        canvas.rotate(-120f, pointO.x, pointO.y)
        itemPaint.color = colors[2]
        canvas.drawPath(itemPath, itemPaint)

        //draw the inner circle_white
        itemPaint.color = COLOR_BLUE
        canvas.drawCircle(pointO.x, pointO.y, mRadius * INNER_RADIUS_RATIO, itemPaint)
    }

    override fun setAlpha(alpha: Int) {
        itemPaint.alpha = alpha
        invalidateSelf()
    }

    override fun getOpacity(): Int {
        return PixelFormat.TRANSLUCENT
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        itemPaint.colorFilter = colorFilter
        invalidateSelf()
    }
}