package me.fresh.lee.kotlintest.activity.draw

import android.os.Bundle
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_ring.*
import me.fresh.lee.kotlintest.R
import me.fresh.lee.kotlintest.widget.PieView
import me.fresh.lee.kotlintest.widget.RingView
import java.util.ArrayList

/**
 *
 * @description    RingActivity
 * @author         lihuayong
 * @date           2019-08-20 11:51
 * @version        1.0
 */
class RingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ring)

        initData()

        ring_view.setAnimatorDuration(1000)

        btn_change.setOnClickListener {
            initData()
        }

        btn_animation.setOnClickListener {
            ring_view.startAnimation()
            pie_view.startAnimation()
        }

        sb_arc_width.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                ring_view.setArcWidth((dp(R.dimen.dp_38) + sb_arc_width.progress / 100f * dp(R.dimen.dp_20)))
                pie_view.setArcWidth(progress / 100f)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }
        })

        sb_extra_width.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                ring_view.setExtraWidth((dp(R.dimen.dp_10) + sb_extra_width.progress / 100f * dp(R.dimen.dp_10)))
                pie_view.setExtraWidth(progress / 100f)

            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }
        })
    }

    private fun initData() {
        val f1 = (25 * Math.random()).toFloat()
        val f2 = (35 * Math.random()).toFloat()
        val f3 = (30 * Math.random()).toFloat()
        val f4 = (10 * Math.random()).toFloat()
        val f5 = 100 - f1 - f2 - f3 - f4

//        ring_view.setData(arrayListOf(f1, f2, f3, f4, f5))
        ring_view.setData(floatArrayOf(f1, f2, f3, f4, f5), true)
        ring_view.setOnSelectListener { selectId, index ->
            if (selectId != RingView.ITEM_UNSELECTED) {
                Toast.makeText(this, "onSelect id = $index", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "onUnSelect id = $index", Toast.LENGTH_SHORT).show()
            }
        }

        val list1 = ArrayList<PieView.PieItem>()
        list1.add(PieView.PieItem(PieView.ASSET_TYPE_P2P, f1.toDouble()))
        list1.add(PieView.PieItem(PieView.ASSET_TYPE_FUND, f2.toDouble()))
        list1.add(PieView.PieItem(PieView.ASSET_TYPE_BALANCE, f3.toDouble()))
        list1.add(PieView.PieItem(PieView.ASSET_TYPE_BANK, f4.toDouble()))
        list1.add(PieView.PieItem(PieView.ASSET_TYPE_WALLET, f5.toDouble()))

        pie_view.setData(list1)

        pie_view.setOnSelectListener { selectId, index ->
            if (selectId != RingView.ITEM_UNSELECTED) {
                Toast.makeText(this, "onSelect id = $index", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "onUnSelect id = $index", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun dp(id: Int): Int {
        return resources.getDimensionPixelOffset(id)
    }
}