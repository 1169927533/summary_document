package me.fresh.lee.kotlintest.widget;

import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.animation.AccelerateDecelerateInterpolator;

import androidx.appcompat.widget.AppCompatTextView;

/**
 * @author lihuayong
 * @version 1.0
 * @description ShimmerTextView
 * @date 2019/7/17 22:42
 */
public class ShimmerTextView extends AppCompatTextView {
    private Paint mPaint;
    private int mDx;
    private ValueAnimator animator;
    private Matrix matrix;
    private LinearGradient mLinearGradient;

    private int[] colors = {0xffff0000, 0xff00ff00, 0xff0000ff, 0xffffff00, 0xff00ffff};
    private float[] pos = {0f, 0.2f, 0.4f, 0.6f, 1.0f};

    public ShimmerTextView(Context context) {
        this(context, null);
    }

    public ShimmerTextView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public ShimmerTextView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        mPaint = getPaint();
        matrix = new Matrix();
    }

    @SuppressLint("DrawAllocation")
    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);

        if (changed) {
            animator = ValueAnimator.ofInt(0, 2 * getMeasuredWidth());
            animator.addUpdateListener(animation -> {
                mDx = (Integer) animation.getAnimatedValue();
                postInvalidate();
            });
            animator.setInterpolator(new AccelerateDecelerateInterpolator());
            animator.setRepeatMode(ValueAnimator.RESTART);
            animator.setRepeatCount(ValueAnimator.INFINITE);
            animator.setDuration(3000);
            animator.start();

            mLinearGradient = new LinearGradient(-getMeasuredWidth(), 0, 0, 0,
                    colors,
                    pos,
                    Shader.TileMode.REPEAT
            );
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        //注意调用 onDraw的时机
        matrix.setTranslate(mDx, 0);
        mLinearGradient.setLocalMatrix(matrix);
        mPaint.setShader(mLinearGradient);

        super.onDraw(canvas);
    }

    public void stopAnim() {
        if (animator != null) {
            animator.cancel();
        }
    }
}