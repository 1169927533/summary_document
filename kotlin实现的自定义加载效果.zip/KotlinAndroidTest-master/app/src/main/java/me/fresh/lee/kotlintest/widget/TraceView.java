package me.fresh.lee.kotlintest.widget;

import android.animation.FloatEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.util.Log;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;

import androidx.annotation.Keep;

import me.fresh.lee.kotlintest.R;

import static me.fresh.lee.kotlintest.util.UtilsKt.getBitmap;

/**
 * @author lihuayong
 * @version 1.0
 * @description TraceView
 * @date 2019-07-01 14:47
 */
@Keep
public class TraceView extends FrameLayout {
    private float x = 0;
    private float y = 0;

    private float bitmapW = 0;
    private float bitmapH = 0;

    private Bitmap like;
    private Paint paint;
    private Paint linePaint;
    private Path linePath;

    private boolean draw = true;

    public TraceView(Context context) {
        this(context, null);
    }

    public TraceView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public TraceView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
//        setWillNotDraw(false);
//        setForeground(new ColorDrawable(ContextCompat.getColor(context, R.color.transparent_blue)));
//        setBackground(new ColorDrawable(ContextCompat.getColor(context, android.R.color.holo_green_light)));

        like = getBitmap(context, R.drawable.ic_like);
        bitmapW = like != null ? like.getWidth() : 0;
        bitmapH = like != null ? like.getHeight() : 0;
        Log.d("=======", "width = " + bitmapW + ", height = " + bitmapH);

        paint = new Paint();
        paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setFilterBitmap(true);
        paint.setDither(true);

        linePaint = new Paint();
        linePaint.setAntiAlias(true);
        linePaint.setColor(Color.RED);
        linePaint.setStrokeWidth(2);
        linePaint.setStyle(Paint.Style.STROKE);

        linePath = new Path();
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
        Log.d("TraceView", "dispatchDraw");
        if (draw) {
            canvas.drawBitmap(like, x, y, paint);
            linePath.lineTo(x + bitmapW / 2.0f, y + bitmapH);
        } else {
            linePath.lineTo(x, y);
        }
        canvas.drawPath(linePath, linePaint);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Log.d("TraceView", "onDraw");
        if (draw) {
            canvas.drawBitmap(like, x, y, paint);
            linePath.lineTo(x + bitmapW / 2.0f, y + bitmapH);
        } else {
            linePath.lineTo(x, y);
        }
        canvas.drawPath(linePath, linePaint);
    }

    public void start(Interpolator interpolator) {
        start(interpolator, true);
    }

    public void init(float x, float y, boolean draw) {
        linePath.reset();
        linePath.moveTo(x, y);
        this.draw = draw;
    }

    public void draw(float x, float y) {
        this.x = x;
        this.y = y;
        invalidate();
    }

    public void start(Interpolator interpolator, boolean draw) {
        long duration = 1500L;
        linePath.reset();
        linePath.moveTo(bitmapW / 2f, bitmapH);
        ValueAnimator animator = ValueAnimator.ofObject(new FloatEvaluator(), 0f, 500f);
        animator.setDuration(duration);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(animation -> {
            x = (float) animation.getAnimatedValue();
            Log.d("=======", "x = " + x);
        });

        ValueAnimator animatorV = ValueAnimator.ofObject(new FloatEvaluator(), 0f, 500f);
        animatorV.setDuration(duration);
        animatorV.setInterpolator(interpolator);
        animatorV.addUpdateListener(animation -> {
            y = (float) animation.getAnimatedValue();
            Log.d("=======", "y = " + y);
            if (draw) {
                invalidate();
            }
        });

        animator.start();
        animatorV.start();
    }
}
