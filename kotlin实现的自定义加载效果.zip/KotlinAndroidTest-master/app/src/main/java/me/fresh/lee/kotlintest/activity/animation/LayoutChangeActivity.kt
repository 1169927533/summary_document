package me.fresh.lee.kotlintest.activity.animation

import android.animation.Animator
import android.animation.Keyframe
import android.animation.LayoutTransition
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.annotation.SuppressLint
import android.graphics.Point
import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.BounceInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_layout_change.btn_add
import kotlinx.android.synthetic.main.activity_layout_change.btn_delete
import kotlinx.android.synthetic.main.activity_layout_change.ll_container
import me.fresh.lee.kotlintest.R


/**
 *
 * @description    LayoutChangeActivity
 * @author         lihuayong
 * @date           2019/7/4 23:24
 * @version        1.0
 */
class LayoutChangeActivity : AppCompatActivity() {

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_layout_change)

        setupLayoutTransition()

        btn_add.setOnClickListener {
            ll_container.addView(LayoutInflater
                    .from(this@LayoutChangeActivity)
                    .inflate(R.layout.item_child_view, ll_container, false)
                    .apply {
                        (this as Button).text = "Button ${ll_container.childCount + 1}"
                    }, 0)
        }

        btn_delete.setOnClickListener {
            if (ll_container.childCount > 0) {
                ll_container.removeViewAt(0)
            }
        }
    }

    @SuppressLint("ObjectAnimatorBinding")
    private fun setupLayoutTransition() {
        //        val wm = this.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val wm = this.windowManager
        val dm = DisplayMetrics()
        val outSize = Point()
        wm.defaultDisplay.getSize(outSize)

        wm.defaultDisplay.getMetrics(dm)
        val width = dm.widthPixels         // 屏幕宽度（像素）
        val height = dm.heightPixels       // 屏幕高度（像素）
        val density = dm.density         // 屏幕密度（0.75 / 1.0 / 1.5）

        val dm2 = this.resources.displayMetrics
        val density3 = dm2.density
        val width3 = dm2.widthPixels
        val height3 = dm2.heightPixels

        Log.d("========", "width = $width, height = $height, density = $density")
        Log.d("========", "width2 = ${outSize.x}, height2 = ${outSize.y}")
        Log.d("========", "width3 = $width3, height3 = $height3, density3 = $density3")
        val densityDpi = dm.densityDpi     // 屏幕密度dpi（120 / 160 / 240）
        // 屏幕宽度算法:屏幕宽度（像素）/屏幕密度
        val screenWidth = (width / density).toInt()  // 屏幕宽度(dp)
        val screenHeight = (height / density).toInt()// 屏幕高度(dp)
        val transition = LayoutTransition()
        val anim = ObjectAnimator.ofFloat(null, "translationX", -width.toFloat(), 0f)
        transition.setAnimator(LayoutTransition.APPEARING, anim/*customTransitionIn(ll_container)*/)

        val animOut = ObjectAnimator.ofFloat(ll_container, "alpha", 1f, 0f)
        animOut.interpolator = BounceInterpolator()

        val rotationHolder = PropertyValuesHolder.ofFloat("rotationY", 360f, 0f)
        val alphaHolder = PropertyValuesHolder.ofFloat("alpha", 1f, 0f)
        val anim1 = ObjectAnimator.ofPropertyValuesHolder(ll_container, rotationHolder, alphaHolder)

        val animOut2 = ObjectAnimator.ofFloat(null, "translationX", 0f, width.toFloat())
        transition.setAnimator(LayoutTransition.DISAPPEARING, animOut2/*customTransitionOut(ll_container)*/)
        val changeAppearingAnim = customTransitionChange()
        transition.setAnimator(LayoutTransition.CHANGE_APPEARING, changeAppearingAnim)

        val changeDisappearingAnim = changeAppearingAnim.clone()
        changeDisappearingAnim.startDelay = 300
        changeDisappearingAnim.duration = 300
        changeDisappearingAnim.interpolator = DecelerateInterpolator()
        transition.setAnimator(LayoutTransition.CHANGE_DISAPPEARING, changeDisappearingAnim)
        ll_container.layoutTransition = transition
    }

    @Suppress("unused")
    private fun customTransitionIn(target: View): Animator {
        val alphaHolder = PropertyValuesHolder.ofFloat("alpha", 0f, 1f)
        val rotationHolder = PropertyValuesHolder.ofFloat("rotationY", 0f, 360f)
        val scaleXHolder = PropertyValuesHolder.ofFloat("scaleX", 0.1f, 1f)
        val scaleYHolder = PropertyValuesHolder.ofFloat("scaleY", 0.1f, 1f)
        val animIn = ObjectAnimator.ofPropertyValuesHolder(target, alphaHolder, rotationHolder, scaleXHolder, scaleYHolder)
        animIn.duration = 1000
        animIn.interpolator = AccelerateDecelerateInterpolator()
        return animIn
    }

    @Suppress("unused")
    private fun customTransitionOut(target: View): Animator {
        val alphaHolder = PropertyValuesHolder.ofFloat("alpha", 1f, 0f)
        val rotationHolder = PropertyValuesHolder.ofFloat("rotationY", 360f, 0f)
        val scaleXHolder = PropertyValuesHolder.ofFloat("scaleX", 1f, 0.1f)
        val scaleYHolder = PropertyValuesHolder.ofFloat("scaleY", 1f, 0.1f)
        val animOut = ObjectAnimator.ofPropertyValuesHolder(target, alphaHolder, rotationHolder, scaleXHolder, scaleYHolder)
        animOut.duration = 1500
        animOut.interpolator = AccelerateDecelerateInterpolator()
        return animOut
    }

    /**
     * 这里有点问题的， pvhScaleX，缩小之后，如果快速添加删除，会导致不能恢复，一直是缩小状态。
     */
    @SuppressLint("ObjectAnimatorBinding")
    private fun customTransitionChange(): Animator {
        val key = Keyframe.ofInt(0f, 0)
        val key2 = Keyframe.ofInt(1f, 1)
        val pvhLeft = PropertyValuesHolder.ofInt("left", 0, 1)
        val pvhTop = PropertyValuesHolder.ofInt("top", 0, 1)
        val pvhRight = PropertyValuesHolder.ofInt("right", 0, 1)
        val pvhBottom = PropertyValuesHolder.ofInt("bottom", 0, 1)
        val pvhScrollX = PropertyValuesHolder.ofKeyframe("scrollX", key, key2)
        val pvhScrollY = PropertyValuesHolder.ofKeyframe("scrollY", key, key2)
        val pvhScaleX = PropertyValuesHolder.ofFloat("scaleX", 1f, 0.9f, 1f)
        val animChange = ObjectAnimator.ofPropertyValuesHolder(null as Any?,
                pvhLeft, pvhTop, pvhRight, pvhBottom, pvhScrollX, pvhScrollY, pvhScaleX)
        animChange.duration = 300
        animChange.startDelay = 0
        animChange.interpolator = DecelerateInterpolator()
        return animChange
    }
}