package me.fresh.lee.kotlintest.widget;

import android.animation.PointFEvaluator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.ColorInt;
import androidx.annotation.StringRes;

import me.fresh.lee.kotlintest.R;

/**
 * @author lihuayong
 * @version 1.0
 * @description WaterView
 * @date 2019-07-13 22:42
 */
public class WaterView extends FrameLayout {

    private static final int TEXT_PADDING = 10;

    /**
     * 粘性范围
     */
    private static final float OUT_DISTANCE = 200f;

    private static final float INIT_CIRCLE_RADIUS = 50f;

    private final TextView textView;

    /**
     * 文本框初始坐标
     */
    private PointF initPosition;

    /**
     * 手指移动的坐标，终点坐标
     */
    private PointF movePosition;

    /**
     * 动画中的位置
     */
    private PointF animPosition;

    /**
     * 手指是否触摸到了控件
     */
    private boolean isClicked = false;

    /**
     * 起点圆 半径
     */
    private float mRadius1 = INIT_CIRCLE_RADIUS;

    /**
     * 终点圆 半径
     */
    private float mRadius = INIT_CIRCLE_RADIUS;

    private Paint paint;

    /**
     * 贝塞尔曲线Path
     */
    private Path path;

    /**
     * 是否脱离了粘性范围
     */
    private boolean isOut;

    /**
     * 文字脱离粘性范围之后的爆炸效果
     */
    private ImageView exploredImageView;

    public WaterView(Context context) {
        this(context, null);
    }

    public WaterView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    @SuppressLint("SetTextI18n")
    public WaterView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();

        textView = new TextView(getContext());
        textView.setPadding(TEXT_PADDING, TEXT_PADDING, TEXT_PADDING, TEXT_PADDING);
        textView.setText("99+");
        textView.setTextColor(Color.WHITE);
        textView.setBackgroundResource(R.drawable.bg_text_oval);
        LayoutParams lp = new LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        textView.setLayoutParams(lp);
        this.addView(textView);

        exploredImageView = new ImageView(getContext());
        exploredImageView.setLayoutParams(lp);
        exploredImageView.setImageResource(R.drawable.text_animate_explore);
        exploredImageView.setVisibility(View.INVISIBLE);
        this.addView(exploredImageView);
    }

    private void init() {
        paint = new Paint();
        paint.setAntiAlias(true);
        paint.setColor(Color.RED);
        paint.setStyle(Paint.Style.FILL);

        path = new Path();

        initPosition = new PointF(0, 0);
        movePosition = new PointF();
        animPosition = new PointF(initPosition.x, initPosition.y);
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        canvas.save();
        if (isClicked) {
            textView.setX(movePosition.x);
            textView.setY(movePosition.y);
            drawPath();

            if (!isOut) {
                canvas.drawCircle(initPosition.x + (textView.getWidth() >> 1), initPosition.y + (textView.getHeight() >> 1), mRadius1, paint);

                canvas.drawPath(path, paint);

                canvas.drawCircle(movePosition.x + (textView.getWidth() >> 1), movePosition.y + (textView.getHeight() >> 1), mRadius, paint);
            }
        } else {
            textView.setX(animPosition.x);
            textView.setY(animPosition.y);
        }

        //恢复canvas初始状态
        canvas.restore();
        super.dispatchDraw(canvas);
    }

    @SuppressWarnings("unused")
    public TextView getTextView() {
        return textView;
    }

    public void reset() {
        textView.setVisibility(View.VISIBLE);
        exploredImageView.setVisibility(View.GONE);
    }

    public void setText(CharSequence sequence) {
        if (textView != null) {
            textView.setText(sequence);
        }
    }

    public void setText(@StringRes int resId) {
        if (textView != null) {
            textView.setText(resId);
        }
    }

    public void setTextColor(@ColorInt int color) {
        if (textView != null) {
            textView.setTextColor(color);
        }
    }

    private void drawPath() {
        float deltaX = movePosition.x - initPosition.x;
        float deltaY = movePosition.y - initPosition.y;

        //获取两个点之间的距离
        float distance = (float) Math.sqrt(Math.pow(deltaX, 2) + Math.pow(deltaY, 2));

        mRadius1 = INIT_CIRCLE_RADIUS - distance * (INIT_CIRCLE_RADIUS - 10f) / OUT_DISTANCE;

        isOut = distance >= OUT_DISTANCE;

        double theta = Math.atan(deltaY / deltaX);

        float offsetX = (float) (mRadius * Math.sin(theta));
        float offsetY = (float) (mRadius * Math.cos(theta));

        float offsetX1 = (float) (mRadius1 * Math.sin(theta));
        float offsetY1 = (float) (mRadius1 * Math.cos(theta));

        float ax = initPosition.x + offsetX1 + (textView.getWidth() >> 1);
        float ay = initPosition.y - offsetY1 + (textView.getHeight() >> 1);

        float bx = movePosition.x + offsetX + (textView.getWidth() >> 1);
        float by = movePosition.y - offsetY + (textView.getHeight() >> 1);

        float cx = movePosition.x - offsetX + (textView.getWidth() >> 1);
        float cy = movePosition.y + offsetY + (textView.getHeight() >> 1);

        float dx = initPosition.x - offsetX1 + (textView.getWidth() >> 1);
        float dy = initPosition.y + offsetY1 + (textView.getHeight() >> 1);

        path.reset();
        path.moveTo(ax, ay);
        path.quadTo(initPosition.x + deltaX / 2 + (textView.getWidth() >> 1), initPosition.y + deltaY / 2 + (textView.getHeight() >> 1), bx, by);

        path.lineTo(cx, cy);
        path.quadTo(initPosition.x + deltaX / 2 + (textView.getWidth() >> 1), initPosition.y + deltaY / 2 + (textView.getHeight() >> 1), dx, dy);
        path.lineTo(ax, ay);
        path.close();
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {

            case MotionEvent.ACTION_DOWN:
                movePosition.set(initPosition);
                //判断当前点击位置是否在文本控件里面

                //rect 用来封装文本控件的范围
                Rect rect = new Rect();
                int[] location = new int[2];
                textView.getLocationOnScreen(location);

                //初始化Rect对象
                rect.set(location[0], location[1],
                        location[0] + textView.getWidth(), location[1] + textView.getHeight());

                //判断当前点击的坐标是否在范围之内
                if (rect.contains((int) event.getRawX(), (int) event.getRawY())) {
                    isClicked = true;
                }
                break;
            case MotionEvent.ACTION_UP:
                isClicked = false;
                if (isOut) {
                    exploredImageView.setX(movePosition.x);
                    exploredImageView.setY(movePosition.y);
                    exploredImageView.setVisibility(View.VISIBLE);
                    ((AnimationDrawable) exploredImageView.getDrawable()).start();

                    textView.setVisibility(View.GONE);
                } else {
                    animateBack();
                }
                break;
            case MotionEvent.ACTION_MOVE:
                movePosition.set(event.getX(), event.getY());
                break;
            default:
                break;
        }

        invalidate();
        return true;
    }

    /**
     * 动感弹球效果
     */
    private void animateBack() {
        ValueAnimator animator = ValueAnimator.ofObject(new PointFEvaluator(), movePosition, initPosition);
        animator.addUpdateListener(animation -> {
            animPosition = (PointF) animator.getAnimatedValue();
            invalidate();
        });
        animator.setInterpolator(new OvershootInterpolator());
        animator.setDuration(150L);
        animator.start();
    }
}
