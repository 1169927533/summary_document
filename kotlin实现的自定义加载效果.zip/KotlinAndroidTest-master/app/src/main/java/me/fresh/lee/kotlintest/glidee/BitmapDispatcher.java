package me.fresh.lee.kotlintest.glidee;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * @author lihuayong
 * @version 1.0
 * @description BitmapDispatcher
 * @date 2019/7/19 23:34
 */
@SuppressWarnings("WeakerAccess")
public class BitmapDispatcher extends Thread {

    private Handler handler = new Handler(Looper.getMainLooper());
    //线程安全，先进先出
    private LinkedBlockingQueue<BitmapRequest> requestQueue;

    public BitmapDispatcher(LinkedBlockingQueue<BitmapRequest> queue) {
        this.requestQueue = queue;
    }

    @Override
    public void run() {
        super.run();
        //从队列获取请求

        while (!isInterrupted()) {
            try {
                BitmapRequest request = requestQueue.take();

                if (request.getImageView() != null) {
                    //设置占位图
                    showPlaceHolder(request);
                }

                //从网络加载图片
                Bitmap bitmap = loadBitmap(request);

                if (request.getImageView() != null) {
                    //把图片显示到ImageView
                    showImageView(request, bitmap);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    private void showImageView(BitmapRequest request, Bitmap bitmap) {
        ImageView imageView = request.getImageView();
        if (bitmap == null) {
            handler.post(() -> {
                RequestListener listener = request.getRequestListener();
                if (null != listener) {
                    listener.onFailure();
                }
            });
            return;
        }

        if (imageView != null && request.getUrlMd5().equalsIgnoreCase((String) request.getImageView().getTag())) {
            handler.post(() -> {
                imageView.setImageBitmap(bitmap);
                RequestListener listener = request.getRequestListener();
                if (null != listener) {
                    listener.onSuccess(bitmap);
                }
            });
        }
    }

    private Bitmap loadBitmap(BitmapRequest request) {
        return downloadImage(request.getUrl());
    }

    private Bitmap downloadImage(String uri) {
        //存放 磁盘地址 fos
        FileOutputStream fos = null;
        InputStream is = null;
        Bitmap bitmap = null;
        try {
            URL url = new URL(uri);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            is = connection.getInputStream();
            bitmap = BitmapFactory.decodeStream(is);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (is != null) {
                    is.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

            try {
                if (fos != null) {
                    fos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return bitmap;
    }


    private void showPlaceHolder(BitmapRequest request) {
        if (request.getResId() > 0 && request.getImageView() != null) {
            int resId = request.getResId();
            ImageView imageView = request.getImageView();
            handler.post(() -> imageView.setImageResource(resId));
        }
    }
}
