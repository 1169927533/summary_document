package me.fresh.lee.kotlintest.glidee;

import android.content.Context;
import android.widget.ImageView;

/**
 * @author lihuayong
 * @version 1.0
 * @description Glidee
 * @date 2019/7/20 0:38
 */
public class Glidee {

    public static BitmapRequest with(Context context) {
        return new BitmapRequest(context);
    }
}
