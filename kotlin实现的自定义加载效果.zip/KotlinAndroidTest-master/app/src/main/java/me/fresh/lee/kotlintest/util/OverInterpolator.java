package me.fresh.lee.kotlintest.util;

import android.os.Build;
import android.view.animation.BaseInterpolator;

import androidx.annotation.RequiresApi;

/**
 * 三届贝塞尔曲线
 */
@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP_MR1)
public class OverInterpolator extends BaseInterpolator {
    @Override
    public float getInterpolation(float input) {
        return 0;
    }
}
