package me.fresh.lee.kotlintest.glidee;

import android.util.Log;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * @author lihuayong
 * @version 1.0
 * @description Md5Util
 * @date 2019/7/19 23:16
 */
@SuppressWarnings("WeakerAccess")
public class Md5Util {

    private static MessageDigest digest;

    static {
        try {
            digest = MessageDigest.getInstance("Md5");
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            Log.e("Md5Util", "Md5 算法不支持");
        }
    }

    /**
     * @param key 需要MD5转换的字符串
     * @return MD5转换过后的字符串
     */
    public static String toMd5(String key) {
        if (digest == null) {
            return String.valueOf(key.hashCode());
        }

        digest.update(key.getBytes());
        return convert2HexString(digest.digest());
    }

    /**
     * @param digest byte 数组
     * @return 转为16进制字符串
     */
    private static String convert2HexString(byte[] digest) {
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) {
            String hex = Integer.toHexString(0xFF & b);
            if (hex.length() == 1) {
                sb.append(0);
            }

            sb.append(hex);
        }

        return sb.toString();
    }


}
