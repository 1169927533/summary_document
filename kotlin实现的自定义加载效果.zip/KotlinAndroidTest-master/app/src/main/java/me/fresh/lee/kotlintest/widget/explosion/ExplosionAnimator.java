package me.fresh.lee.kotlintest.widget.explosion;

import android.animation.ValueAnimator;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

/**
 * @author lihuayong
 * @version 1.0
 * @description ExplosionAnimator
 * @date 2019-07-13 20:55
 */
public class ExplosionAnimator extends ValueAnimator {
    //获取具体当前动画执行到哪一步了

    /**
     * 动画持续时间
     */
    private static final int DEFAULT_DURATION = 1500;

    /**
     * 粒子集合
     */
    private AbstractParticle[][] mParticles;

    private Paint mPaint;
    private View mContainer;

    private AbstractParticleFactory mParticleFactory;


    public ExplosionAnimator(ExplosionField view, Bitmap bitmap, Rect rect, AbstractParticleFactory factory) {
        mContainer = view;
        mParticleFactory = factory;

        mPaint = new Paint();

        this.setFloatValues(0.1f, 1f);
        this.setDuration(DEFAULT_DURATION);
        this.mParticles = this.mParticleFactory.generateParticles(bitmap, rect);
        bitmap.recycle();
    }

    public void draw(Canvas canvas) {
        if (!isStarted()) {
            //动画结束
            return;
        }

        //所有粒子就需要开始运动
        for (AbstractParticle[] particles : mParticles) {
            for (AbstractParticle particle : particles) {
                particle.advance(canvas, mPaint, (Float) getAnimatedValue());
            }
        }

        mContainer.invalidate();
    }

    @Override
    public void start() {
        super.start();
        mContainer.invalidate();
    }
}
