package me.fresh.lee.kotlintest.widget.explosion;

import android.view.View;

/**
 * @author lihuayong
 * @version 1.0
 * @description ClickCallback
 * @date 2019-07-13 21:25
 */
public interface ClickCallback {

    /**
     * 点击回调
     *
     * @param view view
     */
    void onClick(View view);
}
