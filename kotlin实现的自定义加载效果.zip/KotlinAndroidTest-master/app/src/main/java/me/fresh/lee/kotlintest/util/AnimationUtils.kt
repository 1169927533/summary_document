package me.fresh.lee.kotlintest.util

import android.animation.ObjectAnimator
import android.graphics.Color
import android.widget.TextView


/**
 *
 * @Description:
 * @Author:         lihuayong
 * @CreateDate:     2019/2/21 下午2:59
 * @UpdateUser:
 * @UpdateDate:     2019/2/21 下午2:59
 * @UpdateRemark:
 * @Version:        1.0
 */
object AnimationUtils {

    fun startTextColorAnimator(textView: TextView) {
        val anim = ObjectAnimator.ofObject(
                ColorEvaluator(),
                "#0000FF",
                "#00FF00")
        anim.duration = 3000
        anim.addUpdateListener { animation ->
            val colorStr: String = animation.animatedValue as String
            textView.setTextColor(Color.parseColor(colorStr))
        }
        anim.start()
    }
}