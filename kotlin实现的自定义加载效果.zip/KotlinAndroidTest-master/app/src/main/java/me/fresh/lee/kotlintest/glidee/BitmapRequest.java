package me.fresh.lee.kotlintest.glidee;

import android.content.Context;
import android.widget.ImageView;

import java.lang.ref.SoftReference;

/**
 * @author lihuayong
 * @version 1.0
 * @description BitmapRequest
 * @date 2019/7/19 22:55
 */
@SuppressWarnings("WeakerAccess")
public class BitmapRequest {

    //上下文
    private Context context;

    //图片请求地址
    private String url;

    //需要加载的控件
    private SoftReference<ImageView> imageView;

    //占位图片
    private int resId;

    //回调对象
    private RequestListener requestListener;

    //图片标识, ListView 解决缓存服用View之后图片显示混乱问题
    private String urlMd5;

    public BitmapRequest(Context context) {
        this.context = context;
    }

    /**
     * 设置图片url
     */
    public BitmapRequest load(String url) {
        this.url = url;
        this.urlMd5 = Md5Util.toMd5(url);
        return this;
    }

    /**
     * 设置占位图
     */
    public BitmapRequest placeHolder(int resId) {
        this.resId = resId;
        return this;
    }

    /**
     * 设置监听回调
     */
    public BitmapRequest listener(RequestListener listener) {
        this.requestListener = listener;
        return this;
    }

    /**
     * 设置图片显示控件
     */
    public void into(ImageView imageView) {
        imageView.setTag(urlMd5);
        this.imageView = new SoftReference<>(imageView);
        RequestManager.getInstance().addBitmapRequest(this);
    }

    public String getUrl() {
        return url;
    }

    public ImageView getImageView() {
        return imageView.get();
    }

    public int getResId() {
        return resId;
    }

    public RequestListener getRequestListener() {
        return requestListener;
    }

    public String getUrlMd5() {
        return urlMd5;
    }
}
