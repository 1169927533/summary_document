package me.fresh.lee.kotlintest.widget.explosion;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.view.View;

import java.util.Random;

/**
 * @author lihuayong
 * @version 1.0
 * @description Utils
 * @date 2019-07-13 21:08
 */
public final class Utils {

    public static final Random RANDOM = new Random(System.currentTimeMillis());

    public static final Canvas CANVAS = new Canvas();

    private Utils() {
    }


    public static Bitmap createBitmapForView(View view) {
        view.clearFocus();
        Bitmap bitmap = createBitmapSafety(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888, 1);
        if (bitmap != null) {
            synchronized (CANVAS) {
                CANVAS.setBitmap(bitmap);
                view.draw(CANVAS);
                CANVAS.setBitmap(null);
            }
        }
        return bitmap;
    }

    private static Bitmap createBitmapSafety(int width, int height, Bitmap.Config config, int retryCount) {
        try {
            return Bitmap.createBitmap(width, height, config);
        } catch (OutOfMemoryError e) {
            e.printStackTrace();
            if (retryCount > 0) {
                System.gc();
                return createBitmapSafety(width, height, config, retryCount - 1);
            } else {
                return null;
            }
        }
    }

}
