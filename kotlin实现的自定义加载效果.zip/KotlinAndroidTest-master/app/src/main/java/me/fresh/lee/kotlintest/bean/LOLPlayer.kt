package me.fresh.lee.kotlintest.bean

/**
 * Created by lihuayong on 2018/9/21.
 */
data class LOLPlayer (val name:String, var age:Int, var position:String)