package me.fresh.lee.kotlintest.widget.explosion;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author lihuayong
 * @version 1.0
 * @description ExplosionField
 * @date 2019-07-13 20:44
 */
@SuppressLint("ViewConstructor")
public class ExplosionField extends View {

    private ArrayList<ExplosionAnimator> explosionAnimators;

    private HashMap<View, ExplosionAnimator> explosionAnimatorHashMap;

    private OnClickListener onClickListener;

    private ClickCallback clickCallBack;

    private AbstractParticleFactory particleFactory;

    /**
     * 传入粒子工厂
     */
    public ExplosionField(Context context, AbstractParticleFactory factory) {
        super(context);
        init(factory);
    }

    private void init(AbstractParticleFactory factory) {
        //数据初始化
        particleFactory = factory;

        explosionAnimators = new ArrayList<>();
        explosionAnimatorHashMap = new HashMap<>(256);

        //将Field添加到屏幕里去
        attachToActivity((Activity) getContext());

    }

    private void attachToActivity(Activity activity) {
        ViewGroup rootView = activity.findViewById(Window.ID_ANDROID_CONTENT);
        ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        rootView.addView(this, layoutParams);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (ExplosionAnimator explosionAnimator : explosionAnimators) {
            explosionAnimator.draw(canvas);
        }
    }

    public void addExplosion(View view) {
        ExplosionField.this.explode(view);
    }

    /**
     * 给需要有粒子特效的View设置点击事件
     *
     * @param view 需要设置粒子效果的view
     */
    @SuppressWarnings("unused")
    public void addListener(View view) {
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;

            int count = viewGroup.getChildCount();

            for (int i = 0; i < count; i++) {
                this.addListener(viewGroup.getChildAt(i));
            }
        } else {
            view.setClickable(true);
            view.setOnClickListener(this.getOnClickListener());
        }
    }

    @SuppressWarnings("unused")
    public void setClickCallBack(ClickCallback callBack) {
        this.clickCallBack = callBack;
    }

    private OnClickListener getOnClickListener() {

        if (null == this.onClickListener) {

            this.onClickListener = v -> {
                //开启粒子特效
                ExplosionField.this.explode(v);
                if (ExplosionField.this.clickCallBack != null) {
                    ExplosionField.this.clickCallBack.onClick(v);
                }
            };
        }
        return onClickListener;
    }

    /**
     * 粒子爆炸特效的入口
     */
    private void explode(View view) {
        //生成一个View的副本， 以及位置对齐
        Rect rect = new Rect();
        //获取View相对于整个屏幕的位置
        view.getGlobalVisibleRect(rect);

        //Actionbar 高度
        int contentTop = ((ViewGroup) getParent()).getTop();

        //获取状态栏高度
        Rect frame = new Rect();
        ((Activity) getContext()).getWindow().getDecorView().getWindowVisibleDisplayFrame(frame);
        int statusBarHeight = frame.top;
        rect.offset(0, -contentTop - statusBarHeight); //位置对齐

        //先震动效果
        ValueAnimator animator = ValueAnimator.ofFloat(0f, 1f).setDuration(150L);
        animator.addUpdateListener(animation -> {
            view.setTranslationX((Utils.RANDOM.nextFloat() - 0.5f) * view.getWidth() * 0.05f);
            view.setTranslationY((Utils.RANDOM.nextFloat() - 0.5f) * view.getHeight() * 0.05f);
        });

        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                //恢复位置
                view.setTranslationX(0);
                view.setTranslationY(0);

                //再开启粒子效果动画
                explode2(view, rect);
            }
        });

        animator.start();
    }

    private void explode2(final View view, Rect rect) {
        ExplosionAnimator animator = new ExplosionAnimator(this, Utils.createBitmapForView(view), rect, this.particleFactory);
        this.explosionAnimators.add(animator);
        this.explosionAnimatorHashMap.put(view, animator);
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationStart(Animator animation) {
                view.setClickable(false);
                view.animate().setDuration(150L).scaleX(0.0f).scaleY(0.0f).alpha(0.0f).start();
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                view.animate().setDuration(150L).scaleX(1.0f).scaleY(1.0f).alpha(1.0f).start();
                view.setClickable(true);
                ExplosionField.this.explosionAnimators.remove(animator);
                ExplosionField.this.explosionAnimatorHashMap.remove(view);
            }
        });

        animator.start();
    }
}
