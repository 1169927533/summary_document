package me.fresh.lee.kotlintest.adapter

import android.content.Context
import android.view.View

/**
 * Created by lihuayong on 2018/9/21.
 */
abstract class RollingTextAdapter {
    abstract fun getCount():Int
    abstract fun getView(context:Context, position:Int):View
}