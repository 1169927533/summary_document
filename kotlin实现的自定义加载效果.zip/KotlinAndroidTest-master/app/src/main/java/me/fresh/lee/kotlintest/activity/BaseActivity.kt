package me.fresh.lee.kotlintest.activity

import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import androidx.annotation.ColorInt
import androidx.annotation.ColorRes
import androidx.annotation.DrawableRes
import androidx.core.content.ContextCompat
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import me.fresh.lee.kotlintest.R

/**
 * Created by lihuayong on 2018/9/29.
 * Base activity for all application activities
 */
@SuppressLint("Registered")
open class BaseActivity : AppCompatActivity() {

    protected var toolbar: Toolbar? = null
    protected var mTitle: TextView? = null
    protected var mSubTitle: TextView? = null
    private var titleStr: String? = null
    private var menu: Menu? = null


    override fun onPostCreate(savedInstanceState: Bundle?) {
        super.onPostCreate(savedInstanceState)

        if (toolbar == null) {
            Log.i("LEE", "init toolbar")
            initToolBar(true)
        }
    }

    override fun setTitle(titleId: Int) {
        this.title = getString(titleId)
    }

    override fun setTitle(title: CharSequence?) {
        if (mTitle == null) {
            Log.i("LHY", "title == null")
            if (title != null)
                titleStr = title as String?
            return
        }
        mTitle!!.text = title
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        super.onCreateOptionsMenu(menu)
        menuInflater.inflate(R.menu.base_menu, menu)
        this.menu = menu
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        val id = item!!.itemId
        if (id == R.id.menu_more) {
            Toast.makeText(this@BaseActivity, "click more!", Toast.LENGTH_SHORT).show()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    protected fun initToolBar(showNavigation: Boolean) {
        initToolBar(R.drawable.ic_arrow_back_black_24dp, showNavigation, showNavigation)
    }

    protected fun initToolBar(@DrawableRes navigationResId: Int) {
        initToolBar(navigationResId, true, true)
    }

    protected fun initToolBar(@DrawableRes navigationResId: Int, isTitleAlignCenter: Boolean) {
        initToolBar(navigationResId, isTitleAlignCenter, true, !isTitleAlignCenter)
    }

    protected fun initToolBar(@DrawableRes navigationResId: Int, showNavigationIcon: Boolean, showVerticalDivider: Boolean) {
        initToolBar(navigationResId, true, showNavigationIcon, showVerticalDivider)
    }

    protected fun initToolBar(@DrawableRes navigationResId: Int, isTitleAlignCenter: Boolean, showNavigation: Boolean, showVertivalDivider: Boolean) {
        toolbar = findViewById(R.id.toolbar_common)
        toolbar?.let {
            it.setBackgroundColor(getColorInt(R.color.blue_pressed))
            setStatusBarColor(getColorInt(R.color.blue))
            mTitle = it.findViewById(R.id.toolbar_main_title)
            mSubTitle = it.findViewById(R.id.toolbar_subtitle)
            setSupportActionBar(toolbar)

            title = if (titleStr != null) {
                titleStr
            } else {
                title
            }
            supportActionBar?.setDisplayShowTitleEnabled(false)
            if (!isTitleAlignCenter && showNavigation) {
                it.setNavigationIcon(navigationResId)
            }
            disableSubTitle()
            val divider: View = it.findViewById(R.id.v_divider)
            divider.visibility.apply { if (showVertivalDivider) View.VISIBLE else View.GONE }
            if (isTitleAlignCenter) {
                val leftView: View = this.findViewById(R.id.toolbar_navigation_left)
                if (leftView is ImageView && showNavigation) {
                    leftView.setVisibility(View.VISIBLE)
                    leftView.setImageResource(navigationResId)
                    leftView.setOnClickListener {
                        finish()
                    }
                } else {
                    leftView.visibility = View.INVISIBLE
                }
            } else {
            }
        }
    }

    private fun disableSubTitle() {
        if (mSubTitle == null)
            return
        mSubTitle!!.visibility = View.GONE
    }

    protected fun setStatusBarColor(@ColorInt colorInt: Int) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            this.window.apply {
                addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
                clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS)
                statusBarColor = colorInt
            }
        }
    }

    @ColorInt
    protected fun getColorInt(@ColorRes colorRes: Int): Int {
        return ContextCompat.getColor(this@BaseActivity, colorRes)
    }
}