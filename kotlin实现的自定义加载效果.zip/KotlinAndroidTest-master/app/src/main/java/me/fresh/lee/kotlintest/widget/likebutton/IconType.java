package me.fresh.lee.kotlintest.widget.likebutton;

/**
 * Created by Joel on 23/12/2015.
 */
public enum IconType {
    Heart,
    Thumb,
    Star
}
