package me.fresh.lee.kotlintest.activity

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.tabs.TabLayout
import kotlinx.android.synthetic.main.activity_stick_tablayout.pager
import kotlinx.android.synthetic.main.activity_stick_tablayout.tabs
import me.fresh.lee.kotlintest.R

/**
 *
 * @description    StickActivity
 * @author         lihuayong
 * @date           2019-08-15 15:58
 * @version        1.0
 */
class StickActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stick_tablayout)

        val titles = arrayListOf<String>("Tab1", "Tab2", "Tab3")
        val adapter = SimplePageAdapter(supportFragmentManager, titles)
        pager.adapter = adapter
        tabs.tabMode = TabLayout.MODE_SCROLLABLE
        tabs.tabGravity = TabLayout.GRAVITY_CENTER

        tabs.setupWithViewPager(pager)
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabReselected(p0: TabLayout.Tab?) {
            }

            override fun onTabUnselected(p0: TabLayout.Tab?) {
            }

            override fun onTabSelected(tab: TabLayout.Tab?) {
                tab?.position?.let {
                    //tab.text as String?
                    Log.d("xxxxxx", "onTabSelected" + tab.position)
                }
            }
        })
    }

}