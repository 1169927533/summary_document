package me.fresh.lee.kotlintest.widget.likebutton;

public interface OnAnimationEndListener {
    void onAnimationEnd(LikeButton likeButton);
}
